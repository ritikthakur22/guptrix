import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

const transport = nodemailer.createTransport({
    host: "smtp-relay.brevo.com",
    port: 587,
    secure: false,
    auth: {
        user: process.env.EMAIL_FROM,
        pass: process.env.BREVO_API_KEY
    },
    pool: true,
    maxConnections: 3,
});

export const sendEmail = async (to: string, subject: string, purpose: string, otp: string) => {
    try {
        await transport.sendMail({
            from: `"Guptrix" <guptrix@gmail.com>`,
            to: to.toLowerCase().trim(),
            subject,
            html: `
                        <!DOCTYPE html>
                        <html lang="en">
                        <head>
                        <meta charset="UTF-8" />
                        <title>OTP From TMS</title>
                        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                        </head>

                        <body style="margin:0; padding:0; background-color:#f4f6f8; font-family:Arial, Helvetica, sans-serif;">
                        
                        <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f6f8; padding:40px 0;">
                            <tr>
                            <td align="center">

                                <table width="100%" cellpadding="0" cellspacing="0" style="max-width:600px; background:#ffffff; border-radius:10px; box-shadow:0 6px 18px rgba(0,0,0,0.08); padding:32px;">
                                
                                <tr>
                                    <td align="center" style="padding-bottom:20px;">
                                    <h2 style="margin:0; font-size:22px; color:#111827;">
                                        ${purpose}
                                    </h2>
                                    </td>
                                </tr>

                                <tr>
                                    <td style="font-size:16px; color:#374151; line-height:1.6; padding-bottom:24px;">
                                    Hello,<br><br>
                                    Use the OTP below to complete your verification.  
                                    This code is valid for <strong>5 minutes</strong>.
                                    </td>
                                </tr>

                                <tr>
                                    <td align="center" style="padding-bottom:24px;">
                                    <div
                                        style="
                                        display:inline-block;
                                        padding:16px 28px;
                                        font-size:28px;
                                        letter-spacing:8px;
                                        font-weight:700;
                                        color:#2563eb;
                                        background:#f1f5f9;
                                        border-radius:8px;
                                        "
                                    >
                                        ${otp}
                                    </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td style="font-size:14px; color:#6b7280; line-height:1.6; padding-bottom:28px;">
                                    If you did not request this code, please ignore this email.  
                                    Do not share this OTP with anyone for security reasons.
                                    </td>
                                </tr>

                                <tr>
                                    <td style="border-top:1px solid #e5e7eb; padding-top:20px;"></td>
                                </tr>

                                <tr>
                                    <td align="center" style="font-size:12px; color:#9ca3af; padding-top:10px;">
                                    © 2026 TMS. All rights reserved.
                                    </td>
                                </tr>

                                </table>

                            </td>
                            </tr>
                        </table>

                        </body>
                        </html>
                        `,
        });
        console.log("Email sent successfully");
    } catch (err) {
        console.error("Error sending Email", err);
        throw new Error("Email send failed");
    };
};