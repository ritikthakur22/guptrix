import UserCounter from "../mvc/models/userCounter.model";

export const generateUserId = async (): Promise<string> => {
    const userCounter = await UserCounter.findOneAndUpdate(
        { id: 'userId' },
        { $inc: { seq: 1 } },
        { new: true, upsert: true }
    );

    const seqNumber = userCounter?.seq.toString().padStart(5, '0');
    return `USER-${seqNumber}`;
};