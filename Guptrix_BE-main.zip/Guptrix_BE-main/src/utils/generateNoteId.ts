import NoteCounter from "../mvc/models/noteCounter.model";
export const generateNoteId = async (): Promise<string> => {
    const noteCounter = await NoteCounter.findOneAndUpdate(
        { id: 'noteId' },
        { $inc: { seq: 1 } },
        { new: true, upsert: true }
    );

    const seqNumber = noteCounter?.seq.toString().padStart(10, '0');
    return `NOTE-${seqNumber}`;
};