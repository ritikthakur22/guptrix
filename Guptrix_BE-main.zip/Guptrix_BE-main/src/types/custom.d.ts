import { Request } from "express";
import { UserModel } from "../mvc/models/user.model";

declare module 'express-server-static-core' {
    interface Request {
        user?: UserModel;
    }
}