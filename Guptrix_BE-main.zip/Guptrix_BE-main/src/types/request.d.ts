import { UserModel } from "../mvc/models/user.model";
import { Request } from "express";
import mongoose from "mongoose";
export interface AuthenticatedRequest extends Request {
    user: UserModel;
    currentUserId: mongoose.Types.ObjectId; // Add this since you attach it in jwtVerify
}