import { JwtPayload } from "jsonwebtoken";

export interface AccessTokenPayload extends JwtPayload {
  data: {
    email: string;
    userId: string;
  };
}
