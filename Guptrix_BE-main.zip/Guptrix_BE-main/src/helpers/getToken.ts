import Jwt, { SignOptions } from "jsonwebtoken";

export const getAccessToken = (email: string, userId?: string, expiry?: string) => {
    const expiresIn = (expiry ?? '15m') as SignOptions['expiresIn'];
    const data = { email, userId };

    if (!process.env.ACCESS_TOKEN_SECRET) throw new Error('Access scret token not found');

    const options: SignOptions = { expiresIn };

    const accessToken = Jwt.sign({ data }, process.env.ACCESS_TOKEN_SECRET as string | undefined, options);

    return accessToken;
}

export const getRefreshToken = (email: string, userId?: string, expiry?: string) => {
    const expiresIn = (expiry ?? '7d') as SignOptions['expiresIn'];
    const data = { email, userId };

    if (!process.env.REFRESH_TOKEN_SECRET) throw new Error('Refresh secret token not found');

    const options: SignOptions = { expiresIn }

    const refreshToken = Jwt.sign({ data }, process.env.REFRESH_TOKEN_SECRET as string | undefined, options);

    return refreshToken;
} 