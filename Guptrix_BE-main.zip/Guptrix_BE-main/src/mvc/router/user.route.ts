import { Router } from "express";
import api from "../controller/user.controller";

const userRoute: Router = Router();

userRoute.get('/current', api.getCurrentUser);

export default userRoute;