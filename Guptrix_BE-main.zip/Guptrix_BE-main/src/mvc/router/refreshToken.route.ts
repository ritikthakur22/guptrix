import e, { Router } from "express";
import api from "../controller/refreshToken.controller";

const refreshTokenrouter = Router();

refreshTokenrouter.get('/access-token', api.handleRefreshToken)

export default refreshTokenrouter;