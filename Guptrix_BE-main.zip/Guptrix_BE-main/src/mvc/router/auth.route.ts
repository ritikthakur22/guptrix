import { Router } from "express";
import api from "../controller/auth.controller"
import jwtVerify from "../middlewares/auth.middleware"

const authRoute = Router();

authRoute.post('/register', api.register);
authRoute.post('/verify', api.verifyOTP);
authRoute.post('/resend-otp', api.resendOTP);
authRoute.post('/login', api.login);
authRoute.post('/request-password-reset', api.requestPasswordReset);
authRoute.post('/verify-otp-reset-password', api.verifyOtpAndResetPassword); // case you don't know the old password
authRoute.patch('/reset-password', jwtVerify, api.password_reset);  // ase you know old password
authRoute.post('/logout', api.logout);
authRoute.get('/recovery-login/:email', api.getRecoveryCreds);

export default authRoute;