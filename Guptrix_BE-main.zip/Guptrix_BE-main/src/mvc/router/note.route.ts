import { Router } from "express";
import api from "../controller/note.controller";

const noteRoute = Router();

// --- Main Operations ---
noteRoute.post('/create', api.createNote);
noteRoute.get('/get-notes', api.getNote);
noteRoute.patch("/update/:noteId", api.updateNote);

// --- Trash Operations ---
// Note: Keep /trash above routes with /:noteId if they share the same base path
noteRoute.get('/trash', api.getTrashNotes);
noteRoute.delete("/delete/:noteId", api.deleteNote); // Fixed: Added leading slash
noteRoute.patch('/restore/:noteId', api.restoreNote);
noteRoute.delete('/permanent-delete/:noteId', api.hardDeleteNote);

// --- Upload note ---
noteRoute.get('/get-note-status/:noteId', api.getNoteStatus);
noteRoute.post('/import-note', api.importNote);

export default noteRoute;