import mongoose, { Schema, Document } from "mongoose";

interface IUserCounter extends Document {
    id: string;
    seq: number;
}

const userCouterSchema: Schema = new Schema({
    id: {
        type: String,
        required: true,
        unique: true,
    },
    seq: {
        type: Number,
        default: 0,
    },
});

const UserCounter = mongoose.model<IUserCounter>('userCounter', userCouterSchema);
export default UserCounter;
