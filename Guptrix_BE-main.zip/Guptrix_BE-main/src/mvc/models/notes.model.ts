import { generateNoteId } from "../../utils/generateNoteId";
import mongoose, { Document, Schema } from "mongoose";

// 1. Rename 'Delete' to 'Trash' to avoid JS reserved word conflicts
type TrashInfo = {
    isDeleted: boolean;
    deletedAt: Date | null; // Use null when not in trash
}
export interface INotes {
    userId: mongoose.Types.ObjectId;
    noteId: string;
    titleIV: string;
    title: string;
    contentIV?: string;
    content?: string;
    canvasData?: string;
    canvasIV?: string;
    color: string;
    pinned: boolean;
    trash: TrashInfo;
}

export interface NoteModel extends INotes, Document { }

const NoteSchema: Schema = new Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user',
        required: true,
        // index: true,
    },
    noteId: {
        type: String,
        unique: true
    },
    titleIV: {
        type: String,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    content: {
        type: String,
        required: false
    },
    contentIV: {
        type: String,
        required: false
    },
    canvasData: {
        type: String,
        required: false
    },
    canvasIV: {
        type: String,
        required: false
    },
    color: {
        type: String,
        enum: ["default", "yellow", "green", "blue", "pink", "purple", "orange"],
        default: "default"
    },
    pinned: {
        type: Boolean,
    },
    trash: {
        isDeleted: {
            type: Boolean,
            default: false,
        },
        deletedAt: {
            type: Date,
            default: null
        }
    }
},
    { timestamps: true }
)

NoteSchema.pre<NoteModel>("save", async function () {
    if (!this.noteId) {
        this.noteId = await generateNoteId();
    }
});

// 2. THE TTL INDEX: This automatically deletes the doc 15 days after deletedAt
// Note: This only works if deletedAt is a valid Date. If it's null, nothing happens.
NoteSchema.index({ "trash.deletedAt": 1 }, { expireAfterSeconds: 15 * 24 * 60 * 60 });

// NoteSchema.index({ userId: 1, createdAt: -1 });

// 3. Optimized Compound Index
// This covers getNote (filtering by isDeleted: false) 
// and getTrashNotes (filtering by isDeleted: true)
// while keeping them sorted by date.
NoteSchema.index({ userId: 1, "trash.isDeleted": 1, createdAt: -1 });


const Note = mongoose.model<NoteModel>('note', NoteSchema);
export default Note;