import mongoose, { Document, Schema } from "mongoose";
import { generateUserId } from "../../utils/generateUserId";

export interface IUser {
    userId: string;
    username: string;
    email: string;
    password: string;
    otp?: {
        code: string;
        expiresAt: Date;
    } | null;
    isVerified: boolean;
    isBlocked: boolean;
    salt: string;           // for PBKDF2
    encryptedAESKey: string; // AES key encrypted with password-derived key
    keyIV: string;            // IV used to encrypt AES key
    refreshToken: string;
    recoverySalt: string; // used when user forgot password 
    recoveryIv: string; // used when user forgot password 
    encryptedAESKeyWithRecovery: string; // used when user forgot password 
};

export interface UserModel extends IUser, Document { }

const UserSchema: Schema = new Schema({
    userId: {
        type: String,
        unique: true,
    },
    username: {
        type: String,
        required: true,
        trim: true,
    },
    email: {
        type: String,
        required: true,
        trim: true,
        lowercase: true,
        unique: true,
    },
    password: {
        type: String,
        required: true,
        select: false, // hidden by default
    },
    otp: {
        code: { type: String, default: null },
        expiresAt: { type: Date, default: null },
    },
    isVerified: {
        type: Boolean,
        default: false,
    },
    isBlocked: {
        type: Boolean,
        default: false,
    },
    salt: {
        type: String,
        required: true
    },
    encryptedAESKey: {
        type: String,
        required: true
    },
    keyIV: {
        type: String,
        required: true
    },
    recoverySalt: {
        type: String,
        required: true
    },
    encryptedAESKeyWithRecovery: {
        type: String,
        required: true
    },
    recoveryIv: {
        type: String,
        required: true
    },
    refreshToken: {
        type: String,
        default: null
    }
},
    { timestamps: true }
)

UserSchema.pre<UserModel>("save", async function () {
    if (!this.userId) {
        this.userId = await generateUserId();
    }
});


const User = mongoose.model<UserModel>('user', UserSchema)
export default User;