import mongoose, { Schema, Document } from "mongoose";

interface INoteCounter extends Document {
    id: string;
    seq: number;
}

const noteCouterSchema: Schema = new Schema({
    id: {
        type: String,
        required: true,
        unique: true,
    },
    seq: {
        type: Number,
        default: 0,
    },
});

const NoteCounter = mongoose.model<INoteCounter>('noteCounter', noteCouterSchema);
export default NoteCounter;
