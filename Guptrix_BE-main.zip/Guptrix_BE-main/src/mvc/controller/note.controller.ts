import { Request, Response } from "express"
import Note from "../models/notes.model";
import { AuthenticatedRequest } from "@/types/request";
import NoteCounter from "../models/noteCounter.model";


const createNote = async (req: AuthenticatedRequest, res: Response) => {
    try {
        // const { titleIV, contentIV, title, content, color, pinned } = req.body;
        const { titleIV, title, color, pinned } = req.body;
        const userId = req.user._id;

        // 1. Basic Validation
        if (!titleIV || !title || !color) {
            // if (!titleIV || !contentIV || !title || !content || !color) {
            return res.status(400).json({ error: "Required fields are missing" });
        }

        if (typeof pinned !== "boolean") {
            return res.status(400).json({ error: "Pinned must be boolean" });
        }

        // 2. Initialize Note
        // We don't need to pass 'trash' here because the Schema defaults handle it.
        const newNote = new Note({
            userId,
            titleIV,
            title,
            // contentIV,
            // content,
            color: color || "default", // explicitly handling defaults if you want
            pinned: pinned || false,
            trash: {
                isDeleted: false,
                deletedAt: null
            }
        });

        // 3. Save to Database
        await newNote.save();

        return res.status(201).json({ // 201 is more standard for "Created"
            message: "Note created successfully",
            note: {
                noteId: newNote.noteId,
                title: newNote.title,
                content: newNote?.content,
                canvasData: newNote?.canvasData,
                canvasIV: newNote?.canvasIV,
                color: newNote.color,
                pinned: newNote.pinned,
                titleIV: newNote.titleIV,
                contentIV: newNote?.contentIV
            }
        });

    } catch (error) {
        console.error("Error occurred during note creation:", error);
        return res.status(500).json({
            error: "Internal servers error. Please try again later."
        });
    }
}

// const getNote = async (req: AuthenticatedRequest, res: Response) => {
//     try {
//         // const userId = req.user._id;

//         // const page = parseInt(req.query.page as string) || 1;
//         // const limit = parseInt(req.query.limit as string) || 10;

//         // const skip = (page - 1) * limit;

//         // const [userNotes, totalNotes] = await Promise.all([
//         //     Note.find({ userId })
//         //         .sort({ createdAt: -1 }) // Usually best to show newest first
//         //         .skip(skip)
//         //         .limit(limit),
//         //     Note.countDocuments({ userId })
//         // ]);

//         // return res.status(200).json({
//         //     message: "Notes found",
//         //     currentPage: page,
//         //     totalPages: Math.ceil(totalNotes / limit),
//         //     totalItems: totalNotes,
//         //     userNotes
//         // });

//         const userId = req.user._id;
//         // 1. Get page and limit from query strings, with defaults
//         const page = parseInt(req.query.page as string) || 1;
//         const limit = parseInt(req.query.limit as string) || 10;
//         // 2. Calculate how many documents to skip
//         // If page is 2 and limit is 10, skip (2-1)*10 = 10 notes.
//         const skip = (page - 1) * limit;

//         // CRITICAL: Add { "trash.isDeleted": false } to the query
//         const query = { userId, "trash.isDeleted": false };

//         // 3. Fetch data and total count in parallel for better performance
//         const [userNotes, totalNotes] = await Promise.all([
//             Note.find(query)
//                 .sort({ createdAt: -1 })
//                 .skip(skip)
//                 .limit(limit),
//             Note.countDocuments(query)
//         ]);

//         return res.status(200).json({
//             message: "Notes found",
//             currentPage: page,
//             totalPages: Math.ceil(totalNotes / limit),
//             totalItems: totalNotes,
//             userNotes
//         });

//     } catch (err) {
//         console.error("Error occurred during reading user's notes", err);
//         return res.status(500).json({ error: "Internal server error." });
//     }
// };

const getNote = async (req: AuthenticatedRequest, res: Response) => {
    try {
        const userId = req.user._id;

        // 1. Extract query parameters
        const page = parseInt(req.query.page as string) || 1;
        const limit = parseInt(req.query.limit as string) || 10;
        const search = req.query.search as string; // Get search string from query

        const skip = (page - 1) * limit;

        // 2. Build the dynamic query object
        const query: any = {
            userId,
            "trash.isDeleted": false
        };

        // 3. If a search term exists, add it to the query
        if (search) {
            // "i" makes it case-insensitive
            // This searches for the term in either 'title' OR 'content'
            query.$or = [
                { title: { $regex: search, $options: "i" } },
                // { content: { $regex: search, $options: "i" } }
            ];
        }

        // 4. Fetch data and total count in parallel
        const [userNotes, totalNotes] = await Promise.all([
            Note.find(query)
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(limit),
            Note.countDocuments(query)
        ]);

        return res.status(200).json({
            message: search ? `Search results for "${search}"` : "Notes found",
            currentPage: page,
            totalPages: Math.ceil(totalNotes / limit),
            totalItems: totalNotes,
            userNotes
        });

    } catch (err) {
        console.error("Error occurred during reading user's notes", err);
        return res.status(500).json({ error: "Internal server error." });
    }
};

const updateNote = async (req: AuthenticatedRequest, res: Response) => {
    try {
        const userId = req.user._id;
        const { noteId } = req.params;
        const { titleIV, contentIV, canvasData, canvasIV, title, content, color, pinned } = req.body;

        // 1. Validation
        // if (!encryptedTitle || !encryptedContent || !iv) {
        //     return res.status(400).json({ error: "Missing required encryption data" });
        // }

        // 2. Find and Update 
        // Logic: Only update if noteId belongs to userId AND is NOT deleted
        const updatedNote = await Note.findOneAndUpdate(
            {
                noteId,
                userId,
                "trash.isDeleted": false // Prevent editing trashed notes
            },
            {
                $set: {
                    titleIV,
                    contentIV,
                    canvasIV,
                    title,
                    content,
                    canvasData,
                    color,    // Added color update
                    pinned    // Added pinned update
                }
            },
            { new: true, runValidators: true }
        );

        // 3. Specific Error Handling
        if (!updatedNote) {
            // Check if note exists but is in trash
            const trashedNote = await Note.findOne({ noteId, userId, "trash.isDeleted": true });

            if (trashedNote) {
                return res.status(400).json({ error: "Cannot edit a note that is in the trash. Please restore it first." });
            }

            return res.status(404).json({ error: "Note not found." });
        }

        return res.status(200).json({
            message: "Note updated successfully",
            updatedNote
        });

    } catch (err) {
        console.error("Update error:", err);
        return res.status(500).json({ error: "Internal server error" });
    }
};

const deleteNote = async (req: AuthenticatedRequest, res: Response) => {
    try {
        const userId = req.user._id;
        const { noteId } = req.params;

        // 1. Validation: Ensure noteId is provided
        if (!noteId) {
            return res.status(400).json({ error: "Note ID is required to perform this action." });
        }

        // 2. Optimization/Logic: Find the note first or use a targeted update
        // We only want to move it to trash if it's NOT already there.
        const trashedNote = await Note.findOneAndUpdate(
            {
                userId,
                noteId,
                "trash.isDeleted": false // Only trash it if it's currently active
            },
            {
                $set: {
                    "trash.isDeleted": true,
                    "trash.deletedAt": new Date()
                }
            },
            { new: true }
        );

        // 3. Specific Error Feedback
        if (!trashedNote) {
            // Check if it exists but is already deleted
            const alreadyDeleted = await Note.findOne({ userId, noteId, "trash.isDeleted": true });

            if (alreadyDeleted) {
                return res.status(409).json({ error: "Note is already in the trash." });
            }

            return res.status(404).json({ error: "Note not found or you do not have permission." });
        }

        return res.status(200).json({
            message: "Note moved to trash. It will be permanently deleted in 15 days.",
            noteId
        });

    } catch (err) {
        // 4. Log the actual error for debugging, but keep the client response generic
        console.error(`[DeleteNote Error] User: ${req.user._id} | Note: ${req.params.noteId}`, err);

        return res.status(500).json({
            error: "An unexpected error occurred while moving the note to trash."
        });
    }
};


const getTrashNotes = async (req: AuthenticatedRequest, res: Response) => {
    try {
        const userId = req.user._id;

        // 1. Parse pagination parameters
        const page = parseInt(req.query.page as string) || 1;
        const limit = parseInt(req.query.limit as string) || 10;
        const search = req.query.search as string;

        // Ensure page and limit are positive numbers
        if (page < 1 || limit < 1) {
            return res.status(400).json({ error: "Page and limit must be positive integers." });
        }

        const skip = (page - 1) * limit;

        // 2. Define the Trash Filter
        const query: any = {
            userId,
            "trash.isDeleted": true
        };

        if (search) {
            query.$or = [
                { title: { $regex: search, $options: "i" } },
                // { content: { $regex: search, $options: "i" } }
            ]
        }

        // 3. Execute queries in parallel
        const [trashedNotes, totalNotes] = await Promise.all([
            Note.find(query)
                .sort({ "trash.deletedAt": -1 }) // Show most recently deleted first
                .skip(skip)
                .limit(limit)
                .lean(), // Using .lean() for better read performance
            Note.countDocuments(query)
        ]);

        // 4. Return paginated response
        return res.status(200).json({
            message: "Trash notes retrieved successfully",
            currentPage: page,
            totalPages: Math.ceil(totalNotes / limit),
            totalItems: totalNotes,
            trashedNotes
        });

    } catch (error) {
        console.error("Error fetching trash notes:", error);
        return res.status(500).json({
            error: "Internal server error. Could not retrieve trash."
        });
    }
};

const hardDeleteNote = async (req: AuthenticatedRequest, res: Response) => {
    try {
        const { noteId } = req.params;
        const userId = req.user._id;

        // 1. Validation: Ensure noteId is provided
        if (!noteId) {
            return res.status(400).json({ error: "Note ID is required for permanent deletion." });
        }

        // 2. Execution: Only delete if it belongs to user AND is already in trash
        const deleted = await Note.findOneAndDelete({
            noteId,
            userId,
            "trash.isDeleted": true
        });

        // 3. Response Handling
        if (!deleted) {
            // Check if the note exists but isn't in the trash yet
            const existsOutsideTrash = await Note.findOne({ noteId, userId, "trash.isDeleted": false });

            if (existsOutsideTrash) {
                return res.status(400).json({
                    error: "Note must be moved to trash before it can be permanently deleted."
                });
            }

            return res.status(404).json({ error: "Note not found in trash." });
        }

        return res.status(200).json({
            message: "Note permanently deleted from database.",
            noteId
        });

    } catch (err) {
        console.error(`[HardDelete Error] User: ${req.user._id} | Note: ${req.params.noteId}`, err);
        return res.status(500).json({
            error: "Internal server error. Failed to permanently delete the note."
        });
    }
};

const restoreNote = async (req: AuthenticatedRequest, res: Response) => {
    try {
        const userId = req.user._id;
        const { noteId } = req.params;

        // 1. Validation
        if (!noteId) {
            return res.status(400).json({ error: "Note ID is required to restore." });
        }

        // 2. Find and Update
        // Logic: Only restore if the note belongs to the user AND is actually deleted
        const restoredNote = await Note.findOneAndUpdate(
            {
                userId,
                noteId,
                "trash.isDeleted": true
            },
            {
                $set: {
                    "trash.isDeleted": false,
                    "trash.deletedAt": null // Stops the 15-day auto-delete timer
                }
            },
            { new: true }
        );

        // 3. Error Handling
        if (!restoredNote) {
            // Check if the note is already active
            const isAlreadyActive = await Note.findOne({ userId, noteId, "trash.isDeleted": false });

            if (isAlreadyActive) {
                return res.status(400).json({ error: "Note is already active and not in the trash." });
            }

            return res.status(404).json({ error: "Note not found in trash." });
        }

        return res.status(200).json({
            message: "Note restored successfully",
            restoredNote
        });

    } catch (err) {
        console.error("Restore error:", err);
        return res.status(500).json({ error: "Internal server error" });
    }
};

const getNoteStatus = async (req: AuthenticatedRequest, res: Response) => {
    try {
        const _id = req.user._id;
        const { noteId } = req.params;
        const userNote = await Note.findOne({ noteId, userId: _id });

        if (!userNote) return res.status(201).json({ message: "No note found!", isNote: false, isDeleted: null });

        const isDeletedStatus = userNote?.trash.isDeleted;

        return res.status(201).json({ message: "Note found", isNote: true, isDeleted: isDeletedStatus });

    } catch (error: any) {
        console.log("Error occured during sending note status", error);
        res.status(500).json({ error: "Internal server error" });
    }
}

const importNote = async (req: AuthenticatedRequest, res: Response) => {
    try {
        const userId = req.user._id;
        const { noteId, titleIV, title, content, contentIV, canvasData, canvasIV, color, pinned } = req.body;

        if (!noteId || !titleIV || !title || !content || !contentIV || !canvasData || !canvasIV || !color || pinned === undefined) {
            return res.status(400).json({ error: "Required fields are missing." });
        };

        const noteIdRegex = /^NOTE-\d{10}$/;

        if (!noteIdRegex.test(noteId)) {
            return res.status(400).json({ error: "Invalid noteId format" });
        }

        // 1️⃣ Extract numeric part
        const numericPart = parseInt(noteId.split("-")[1]);

        if (isNaN(numericPart)) {
            return res.status(400).json({ error: "Invalid noteId format" });
        }

        // 2️⃣ Get current counter
        const counter = await NoteCounter.findOne({ id: "noteId" });

        const currentSeq = counter?.seq || 0;

        // 3️⃣ Validate against counter
        if (numericPart > currentSeq) {
            return res.status(400).json({
                error: `Invalid noteId. Imported ID (${numericPart}) exceeds current sequence (${currentSeq}).`
            });
        }

        // 4️⃣ Upsert note
        const note = await Note.findOneAndUpdate(
            { noteId, userId },
            {
                $set: {
                    titleIV,
                    title,
                    contentIV,
                    content,
                    canvasData,
                    canvasIV,
                    color,
                    pinned,
                    trash: {
                        isDeleted: false,
                        deletedAt: null
                    }
                },
                $setOnInsert: {
                    noteId,
                    userId,
                }
            },
            {
                new: true,
                upsert: true,
                runValidators: true
            }
        );

        return res.status(200).json({
            message: "Note imported successfully",
            note
        });

    } catch (error: any) {
        console.log("error occured during importing notes", error);
        return res.status(500).json({ error: "Internal server error" });
    }
}


// const importExistingNote = async (req: AuthenticatedRequest, res: Response) => {
//     try {
//         const _id = req.user._id;
//         const { noteId, } = req.body;
//     } catch (error: any) {
//         console.log("error occured during importing notes", error);
//         return res.status(500).json({ error: "Internal server error" });
//     }
// }

export default {
    createNote,
    getNote,
    updateNote,
    deleteNote,
    getTrashNotes,
    hardDeleteNote,
    restoreNote,
    getNoteStatus,
    importNote
}