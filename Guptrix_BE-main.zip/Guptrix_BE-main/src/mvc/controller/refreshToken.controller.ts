import { Request, Response } from "express";
import { AccessTokenPayload } from "../../types/jwt";
import jwt, { VerifyErrors, JwtPayload } from 'jsonwebtoken';
import dotenv from 'dotenv';
import User from "../models/user.model";
import { getAccessToken } from "../../helpers/getToken";

dotenv.config();

const handleRefreshToken = async (req: Request, res: Response) => {
    const cookie = req.cookies;
    if (!cookie?.refreshToken) return res.status(403).json({ error: "Refresh token not found. Please login again" });
    const refreshToken = cookie?.refreshToken;

    // Find user with this refresh token
    const user = await User.findOne({ refreshToken });
    if (!user) {
        return res.status(403).json({
            success: false,
            error: "Invalid refresh token. Please login again."
        });
    }
    // Check if user is blocked
    if (user.isBlocked) {
        return res.status(403).json({
            success: false,
            error: "Account is blocked"
        });
    }
    // Check if user is verified
    if (!user.isVerified) {
        return res.status(403).json({
            success: false,
            error: "Account is not verified"
        });
    }

    jwt.verify(
        refreshToken,
        process.env.REFRESH_TOKEN_SECRET as string,
        async (err: VerifyErrors | null, decoded: string | JwtPayload | undefined) => {
            if (err) {
                // Token expired or invalid - clear it from database
                user.refreshToken = null;
                await user.save();

                return res.status(403).json({
                    success: false,
                    error: "Refresh token expired. Please login again."
                });
            }

            const payload = decoded as AccessTokenPayload;

            // const userId = payload.data.userId
            // const Nuser = await User.findOne({ userId })
            // if (payload.data.email)

            //     if (user.email !== payload.data.email) {
            //         return res.status(403).json({ error: "Forbidden" });
            //     }

            // Security check: Ensure the token's email matches the user's email
            if (user.email !== payload.data.email) {
                // Potential token theft - invalidate refresh token
                user.refreshToken = null;
                await user.save();

                return res.status(403).json({
                    success: false,
                    error: "Token validation failed. Please login again."
                });
            }

            // Security check: Ensure the token's userId matches
            if (user.userId.toString() !== payload.data.userId) {
                // Potential token theft - invalidate refresh token
                user.refreshToken = null;
                await user.save();

                return res.status(403).json({
                    success: false,
                    error: "Token validation failed. Please login again."
                });
            }

            const accessToken = getAccessToken(
                payload.data.email,
                payload.data.userId,
                "15m"
            );

            return res.status(201).json({ accessToken });
        }
    );

}

export default {
    handleRefreshToken
};