import { Request, Response } from "express";
import User from "../models/user.model";
import bcrypt from 'bcrypt'
import mongoose from "mongoose";
import { generateOTP } from "../../utils/generateOTP";
import { sendEmail } from "../../utils/mailer";
import { getAccessToken } from "../../helpers/getToken";
import { getRefreshToken } from "../../helpers/getToken";


const register = async (req: Request, res: Response) => {

    const { username, email, password, salt, encryptedAESKey, keyIV, encryptedAESKeyWithRecovery, recoverySalt, recoveryIv } = req.body;

    if (!username || !email || !password || !salt || !encryptedAESKey || !keyIV || !recoveryIv || !recoverySalt || !encryptedAESKeyWithRecovery) return res.status(400).json({ error: 'Required fields are missing' });

    if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters long' });

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(email)) return res.status(400).json({ error: 'Invalid Email' });

    try {
        const emailExists = await User.findOne({ email: new RegExp(email, 'i') });
        if (emailExists) {
            return res.status(400).json({ error: 'Email already exists' });
        };

        const hashedPassword = await bcrypt.hash(password, 10);

        const generatedOTP = generateOTP()

        const otpCode = await bcrypt.hash(generatedOTP, 10);


        await sendEmail(email, "Account verification OTP", "Verify Your Account", generatedOTP);

        const user = new User({
            _id: new mongoose.Types.ObjectId(),
            username,
            email,
            password: hashedPassword,
            otp: {
                code: otpCode,
                expiresAt: new Date(Date.now() + 5 * 60 * 1000) // 5 minutes
            },
            salt,
            encryptedAESKey,
            keyIV,
            recoveryIv,
            recoverySalt,
            encryptedAESKeyWithRecovery
        });

        await user.save();

        return res.status(201).json({
            message: "User registered successfully!",
            userId: user.userId,
        });


    } catch (err) {
        console.error('Error during registration', err);
        return res.status(500).json({
            error: "Server error. Please try again later."
        });
    };
};

const verifyOTP = async (req: Request, res: Response) => {
    const { userId, otp } = req.body;

    if (!userId || !otp) {
        return res.status(400).json({ error: "Required fields are missing" });
    };

    try {
        const user = await User.findOne({ userId });

        if (!user) return res.status(404).json({ error: "User not found." });

        if (!user.otp || !user.otp.code) return res.status(400).json({ error: "OTP not generated" });

        // check expiration
        if (new Date() > user.otp.expiresAt) return res.status(400).json({ error: "OTP expired" });

        // otp match
        const OTPMatch = await bcrypt.compare(otp, user.otp.code);
        if (!OTPMatch) return res.status(400).json({ error: "Invalid OTP" });

        user.isVerified = true;
        user.otp = null;
        await user.save();

        return res.status(200).json({
            success: true,
            message: "OTP verified successfully",
            isVerified: user.isVerified
        });

    } catch (err) {
        console.error("Error occured during verifying", err);
        return res.status(500).json({ error: "Internal server error. Please try again later." });
    }
}
const resendOTP = async (req: Request, res: Response) => {
    const { userId } = req.body;
    try {
        const user = await User.findOne({ userId });

        if (!user) {
            return res.status(404).json({ error: "User not found" });
        }

        if (!user.otp || !user.otp.code) {
            return res.status(400).json({ error: "OTP not generated" });
        }

        // Fix: Check if OTP is still valid (hasn't expired yet)
        // If current time is BEFORE expiry, OTP is still valid - don't allow resend
        if (new Date() < user.otp.expiresAt) {
            return res.status(429).json({
                error: "Please wait 5 minutes before requesting another code"
            });
        }

        const generatedOTP = generateOTP();
        const otpCode = await bcrypt.hash(generatedOTP, 10);

        await sendEmail(user.email, "OTP", "New verification code for your account", generatedOTP);

        user.otp = {
            code: otpCode,
            expiresAt: new Date(Date.now() + 5 * 60 * 1000) // 5 minutes
        };

        await user.save();

        // Fix: Return success response
        return res.status(200).json({
            message: "OTP sent successfully. Please check your email."
        });

    } catch (err) {
        console.log("Error occurred during resend otp", err);
        return res.status(500).json({
            error: "Internal server error. Please try again later."
        });
    }
};

const login = async (req: Request, res: Response) => {
    const { email, password, rememberMe } = req.body;

    // Validate required fields
    if (!email || !password) {
        return res.status(400).json({ error: "Required fields are missing!" });
    }

    try {
        // Find user with password field
        const user = await User.findOne({ email }).select('+password +salt +encryptedAESKey +keyIV');

        if (!user) {
            return res.status(401).json({ error: "Invalid credentials" });
        }

        // Check if account is blocked BEFORE password verification
        // This prevents blocked users from knowing if their password is correct
        if (user.isBlocked) {
            return res.status(403).json({ error: "Account is blocked" });
        }

        // Verify password
        const isPasswordValid = await bcrypt.compare(password, user.password);

        if (!isPasswordValid) {
            return res.status(401).json({ error: "Invalid credentials" });
        }

        // Check if user is verified
        if (!user.isVerified) {
            const generatedOTP = generateOTP();
            const otpCode = await bcrypt.hash(generatedOTP, 10);

            await sendEmail(user.email, "Verify your account", "New verification code for your account", generatedOTP);

            user.otp = {
                code: otpCode,
                expiresAt: new Date(Date.now() + 5 * 60 * 1000) // 5 minutes
            };

            await user.save();

            return res.status(403).json({
                error: "Account is not verified. Please check your email for verification code.",
                email: user.email,
                userId: user.userId,
            });
        }

        // Generate tokens with appropriate expiration
        const accessToken = getAccessToken(
            user.email,
            user.userId.toString(),
            rememberMe ? "1h" : "15m"
        );

        const refreshToken = getRefreshToken(
            user.email,
            user.userId.toString(),
            rememberMe ? "30d" : "7d"
        );


        // Set refresh token as httpOnly cookie
        res.cookie('refreshToken', refreshToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: rememberMe ? 30 * 24 * 60 * 60 * 1000 : 7 * 24 * 60 * 60 * 1000
        });

        // store refresh token to db
        user.refreshToken = refreshToken;
        await user.save();


        // Return success response with user data
        return res.status(200).json({
            success: true,
            message: "Login successful",
            accessToken,
            salt: user.salt,
            encryptedAESKey: user.encryptedAESKey,
            keyIV: user.keyIV,
        });

    } catch (err) {
        console.log("Error occured during login", err);
        return res.status(500).json({ error: "Internal server error. Please try again later." })
    }
}

const requestPasswordReset = async (req: Request, res: Response) => {
    const { email } = req.body;

    if (!email) return res.status(400).json({ error: "Required fields are missing" });

    try {
        const user = await User.findOne({ email });
        if (!user) return res.status(200).json({ message: "If an account exists, an OTP has been sent." });

        const generatedOTP = generateOTP()

        const otpCode = await bcrypt.hash(generatedOTP, 10);

        await sendEmail(email, "Your Password Reset OTP", "Password Reset Verification", generatedOTP);

        user.otp = {
            code: otpCode,
            expiresAt: new Date(Date.now() + 5 * 60 * 1000) // 5 minutes
        }

        await user.save();

        return res.status(200).json({ message: "OTP send successfully!" });

    } catch (error) {
        console.log("Error occured durign request password reset", error);
        return res.status(500).json({ error: "Internal server error" });
    }
}

const verifyOtpAndResetPassword = async (req: Request, res: Response) => {
    const { email, otp, newPassword, salt, encryptedAESKey, keyIV, recoverySalt, encryptedAESKeyWithRecovery, recoveryIv } = req.body;

    if (!email || !otp || !newPassword || !salt || !encryptedAESKey || !keyIV) return res.status(400).json({ error: "Required fields are missing" });

    try {
        const user = await User.findOne({ email }).select('+password');
        if (!user) return res.status(404).json({ error: "Invalid credentials" });

        if (!user.otp || !user.otp.code) return res.status(400).json({ error: "OTP not generated" });

        // check expiration
        if (new Date() > user.otp.expiresAt) return res.status(400).json({ error: "OTP expired" });

        // otp match
        const OTPMatch = await bcrypt.compare(otp, user.otp.code);
        if (!OTPMatch) return res.status(400).json({ error: "Invalid OTP" });

        const isPasswordSame = await bcrypt.compare(newPassword, user.password);
        if (isPasswordSame) return res.status(400).json({ error: "Enter unique password" });

        const hashedNewPassword = await bcrypt.hash(newPassword, 10);

        user.password = hashedNewPassword;
        user.otp = null;
        user.salt = salt;
        user.encryptedAESKey = encryptedAESKey;
        user.keyIV = keyIV;

        if (recoveryIv && encryptedAESKeyWithRecovery && recoverySalt) {
            user.recoveryIv = recoveryIv;
            user.recoverySalt = recoverySalt;
            user.encryptedAESKeyWithRecovery = encryptedAESKeyWithRecovery;
        }

        await user.save();

        return res.status(200).json({
            success: true,
            message: "Password reset successful",
            isVerified: user.isVerified
        });

    } catch (err) {
        console.error("Error occured during forgot password", err);
        return res.status(500).json({ error: "Internal server error. Please try again later." });
    }
}

// recovery-login send recovery credentials
const getRecoveryCreds = async (req: Request, res: Response) => {
    try {
        const { email } = req.params;
        if (!email) return res.status(400).json({ error: 'Required Fields are missing' });

        const user = await User.find({ email }).select('recoverySalt encryptedAESKeyWithRecovery recoveryIv -_id');
        return res.status(200).json({
            message: 'Sent successfully',
            user
        });
    } catch (error: any) {
        console.log("Error during sending recovery credentials", error);
        return res.status(500).json({ error: "Internal server error" });
    }
}

const password_reset = async (req: Request, res: Response) => {
    const { email, oldPassword, newPassword } = req.body;

    if (!oldPassword || !newPassword) return res.status(400).json({ error: "Required fields are missing" });
    try {
        const user = await User.findOne({ email }).select('+password');
        if (!user) return res.status(401).json({ error: "Invalid credentials" });

        if (user.isBlocked) {
            return res.status(403).json({ error: "Account is blocked" });
        }

        const isPasswordValid = await bcrypt.compare(oldPassword, user.password);
        if (!isPasswordValid) return res.status(401).json({ error: "Invalid credentials" });

        // Check if user is verified
        if (!user.isVerified) {
            return res.status(403).json({
                error: "Account is not verified.",
                userId: user.userId
            });
        }

        const newHashedPassword = await bcrypt.hash(newPassword, 10);
        user.password = newHashedPassword;
        await user.save();

        return res.status(204).json({ message: "Password updated successfully!" });

    } catch (err) {
        console.log("Error occured during reseting password");
        return res.status(500).json({ error: "Internal server error. Please try again later." });
    }
}

const logout = async (req: Request, res: Response) => {
    const cookies = req.cookies;

    // 1. If NO cookie exists, we are already "logged out"
    if (!cookies?.refreshToken) {
        return res.sendStatus(204);
    }

    const refreshToken = cookies.refreshToken;

    // 2. Find the user with this token
    const user = await User.findOne({ refreshToken });

    // 3. If token exists in browser but not in DB, just clear the cookie
    if (!user) {
        res.clearCookie('refreshToken', {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            path: '/' // Recommended to ensure the correct cookie is targeted
        });
        return res.sendStatus(204);
    }

    // 4. Delete refresh token from DB (MUST await this)
    user.refreshToken = ""; // or null, depending on your schema
    await user.save();

    // 5. Clear the cookie from the browser
    res.clearCookie('refreshToken', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        path: '/'
    });

    return res.sendStatus(204);
};

export default {
    register,
    verifyOTP,
    resendOTP,
    login,
    requestPasswordReset,
    verifyOtpAndResetPassword,
    password_reset,
    logout,
    getRecoveryCreds
}