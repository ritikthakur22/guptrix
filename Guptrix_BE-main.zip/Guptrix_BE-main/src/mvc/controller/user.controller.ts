import { AuthenticatedRequest } from "@/types/request"
import { Response } from "express"
import User from "../models/user.model";

const getCurrentUser = async (req: AuthenticatedRequest, res: Response) => {
    try {
        const userId = req.user._id;
        const user = await User.find(userId).select('-password -otp -isVerified -isBlocked -refreshToken');

        return res.status(200).json({ user });
    } catch (error: any) {
        console.log("Error returning current user data", error);
        return res.status(500).json({ error: "Internal server Error" });
    }
}


export default {
    getCurrentUser,
}