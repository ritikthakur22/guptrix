import type { NextFunction, Response, Request } from "express";
import jwt, { TokenExpiredError } from "jsonwebtoken";
import User, { UserModel } from "../models/user.model";

const jwtVerify = async (req: Request, res: Response, next: NextFunction) => {
    try {
        // get the access token from the header authoization type bearer
        const authHeader = req.headers.authorization as string;

        // it comes in 'Bearer token' so it will check wheather the incoming style 
        if (!authHeader?.startsWith('Bearer ')) return res.status(401).json({ message: "Unauthorized" });

        // it will extract the token from the header
        const token = authHeader.split(' ')[1];

        if (!token) return res.status(401).json({ messsage: "Unauthorized" });

        jwt.verify(token, process.env.ACCESS_TOKEN_SECRET as string, async (err, decoded: any) => {
            if (err) return res.status(403).json({ message: "Forbidden", err });

            const userData = decoded?.data?.email

            const user = await User.findOne({ email: userData });

            if (!user) return res.status(403).json({ message: "User not found" });
            // req.body.currentUserId = user._id;
            // (req as Request & { user: UserModel }).user = user;  // type declaration is performed in express.d.ts so not needed here
            // req.user = user; // express.d.ts is not working

            (req as any).currentUserId = user._id;
            (req as any).user = user;

            next();
        })

    } catch (error: any) {
        if (error.name === "TokenExpiredError") {
            return res.status(401).json({ message: "Token expired" });
        }
        if (error.name === "JsonWebTokenError") {
            return res.status(403).json({ message: "Invalid token" });
        }
        console.error(error);
        return res.status(500).json({ message: "Internal server error" });
    };
}

export default jwtVerify;