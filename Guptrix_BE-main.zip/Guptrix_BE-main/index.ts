import express, { Express } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import authRoute from "./src/mvc/router/auth.route"
import cookieParser from 'cookie-parser';
import refreshTokenRoute from "./src/mvc/router/refreshToken.route"
import jwtVerify from './src/mvc/middlewares/auth.middleware';
import noteRoute from './src/mvc/router/note.route'
import userRoute from './src/mvc/router/user.route'

dotenv.config();
const PORT = 4000;

const app: Express = express();

const allowedOrigin = [
    'http://localhost:3000',
    'https://guptrix.netlify.app'
]

const corsOptions = {
    origin: function (origin: string | undefined, callback: (err: Error | null, allowed?: boolean) => void) {
        if (!origin) return callback(null, true);

        if (allowedOrigin.indexOf(origin) !== -1) {
            callback(null, true);
        }
        else {
            callback(new Error('Not allowed by CORS'));
        }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    exposedHeaders: ['set-cookie']
}

app.use(cors(corsOptions));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(cookieParser());

// routes
app.use('/api', authRoute);
app.use('/refresh', refreshTokenRoute);
app.use('/note', jwtVerify, noteRoute);
app.use('/api/user', jwtVerify, userRoute);

app.get('/', (req, res) => {
    res.send('Server is Calling.');
});

// 404 error fallback
app.use((req, res) => {
    res.status(404).send({
        error: true,
        code: 404,
        message: 'API not found',
    });
});

// db + server
mongoose.set('strictQuery', false);
const mongoURL = process.env.DATABASE_URL;

if (!mongoURL) {
    console.log('Database URL is not set in .env');
    process.exit(1);
};

async function startServer() {
    try {
        await mongoose.connect(mongoURL as string);
        console.log('Database connected successfully!');

        app.listen(PORT, () => {
            console.log(`⚡️ [server]: Server is running at http://localhost:${PORT}`);
        });
    } catch (err) {
        console.error('Database connection failed', err);
        process.exit(1); // stop server if DB connection fails
    };
};

startServer();

export default app;