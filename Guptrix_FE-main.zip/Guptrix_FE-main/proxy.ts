import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function proxy(req: NextRequest) {
    const token = req.cookies.get("token")?.value;
    const refresh = req.cookies.get("rft")?.value;
    const pathname = req.nextUrl.pathname;
    const { searchParams } = req.nextUrl;

    // ---- PUBLIC ROUTES ----
    const publicRoutes = ["/auth/login", "/auth/signup", "/auth/verify-otp", "/", "/auth/forgot-password", "/auth/reset-password"];

    const isPublicRoute = publicRoutes.includes(pathname);

    // 👉 If user is logged in AND trying to access public page → redirect to dashboard
    if (isPublicRoute && token && searchParams.get("expired") !== "true") {
        return NextResponse.redirect(new URL("/dashboard", req.url));
    }

    // ---- PRIVATE ROUTES ----
    const privateRoutes = ["/dashboard", "/card", "/trash"];

    const isTryingPrivate = privateRoutes.some((pr) =>
        pathname.startsWith(pr)
    );

    // 👉 If user is NOT logged in and trying to access private pages → redirect to login
    if (isTryingPrivate && !token && !refresh) {
        return NextResponse.redirect(new URL("/auth/login", req.url));
    }

    return NextResponse.next();

}

export const config = {
    matcher: [
        "/dashboard/:path*",
        "/card/:path*",
        "/trash/:path*",
        "/auth/login",
        "/auth/signup",
        "/auth/verify-otp",
        "/auth/forgot-password",
        "/auth/reset-password",
        "/",
    ],
};