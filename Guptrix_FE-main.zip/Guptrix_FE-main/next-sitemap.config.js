module.exports = {
  siteUrl: "https://guptrix.netlify.app",
  generateRobotsTxt: true,
};
