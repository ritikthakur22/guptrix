import { NextResponse } from 'next/server';
import axios from 'axios';
import { REFRESH_TOKEN } from '../../../lib/api/url-helpers';
import { cookies } from 'next/headers';

export async function GET() {
    try {
        const cookieStore = await cookies();
        
        // 1. Get the 'rft' cookie that you stored during login
        const refreshToken = cookieStore.get('rft')?.value;

        if (!refreshToken) {
            return NextResponse.json({ success: false, error: "No refresh token" }, { status: 401 });
        }

        // 2. Call your Node.js backend
        // We manually pass the cookie in the headers because server-to-server 
        // calls don't automatically forward browser cookies.
        const response = await axios.get(REFRESH_TOKEN, {
            headers: {
                Cookie: `refreshToken=${refreshToken}` // Match the name your backend expects
            },
            withCredentials: true,
        });

        const newAccessToken = response.data?.accessToken;

        if (response.status === 201 && newAccessToken) {
            // 3. Create the response
            const nextResponse = NextResponse.json({ 
                success: true,
                message: "Token refreshed" 
            });

            // 4. Update the 'token' (Access Token) cookie in the browser
            nextResponse.cookies.set('token', newAccessToken, {
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                sameSite: 'strict',
                maxAge: 15 * 60, // 15 minutes
                path: '/',
            });

            return nextResponse;
        }

        return NextResponse.json({ success: false }, { status: 401 });

    } catch (error: any) {
        console.error("Refresh Error:", error.response?.data || error.message);
        return NextResponse.json(
            { success: false, error: error.response?.data?.error || 'Refresh failed' },
            { status: error.response?.status || 500 }
        );
    }
}