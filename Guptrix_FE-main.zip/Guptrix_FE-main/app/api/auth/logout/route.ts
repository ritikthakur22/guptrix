import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';

export async function POST() {
    try {
        const cookieStore = await cookies();

        // Call backend to clear refreshToken and invalidate session
        await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth/logout`, {
            method: 'POST',
            credentials: 'include', // Send refreshToken cookie to backend
            headers: {
                'Content-Type': 'application/json'
            }
        });

        // Clear the accessToken (stored as 'token') from Next.js cookies
        cookieStore.delete('token');
        cookieStore.delete('rft');

        return NextResponse.json({
            success: true,
            message: 'Logged out successfully'
        });
    } catch (error) {
        console.error('Logout error:', error);

        // Even if backend call fails, clear the token cookie
        const cookieStore = await cookies();
        cookieStore.delete('token');
        cookieStore.delete('rft');

        return NextResponse.json(
            { success: true, message: 'Logged out' },
            { status: 200 }
        );
    }
}
