import { error } from 'console';
import { cookies } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
    try {
        const body = await req.json();

        // 👇 Call YOUR Node.js backend API
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'include',
            body: JSON.stringify(body),
        });

        const data = await response.json();

        // ✅ Check if login was successful (adjust based on your API response structure)
        if (response.ok && data.accessToken) {
            const cookieStore = await cookies();
            const rememberMe = body.rememberMe || false;

            // Calculate access token expiry
            const accessTokenMaxAge = rememberMe
                ? 60 * 60        // 1 hour
                : 15 * 60;       // 15 minutes


            // Set httpOnly cookie on server side
            cookieStore.set('token', data.accessToken, {
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                sameSite: 'strict',
                maxAge: accessTokenMaxAge,
                path: '/',
            });

            // 1. Use getSetCookie() to get the array of all cookies from Node.js
            const setCookieHeaders = response.headers.getSetCookie();

            if (setCookieHeaders && setCookieHeaders.length > 0) {

                // 2. Find the specific cookie string for refreshToken
                const refreshCookieString = setCookieHeaders.find(cookie =>
                    cookie.startsWith('refreshToken=')
                );

                if (refreshCookieString) {
                    // 3. Extract just the value (the part between '=' and ';')
                    // Example: "refreshToken=header.payload.signature; Path=/; HttpOnly"
                    const refreshTokenValue = refreshCookieString
                        .split(';')[0]      // "refreshToken=header.payload.signature"
                        .split('=')[1];     // "header.payload.signature"

                    // 4. Set it in the Browser
                    cookieStore.set('rft', refreshTokenValue, {
                        httpOnly: true,
                        secure: process.env.NODE_ENV === 'production',
                        sameSite: 'strict',
                        maxAge: rememberMe ? 30 * 24 * 60 * 60 : 7 * 24 * 60 * 60,
                        path: '/',
                    });
                }
            }

            // Return user data (without token)
            return NextResponse.json({
                success: true,
                data: {
                    message: data.message || data.data?.message,
                },
                salt: data.salt,
                encryptedAESKey: data.encryptedAESKey,
                keyIV: data.keyIV,
            });
        }

        // Login failed
        return NextResponse.json(
            {
                success: false,
                error: data.message || data.error || 'Login failed',
                email: data.email,
                userId: data.userId
            },
            { status: response.status || 401 }
        );
    } catch (error: any) {
        console.error('Login API error:', error);
        return NextResponse.json(
            { success: false, error: error.message || 'An error occurred' },
            { status: 500 }
        );
    }
}