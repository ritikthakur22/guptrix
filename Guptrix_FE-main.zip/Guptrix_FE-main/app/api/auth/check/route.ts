import { REFRESH_TOKEN } from "@/app/lib/api/url-helpers";
import { timeStamp } from "console";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";


export async function GET() {
    try {
        const cookieStore = await cookies();
        const token = cookieStore.get('token')?.value;
        const refresh = cookieStore.get('rft')?.value;

        if (!!token) {
            return NextResponse.json({ authenticated: true, timestamp: new Date().toISOString() })
        }

        if (!token && !!refresh) {
            try {
                const res = await fetch(REFRESH_TOKEN, {
                    method: 'GET',
                    headers: {
                        cookie: `refreshToken=${refresh}`
                    },
                });

                if (!res.ok) throw new Error("Refresh Fail");
                const data = await res.json();

                cookieStore.set('token', data.accessToken, {
                    httpOnly: true,
                    secure: process.env.NODE_ENV === 'production',
                    sameSite: 'strict',
                    maxAge: 15 * 60,
                    path: '/',
                })

                return NextResponse.json({ authenticated: true, timeStamp: new Date().toISOString() })

            } catch (error: any) {
                console.error("Error occured during check");
            }
        }
        
        return NextResponse.json({ authenticated: false, timestamp: new Date().toISOString() })
        
    } catch (error) {
        console.error("Auth check error");
        return NextResponse.json(
            { authenticated: false },
            { status: 200 }
        );
    }

}