import { cookies } from "next/headers"
import TrashPage from "./TrashClient"
import { fetchCachedTrashNotes } from "../lib/serverCache";
import NoteHydrator from "../components/provider/NoteHydrator";

const page = async () => {
  const cookieStore = await cookies();
  const token = cookieStore.get('token')?.value;

  const trashNote = await fetchCachedTrashNotes(token as string);
  return (
    <div className="min-h-screen bg-[hsl(var(--background))]">
      {/* <NoteHydrator trashNotes={trashNote} /> */}
      <TrashPage trashNotesList={trashNote} />
    </div>
  )
}

export default page
