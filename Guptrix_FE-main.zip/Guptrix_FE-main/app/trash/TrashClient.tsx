"use client";

import { NotesGrid } from "../components/NotesGrid";
import { useNoteStore } from "../store/note/note.store";
import { hardDeleteNote, restoreNote } from "../lib/api/note";
import { toast } from "sonner";
import { useEffect, useState } from "react";
import { retrieveAESKey } from "../lib/crypto-key-manager";
import PasswordAsk from "../components/PasswordAsk";
import { EncryptedNote } from "../store/note/note.types";
import NoteHydrator from "../components/provider/NoteHydrator";

interface TrashPageProps {
    trashNotesList: EncryptedNote[] | null;
}

const TrashPage = ({ trashNotesList }: TrashPageProps) => {
    const notes = useNoteStore((state) => state.notes) || [];
    const trashNotes = useNoteStore((state) => state.trashNotes) || [];
    const setNotes = useNoteStore((state) => state.setNotes);
    const setTrashNotes = useNoteStore((state) => state.setTrashNotes);
    const removeTrashNoteStore = useNoteStore((state) => state.removeTrashNote);
    const [aesKey, setAesKey] = useState<CryptoKey | null>(null);
    const [showPasswordDialog, setShowPasswordDialog] = useState<boolean>(false);




    // load aes
    useEffect(() => {

        const loadKey = async () => {
            const key = await retrieveAESKey();
            setAesKey(key);
            if (key) {
                setAesKey(key);
            } else {
                setShowPasswordDialog(true);
            }
        };
        loadKey();
    }, []);


    if (!aesKey) {
        return (
            <PasswordAsk
                open={showPasswordDialog}
                onClose={() => setShowPasswordDialog(false)}
                onUnlock={(key) => {
                    setAesKey(key);
                    setShowPasswordDialog(false);
                }}
            />
        )
    }


    const handlePermanentDelete = async (noteId: string) => {
        // Find the note
        const noteToDelete = trashNotes.find((n) => n.noteId === noteId);
        if (!noteToDelete) return;

        // Optimistic update
        const previousTrashNotes = [...trashNotes];
        removeTrashNoteStore(noteId);

        try {
            const res = await hardDeleteNote(noteId);

            if (res.success) {
                toast.success("Note permanently deleted");
            } else {
                // Revert on failure
                setTrashNotes(previousTrashNotes);
                toast.error(res.error || "Failed to delete note");
            }
        } catch (err) {
            // Revert on error
            setTrashNotes(previousTrashNotes);
            toast.error("Failed to delete note");
        }
    };

    const handleRestoreNote = async (noteId: string) => {
        // Find the note in trash
        const noteToRestore = trashNotes.find((n) => n.noteId === noteId);
        if (!noteToRestore) return;

        // Optimistic update: remove from trash
        const previousTrashNotes = [...trashNotes];
        removeTrashNoteStore(noteId);

        try {
            const res = await restoreNote(noteId);

            if (res.success) {
                // Add back to active notes
                const restoredNote = {
                    ...noteToRestore,
                    trash: {
                        isDeleted: false,
                        deletedAt: null,
                    },
                };
                setNotes([restoredNote, ...notes]);
                toast.success("Note restored");
            } else {
                // Revert on failure
                setTrashNotes(previousTrashNotes);
                toast.error(res.error || "Failed to restore note");
            }
        } catch (err) {
            // Revert on error
            setTrashNotes(previousTrashNotes);
            toast.error("Failed to restore note");
        }
    };

    return (
        <div className="min-h-screen bg-[hsl(var(--background))]">
            <NoteHydrator trashNotes={trashNotesList} />
            <NotesGrid
                notes={trashNotes}
                isTrash={true}
                onDeleteNote={handlePermanentDelete}
                onRestoreNote={handleRestoreNote}
            />
        </div>
    );
};

export default TrashPage;