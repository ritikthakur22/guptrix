import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "./components/ThemeProvider";
import ReactQueryprovider from "./lib/react-query-provider";
import { ToastProvider } from "./components/ToastProvider";
import LayoutContent from "./components/LayoutWrapper";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Guptrix",
  description: "Guptrix is a zero-knowledge, end-to-end encrypted notes app built for privacy and security.",
  verification: {
    google: "gtigEpN3km3JEn98I9XOskRfrqHKlTAbIorldNrnck4",
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {


  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <ReactQueryprovider>
          <ThemeProvider defaultTheme="dark" storageKey="notes-ui-theme">
            <ToastProvider />
            <LayoutContent>
              {children}
            </LayoutContent>
          </ThemeProvider>
        </ReactQueryprovider>
      </body>
    </html>
  );
}
