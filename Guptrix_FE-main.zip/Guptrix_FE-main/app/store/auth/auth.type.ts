export interface IUser {
    _id: string;
    username: string;
    email: string;
    salt: string;
    encryptedAESKey: string;
    keyIV: string;
    userId: string;
}


export interface UserState {
    user: IUser | null;

    setUser: (user: IUser) => void;
    updateUser: (updateUser: Partial<IUser>) => void;
    clearUser: () => void;
}