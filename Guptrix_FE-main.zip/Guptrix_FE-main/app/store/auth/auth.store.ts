import { create } from 'zustand';
import { UserState } from './auth.type';

export const useUser = create<UserState>((set) => ({
    user: null,

    setUser: (user) => set({ user }),

    updateUser: (updatedFields) =>
        set((state) => ({
            user: state.user
                ? { ...state.user, ...updatedFields }
                : null,
        })),

    clearUser: () => set({
        user: null,
    }),
}))