export interface TrashInfo {
    isDeleted: boolean;
    deletedAt: string | null;
}

export interface Note {
    noteId: string;
    title: string;           // This is the DECRYPTED title (for display)
    content?: string;         // This is the DECRYPTED content (for display)
    titleIV: string;         // IV used for title encryption
    contentIV?: string;       // IV used for content encryption
    canvasData?: string;   // decrypted Excalidraw JSON string
    canvasIV?: string;
    color: string;
    pinned: boolean;
    trash: TrashInfo;
    createdAt: string;
    updatedAt: string;
}

// This is what the backend sends (encrypted data)
export interface EncryptedNote {
    noteId: string;
    title: string;           // This is encrypted ciphertext
    titleIV: string;
    content?: string;         // This is encrypted ciphertext
    contentIV?: string;
    canvasData?: string;   // encrypted ciphertext
    canvasIV?: string;
    color: string;
    pinned: boolean;
    trash: TrashInfo;
    createdAt: string;
    updatedAt: string;
}