import { create } from 'zustand';
import { Note } from './note.types';

interface NoteState {
    notes?: Note[] | null;       // Active notes
    trashNotes?: Note[] | null;  // Deleted / trashed notes

    // Setters
    setNotes: (notes: Note[]) => void;
    setTrashNotes: (trashNotes: Note[]) => void;

    // Mutations
    updateNote: (noteId: string, updatedNote: Partial<Note>) => void;
    updateTrashNote: (noteId: string, updatedNote: Partial<Note>) => void;
    removeNote: (noteId: string) => void;
    removeTrashNote: (noteId: string) => void;

    // Clear
    clearNotes: () => void;
    clearTrashNotes: () => void;
}

export const useNoteStore = create<NoteState>((set) => ({
    notes: [],
    trashNotes: [],

    setNotes: (notes) => set({ notes }),
    setTrashNotes: (trashNotes) => set({ trashNotes }),
    // setNotes: (newNotes) => set({ notes: newNotes }), // ⬅️ This is safe
    // setTrashNotes: (newTrashNotes) => set({ trashNotes: newTrashNotes }),

    updateNote: (noteId, updatedNote) =>
        set((state) => ({
            notes: state.notes && (state.notes.map((note) =>
                note.noteId === noteId ? { ...note, ...updatedNote } : note
            )),
        })),

    updateTrashNote: (noteId, updatedNote) =>
        set((state) => ({
            trashNotes: state.trashNotes && (state.trashNotes.map((note) =>
                note.noteId === noteId ? { ...note, ...updatedNote } : note
            )),
        })),

    removeNote: (noteId) =>
        set((state) => ({
            notes: state.notes && (state.notes.filter((note) => note.noteId !== noteId)
            )
        })),

    removeTrashNote: (noteId) =>
        set((state) => ({
            trashNotes: state.trashNotes && (state.trashNotes.filter((note) => note.noteId !== noteId)
            )
        })),

    clearNotes: () => set({ notes: [] }),
    clearTrashNotes: () => set({ trashNotes: [] }),
}));
