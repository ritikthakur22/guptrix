import { cookies } from "next/headers";
// import NoteHydrator from "../components/provider/NoteHydrator";
import DashboardClient from "./DashboardClient";
import { fetchCachedNotes } from "../lib/serverCache";

const DashboardPage = async () => {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;

  const notes = await fetchCachedNotes(token as string);

  return (
    <div className="min-h-screen bg-[hsl(var(--background))]">
      {/* <NoteHydrator notes={notes} /> */}
      <DashboardClient note={notes} />
    </div>
  );
};

export default DashboardPage;
