"use client";

import { NotesGrid } from "../components/NotesGrid";
import { toast } from "sonner";
import { createNote, deleteNote, importNote, restoreNote, updateNote } from "../lib/api/note";
import { useRouter } from "next/navigation";
import { useNoteStore } from "@/app/store/note/note.store";
import { retrieveAESKey } from "../lib/crypto-key-manager";
import { useEffect, useState } from "react";
import PasswordAsk from "../components/PasswordAsk";
import NoteHydrator from "../components/provider/NoteHydrator";
import { EncryptedNote } from "../store/note/note.types";
import { encryptNote } from "../lib/crypto.service";

interface DashboardClientProps {
    note: EncryptedNote[] | null;
}

const DashboardClient = ({ note }: DashboardClientProps) => {
    const [aesKey, setAesKey] = useState<CryptoKey | null>(null);
    const [showPasswordDialog, setShowPasswordDialog] = useState<boolean>(false);
    const router = useRouter();

    // Get notes from Zustand
    const notes = useNoteStore((s) => s.notes) || [];
    const trashNotes = useNoteStore((s) => s.trashNotes) || [];

    // Store actions
    const setNotes = useNoteStore((s) => s.setNotes);
    const setTrashNotes = useNoteStore((s) => s.setTrashNotes);
    const updateNoteStore = useNoteStore((s) => s.updateNote);
    const removeNoteStore = useNoteStore((s) => s.removeNote);
    const removeTrashNoteStore = useNoteStore((s) => s.removeTrashNote);


    // load aes
    useEffect(() => {

        const loadKey = async () => {
            const key = await retrieveAESKey();
            setAesKey(key);
            if (key) {
                setAesKey(key);
            } else {
                setShowPasswordDialog(true);
            }
        };
        loadKey();
    }, []);


    if (!aesKey) {
        return (
            <PasswordAsk
                open={showPasswordDialog}
                onClose={() => setShowPasswordDialog(false)}
                onUnlock={(key) => {
                    setAesKey(key);
                    setShowPasswordDialog(false);
                }}
            />
        )
    }

    // --------------------------
    // Handlers
    // --------------------------


    const handleDeleteNote = async (noteId: string) => {
        const noteToTrash = notes.find((n) => n.noteId === noteId);
        if (!noteToTrash) return;

        const previousNotes = [...notes];
        removeNoteStore(noteId); // Optimistic remove

        try {
            const res = await deleteNote(noteId);

            if (res.success) {
                // ✅ Fix 1: Use a functional update or check for existence in Trash
                setTrashNotes([
                    ...trashNotes.filter(n => n.noteId !== noteId),
                    {
                        ...noteToTrash,
                        trash: { isDeleted: true, deletedAt: new Date().toISOString() }
                    }
                ]);

                toast.warning("Note moved to trash", {
                    description: "Note will be auto-deleted from trash after 30 days.",
                    action: {
                        label: "Undo",
                        onClick: async () => {
                            try {
                                const restoreRes = await restoreNote(noteId);
                                if (restoreRes.success) {
                                    removeTrashNoteStore(noteId);

                                    // ✅ Fix 2: THE CRITICAL FIX
                                    // Re-fetch the CURRENT state of notes from the store 
                                    // to ensure we don't use a stale "notes" variable
                                    const currentNotes = useNoteStore.getState().notes || [];

                                    // Only add if it's not already there
                                    if (!currentNotes.some(n => n.noteId === noteId)) {
                                        setNotes([...currentNotes, noteToTrash]);
                                    }

                                    toast.success("Note restored");
                                }
                            } catch (err) {
                                toast.error("Failed to restore note");
                            }
                        },
                    },
                });
            } else {
                setNotes(previousNotes);
                toast.error(res.error || "Failed to delete note");
            }
        } catch (err) {
            setNotes(previousNotes);
            toast.error("Failed to delete note");
        }
    };

    const handleDownloadNote = async (noteId: string) => {
        if (!note) return;

        const noteToExport = note.find((n) => n.noteId === noteId);
        if (!noteToExport) {
            toast.error("Note not found");
            return;
        }

        try {
            const exportPayload = {
                type: "guptrix-notes",
                version: 1,
                exportedAt: new Date().toISOString(),
                note: {
                    noteId: noteToExport.noteId,
                    title: noteToExport.title,
                    titleIV: noteToExport.titleIV,
                    content: noteToExport.content,
                    contentIV: noteToExport.contentIV,
                    canvasData: noteToExport.canvasData,
                    canvasIV: noteToExport.canvasIV,
                    color: noteToExport.color,
                    pinned: noteToExport.pinned,
                    createdAt: noteToExport.createdAt,
                    updatedAt: noteToExport.updatedAt,
                },
            };

            // 🔐 Encrypt entire payload
            const encrypted = await encryptNote(
                JSON.stringify(exportPayload),
                aesKey,
            );

            const finalExport = {
                type: "guptrix-export",
                encrypted: true,
                iv: encrypted.iv,
                data: encrypted.ciphertext
            };

            const blob = new Blob(
                [JSON.stringify(finalExport)],
                { type: "application/octet-stream" }
            );

            const url = URL.createObjectURL(blob);

            const a = document.createElement("a");
            a.href = url;
            a.download = `Guptrix-${noteId}.gnote`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);

            URL.revokeObjectURL(url);

            toast.success("Encrypted note downloaded");
        } catch (err) {
            console.error(err);
            toast.error("Failed to download note");
        }
    };

    const handlePinNote = async (noteId: string) => {
        const note = notes.find((n) => n.noteId === noteId);
        if (!note) return;

        const newPinned = !note.pinned;

        // Optimistic update
        const previousNotes = [...notes];
        updateNoteStore(noteId, { pinned: newPinned });

        try {
            // Backend update
            const res = await updateNote({ noteId, userAESKey: aesKey, pinned: newPinned });

            if (!res.success) {
                // Revert on failure
                setNotes(previousNotes);
                toast.error("Failed to pin note");
            }
        } catch (err) {
            // Revert on error
            setNotes(previousNotes);
            toast.error("Failed to pin note");
        }
    };

    const handleColorChange = async (noteId: string, color: string) => {
        // Optimistic update
        const previousNotes = [...notes];
        updateNoteStore(noteId, { color });

        try {
            // Backend update
            const res = await updateNote({ noteId, userAESKey: aesKey, color });

            if (!res.success) {
                // Revert on failure
                setNotes(previousNotes);
                toast.error("Failed to change color");
            }
        } catch (err) {
            // Revert on error
            setNotes(previousNotes);
            toast.error("Failed to change color");
        }
    };

    const handleAddNote = async (title: string) => {
        try {
            const res = await createNote({ userAESKey: aesKey, title });
            const newNote = res.data?.note;

            if (!newNote) {
                toast.error("Failed to create note");
                return;
            }

            // Add the new note to the store
            setNotes([newNote, ...notes]);

            // Navigate to the note page
            router.push(`/card/${newNote.noteId}`);
            toast.success("Note created");
        } catch (err) {
            console.error("Failed to create note:", err);
            toast.error("Failed to create note");
        }
    };

    const handleImportNote = async (file: File) => {
        if (!aesKey) {
            toast.error("Encryption key not available");
            return;
        }

        const response = await importNote({
            file,
            userAESKey: aesKey
        });

        if (!response.success) {
            toast.error(response.data?.error || "Failed to import note");
            return;
        }

        if (response.data?.note) {
            const currentNotes = useNoteStore.getState().notes || [];

            // setNotes([response.data.note, ...currentNotes]);
            if (!currentNotes.some(n => n.noteId === response.data.note.noteId)) {
                setNotes([response.data.note, ...currentNotes]);
            }

            toast.success(response.data?.message)
        }
    };

    return (
        <>
            <NoteHydrator notes={note} />
            <NotesGrid
                notes={notes}
                onAddNote={handleAddNote}
                onUploadNote={handleImportNote}
                onDeleteNote={handleDeleteNote}
                onDownloadNote={handleDownloadNote}
                onPinNote={handlePinNote}
                onColorChange={handleColorChange}
            />
        </>
    );
};

export default DashboardClient;