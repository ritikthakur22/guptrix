"use client";

import { useParams, useRouter } from "next/navigation";
import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import {
    ArrowLeft,
    Save,
    Trash2,
    Pin,
    Palette,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { noteColors } from "../../constants/noteColors";
import { toast } from "sonner";
import { useNoteStore } from "../../store/note/note.store";
import { updateNote, deleteNote } from "../../lib/api/note";
import { retrieveAESKey } from "@/app/lib/crypto-key-manager";
import PasswordAsk from "@/app/components/PasswordAsk";
import EditorJSComponent, { EditorJSHandle } from "../_components/Editorjs";
import ExcalidrawComponent, { ExcalidrawHandle } from "../_components/Excalidraw";

export default function NoteDetailPage() {
    const [aesKey, setAesKey] = useState<CryptoKey | null>(null);
    const [showPasswordDialog, setShowPasswordDialog] = useState<boolean>(false);
    const params = useParams();
    const router = useRouter();
    const noteId = params.id as string;
    const editorRef = useRef<EditorJSHandle>(null);

    // Get note from store
    const notes = useNoteStore((state) => state.notes) || [];
    const trashNotes = useNoteStore((state) => state.trashNotes) || [];

    // Store actions
    const updateNoteStore = useNoteStore((state) => state.updateNote);
    const removeNoteStore = useNoteStore((state) => state.removeNote);
    const setNotes = useNoteStore((state) => state.setNotes);
    const setTrashNotes = useNoteStore((state) => state.setTrashNotes);

    const note = notes.find((n) => n.noteId === noteId);

    const [editedTitle, setEditedTitle] = useState("");
    const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [editorReady, setEditorReady] = useState(false);
    // Add this ref alongside editorRef
    const excalidrawRef = useRef<ExcalidrawHandle>(null);
    const [excalidrawReady, setExcalidrawReady] = useState(false);


    // load aes
    useEffect(() => {
        const loadKey = async () => {
            const key = await retrieveAESKey();
            setAesKey(key);
            if (key) {
                setAesKey(key);
            } else {
                setShowPasswordDialog(true);
            }
        };
        loadKey();
    }, []);

    // Load note data into editor once both note and aesKey are available
    useEffect(() => {
        if (!note || !aesKey) return;
        setEditedTitle(note.title || "");
    }, [note, aesKey]);

    // Load content into EditorJS once editor mounts and note is available
    useEffect(() => {
        if (!note || !aesKey || !editorReady) return;
        if (editorRef.current && note.content) {
            editorRef.current.setContent(note.content);
        }
    }, [editorReady, note, aesKey]);

    // Load canvas data once Excalidraw mounts and note is available
    // useEffect(() => {
    //     if (!note || !aesKey || !excalidrawReady) return;
    //     if (excalidrawRef.current && note.canvasData) {
    //         excalidrawRef.current.setCanvasData(note.canvasData); // already decrypted
    //     }
    // }, [excalidrawReady, note, aesKey]);

    useEffect(() => {
        if (!excalidrawRef.current || !excalidrawReady || !note?.canvasData) return;
        excalidrawRef.current.setCanvasData(note.canvasData);
    }, [excalidrawReady, note?.canvasData]); // ✅ triggers when canvasData arrives


    if (!aesKey) {
        return (
            <PasswordAsk
                open={showPasswordDialog}
                onClose={() => setShowPasswordDialog(false)}
                onUnlock={(key) => {
                    setAesKey(key);
                    setShowPasswordDialog(false);
                }}
            />
        );
    }

    const handleSave = async () => {
        if (!note || isSaving) return;

        setIsSaving(true);
        const content = editorRef.current ? await editorRef.current.getContent() : "";
        const canvasData = excalidrawRef.current
            ? await excalidrawRef.current.getCanvasData()
            : undefined;


        // Optimistic update
        const previousNotes = [...notes];
        updateNoteStore(noteId, {
            title: editedTitle,
            content,
            canvasData
        });

        try {
            const res = await updateNote({
                noteId,
                userAESKey: aesKey,
                title: editedTitle,
                content,
                canvasData
            });

            if (res.success) {
                if (res.data?.updatedNote) {
                    updateNoteStore(noteId, {
                        updatedAt: res.data.updatedNote.updatedAt,
                    });
                }
                setHasUnsavedChanges(false);
                toast.success("Note saved");
            } else {
                setNotes(previousNotes);
                toast.error("Failed to save note");
            }
        } catch {
            setNotes(previousNotes);
            toast.error("Failed to save note");
        } finally {
            setIsSaving(false);
            router.push("/dashboard");
        }
    };

    const handleDelete = async () => {
        if (!note) return;

        const noteToTrash = note;
        const previousNotes = [...notes];
        removeNoteStore(noteId);

        let undoTriggered = false;

        const toastId = toast.warning("Note moved to trash", {
            description: "Click undo to restore your note.",
            action: {
                label: "Undo",
                onClick: () => {
                    undoTriggered = true;
                    toast.dismiss(toastId);
                    setNotes(previousNotes);
                },
            },
        });

        setTimeout(async () => {
            if (!undoTriggered) {
                try {
                    const res = await deleteNote(noteId);

                    if (res.success) {
                        setTrashNotes([
                            ...trashNotes,
                            {
                                ...noteToTrash,
                                trash: {
                                    isDeleted: true,
                                    deletedAt: new Date().toISOString(),
                                },
                            },
                        ]);
                        router.push("/dashboard");
                    } else {
                        setNotes(previousNotes);
                        toast.error(res.error || "Failed to delete note");
                    }
                } catch {
                    setNotes(previousNotes);
                    toast.error("Failed to delete note");
                }
            }
        }, 2500);
    };

    const handlePin = async () => {
        if (!note) return;

        const newPinned = !note.pinned;
        const previousNotes = [...notes];
        updateNoteStore(noteId, { pinned: newPinned });

        try {
            const res = await updateNote({ noteId, userAESKey: aesKey, pinned: newPinned });

            if (!res.success) {
                setNotes(previousNotes);
                toast.error("Failed to pin note");
            }
        } catch {
            setNotes(previousNotes);
            toast.error("Failed to pin note");
        }
    };

    const handleColorChange = async (color: string) => {
        if (!note) return;

        const previousNotes = [...notes];
        updateNoteStore(noteId, { color });

        try {
            const res = await updateNote({ noteId, userAESKey: aesKey, color });

            if (!res.success) {
                setNotes(previousNotes);
                toast.error("Failed to change color");
            }
        } catch {
            setNotes(previousNotes);
            toast.error("Failed to change color");
        }
    };

    if (!note) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-[hsl(var(--background))]">
                <div className="text-center">
                    <p className="text-[hsl(var(--muted-foreground))] mb-4">Note not found</p>
                    <Button onClick={() => router.push("/dashboard")}>
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        Back to Notes
                    </Button>
                </div>
            </div>
        );
    }

    const colorClass =
        noteColors.find((c) => c.value === note.color.toLocaleLowerCase())?.class || "bg-card";

    return (
        <div className="min-h-screen bg-linear-to-br from-background via-background to-muted/20">
            <div className="max-w-full xl:max-w-350 mx-auto px-4 py-6 md:py-8">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => router.push("/dashboard")}
                        className="gap-2"
                    >
                        <ArrowLeft className="h-4 w-4" />
                        Back to Notes
                    </Button>

                    <div className="flex flex-wrap items-center gap-2 justify-end">
                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={handlePin}
                            title={note.pinned ? "Unpin note" : "Pin note"}
                        >
                            <Pin
                                className={cn(
                                    "h-4 w-4",
                                    note.pinned &&
                                    "fill-[hsl(var(--primary))] text-[hsl(var(--primary))]"
                                )}
                            />
                        </Button>

                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" title="Change color">
                                    <Palette className="h-4 w-4" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                                {noteColors.map((color) => (
                                    <DropdownMenuItem
                                        key={color.value}
                                        onClick={() => handleColorChange(color.value)}
                                        className="flex items-center gap-2"
                                    >
                                        <div className={cn("h-4 w-4 rounded-full border", color.class)} />
                                        {color.name}
                                    </DropdownMenuItem>
                                ))}
                            </DropdownMenuContent>
                        </DropdownMenu>

                        <Button
                            variant="default"
                            size="sm"
                            onClick={handleSave}
                            disabled={!hasUnsavedChanges || isSaving}
                            className={cn(
                                "gap-2 gradient-primary text-[hsl(var(--primary-foreground))]",
                                (!hasUnsavedChanges || isSaving) && "opacity-50 cursor-not-allowed"
                            )}
                        >
                            <Save className="h-4 w-4" />
                            {isSaving ? "Saving..." : "Save"}
                        </Button>

                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={handleDelete}
                            title="Delete note"
                        >
                            <Trash2 className="h-4 w-4 text-[hsl(var(--destructive))]" />
                        </Button>
                    </div>
                </div>

                {/* Two-column grid on large screens */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* LEFT — Editor */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={cn(
                            "rounded-xl border border-[hsl(var(--border))]/50 overflow-hidden note-shadow",
                            colorClass
                        )}
                    >
                        {/* E2E Encryption Badge */}
                        <div className="px-8 pt-6 pb-2">
                            <span className="text-xs px-2 py-1 rounded bg-[hsl(var(--success))]/20 text-[hsl(var(--success))] font-medium">
                                🔒 End-to-End Encrypted
                            </span>
                        </div>

                        {/* Title Input */}
                        <div className="px-8 pt-4 pb-2">
                            <Input
                                value={editedTitle}
                                onChange={(e) => {
                                    setEditedTitle(e.target.value);
                                    setHasUnsavedChanges(true);
                                }}
                                placeholder="Note title"
                                className="text-xl sm:text-2xl md:text-3xl font-bold border-none bg-transparent focus-visible:ring-0 px-3 sm:px-5 py-2 h-auto"
                            />
                        </div>

                        {/* EditorJS Content */}
                        <div className="px-4 sm:px-6 md:px-8 pb-6">
                            <EditorJSComponent
                                ref={editorRef}
                                onChange={() => setHasUnsavedChanges(true)}
                                placeholder="Start writing your note..."
                                onReady={() => setEditorReady(true)}
                            />
                        </div>

                        {/* Metadata */}
                        <div className="px-8 pb-6 pt-4 border-t border-[hsl(var(--border))]/30">
                            <div className="flex items-center justify-between text-xs text-[hsl(var(--muted-foreground))] flex-wrap gap-2">
                                <div className="space-y-1">
                                    <p>
                                        <span className="font-medium">Created:</span>{" "}
                                        {new Date(note.createdAt).toLocaleString("en-US", {
                                            dateStyle: "medium",
                                            timeStyle: "short",
                                        })}
                                    </p>
                                    {note.updatedAt && (
                                        <p>
                                            <span className="font-medium">Last edited:</span>{" "}
                                            {new Date(note.updatedAt).toLocaleString("en-US", {
                                                dateStyle: "medium",
                                                timeStyle: "short",
                                            })}
                                        </p>
                                    )}
                                </div>
                                {hasUnsavedChanges && (
                                    <span className="text-[hsl(var(--warning))] font-medium">
                                        Unsaved changes
                                    </span>
                                )}
                            </div>
                        </div>
                    </motion.div>

                    {/* RIGHT — Empty panel (reserved for future use) */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="rounded-xl border border-[hsl(var(--border))]/30 bg-muted/10 min-h-200 sm:min-h-100"
                    // className="hidden lg:flex rounded-xl border border-[hsl(var(--border))]/30 bg-muted/10 items-center justify-center min-h-100"
                    >
                        {/* <ExcalidrawComponent /> */}
                        <ExcalidrawComponent
                            ref={excalidrawRef}                          // ✅ Connect ref
                            onChange={() => setHasUnsavedChanges(true)}  // ✅ Mark dirty on draw
                            onReady={() => setExcalidrawReady(true)}     // ✅ Trigger load effect
                        />

                        {/* Future content goes here */}
                    </motion.div>
                </div>

                {/* Keyboard Shortcuts Info */}
                <div className="mt-6 text-center">
                    <p className="text-xs text-[hsl(var(--muted-foreground))]">
                        Tip: Use{" "}
                        <kbd className="px-1.5 py-0.5 text-[10px] bg-muted rounded">Ctrl+B</kbd> for bold,{" "}
                        <kbd className="px-1.5 py-0.5 text-[10px] bg-muted rounded">Ctrl+I</kbd> for italic,{" "}
                        {/* <kbd className="px-1.5 py-0.5 text-[10px] bg-muted rounded">Ctrl+S</kbd> to save */}
                    </p>
                </div>
            </div>
        </div>
    );
}