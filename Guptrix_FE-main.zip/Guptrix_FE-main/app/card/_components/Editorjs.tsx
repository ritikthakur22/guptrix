"use client";

import { useEffect, useRef, forwardRef, useImperativeHandle } from "react";
import type { ToolConstructable } from "@editorjs/editorjs";

export interface EditorJSHandle {
    getContent: () => Promise<string>;
    setContent: (content: string) => Promise<void>;
}

interface EditorJSComponentProps {
    initialContent?: string;
    onChange?: () => void;
    onReady?: () => void;
    placeholder?: string;
}

const EditorJSComponent = forwardRef<EditorJSHandle, EditorJSComponentProps>(
    ({ initialContent, onChange, onReady, placeholder = "Start writing your note..." }, ref) => {
        const editorRef = useRef<any>(null);
        const holderRef = useRef<HTMLDivElement>(null);
        const isReady = useRef(false);
        // Guard against StrictMode double-mount
        const initStarted = useRef(false);

        useImperativeHandle(ref, () => ({
            getContent: async () => {
                if (!editorRef.current || !isReady.current) return "";
                try {
                    const outputData = await editorRef.current.save();
                    return JSON.stringify(outputData);
                } catch {
                    return "";
                }
            },
            setContent: async (content: string) => {
                // Poll until editor is truly ready (handles async init timing)
                const waitForReady = () =>
                    new Promise<void>((resolve) => {
                        if (isReady.current) return resolve();
                        const interval = setInterval(() => {
                            if (isReady.current) {
                                clearInterval(interval);
                                resolve();
                            }
                        }, 50);
                        // Timeout after 5s
                        setTimeout(() => { clearInterval(interval); resolve(); }, 5000);
                    });

                await waitForReady();

                if (!editorRef.current || !isReady.current) return;
                try {
                    let data = { blocks: [] as any[] };
                    if (content) {
                        try {
                            data = JSON.parse(content);
                        } catch {
                            data = {
                                blocks: [
                                    {
                                        type: "paragraph",
                                        data: { text: content.replace(/<[^>]*>/g, "") },
                                    },
                                ],
                            };
                        }
                    }
                    await editorRef.current.render(data);
                } catch (err) {
                    console.error("EditorJS setContent error:", err);
                }
            },
        }));

        useEffect(() => {
            // Prevent double-init from React StrictMode
            if (initStarted.current || !holderRef.current) return;
            initStarted.current = true;

            const initEditor = async () => {
                const EditorJS = (await import("@editorjs/editorjs")).default;
                const Header = (await import("@editorjs/header")).default;
                const List = (await import("@editorjs/list")).default;
                const Checklist = (await import("@editorjs/checklist")).default;
                const Quote = (await import("@editorjs/quote")).default;
                const Delimiter = (await import("@editorjs/delimiter")).default;
                const InlineCode = (await import("@editorjs/inline-code")).default;
                const Marker = (await import("@editorjs/marker")).default;
                // @ts-ignore — no types package, but it works at runtime
                const Underline = (await import("@editorjs/underline")).default;


                let initialData = { blocks: [] as any[] };
                if (initialContent) {
                    try {
                        initialData = JSON.parse(initialContent);
                    } catch {
                        initialData = {
                            blocks: [
                                {
                                    type: "paragraph",
                                    data: { text: initialContent.replace(/<[^>]*>/g, "") },
                                },
                            ],
                        };
                    }
                }

                const editor = new EditorJS({
                    holder: holderRef.current!,
                    placeholder,
                    // bold and italic are built-in; underline needs the plugin
                    inlineToolbar: ['bold', 'italic', 'underline', 'link', 'marker', 'inlineCode'],
                    data: initialData,
                    tools: {
                        header: {
                            class: Header as unknown as ToolConstructable,
                            config: { levels: [1, 2, 3], defaultLevel: 2 },
                            shortcut: 'CMD+SHIFT+H'
                        },
                        list: {
                            class: List as unknown as ToolConstructable,
                            inlineToolbar: true,
                            shortcut: 'CMD+O'
                        },
                        checklist: {
                            class: Checklist as unknown as ToolConstructable,
                            inlineToolbar: true,
                        },
                        quote: {
                            class: Quote as unknown as ToolConstructable,
                            inlineToolbar: true,
                            shortcut: 'CMD+Q'
                        },
                        delimiter: Delimiter as unknown as ToolConstructable,
                        inlineCode: {
                            class: InlineCode as unknown as ToolConstructable,
                            shortcut: "CMD+SHIFT+M",
                        },
                        marker: {
                            class: Marker as unknown as ToolConstructable,
                            shortcut: "CMD+I",
                        },
                        underline: {
                            class: Underline as unknown as ToolConstructable,
                            shortcut: 'CMD+U',
                        },
                    },
                    onChange: () => {
                        onChange?.();
                    },
                    onReady: () => {
                        isReady.current = true;
                        editorRef.current = editor;
                        onReady?.();
                    },
                });
            };

            initEditor().catch(console.error);

            return () => {
                if (editorRef.current && isReady.current) {
                    try {
                        editorRef.current.destroy?.();
                    } catch { }
                    editorRef.current = null;
                    isReady.current = false;
                }
                initStarted.current = false;
            };
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, []);

        return (
            <>
                <style>{`
                    /* Toolbar +/settings dots — follow theme color */
                    .ce-toolbar__plus,
                    .ce-toolbar__settings-btn {
                        color: hsl(var(--foreground)) !important;
                        background: transparent !important;
                    }
                    .ce-toolbar__plus:hover,
                    .ce-toolbar__settings-btn:hover {
                        background: hsl(var(--muted)) !important;
                        color: hsl(var(--foreground)) !important;
                    }
                    /* Toolbar SVG icons inside popover */
                    .ce-popover__item-icon svg,
                    .ce-inline-toolbar__dropdown svg,
                    .ce-conversion-toolbar__label svg {
                        color: hsl(var(--foreground)) !important;
                        fill: currentColor;
                    }
                    /* Popover (block picker) background */
                    .ce-popover,
                    .ce-inline-toolbar,
                    .ce-conversion-toolbar {
                        background: hsl(var(--popover)) !important;
                        border-color: hsl(var(--border)) !important;
                        color: hsl(var(--popover-foreground)) !important;
                        box-shadow: 0 4px 24px rgba(0,0,0,0.18) !important;
                    }
                    .ce-popover__item:hover,
                    .ce-inline-toolbar__dropdown:hover {
                        background: hsl(var(--muted)) !important;
                    }
                    .ce-popover__item-label,
                    .ce-popover__item-secondary-label {
                        color: hsl(var(--popover-foreground)) !important;
                    }
                    /* Inline toolbar buttons */
                    .ce-inline-tool,
                    .ce-inline-toolbar__dropdown {
                        color: hsl(var(--foreground)) !important;
                    }
                    .ce-inline-tool:hover,
                    .ce-inline-tool--active {
                        background: hsl(var(--muted)) !important;
                        color: hsl(var(--primary)) !important;
                    }
                    /* Paragraph placeholder color */
                    .ce-block--focused .ce-paragraph[data-placeholder]:empty::before,
                    .ce-paragraph[data-placeholder]:empty::before {
                        color: hsl(var(--muted-foreground)) !important;
                    }
                    /* General editor text */
                    .codex-editor,
                    .ce-block,
                    .ce-paragraph {
                        color: hsl(var(--foreground)) !important;
                    }
                    /* Delimiter */
                    .ce-delimiter::before {
                        color: hsl(var(--muted-foreground)) !important;
                    }
                    /* Search input inside popover */
                    .ce-popover__search .ce-search__field {
                        background: hsl(var(--input)) !important;
                        color: hsl(var(--foreground)) !important;
                        border-color: hsl(var(--border)) !important;
                    }
                    .ce-popover__search,
                    .ce-search,
                    .ce-search__field,
                    .ce-popover__search .ce-search__field,
                    .ce-popover-search,
                    .ce-popover-search__field {
                        background: hsl(var(--input)) !important;
                        color: hsl(var(--foreground)) !important;
                        border-color: hsl(var(--border)) !important;
                        caret-color: hsl(var(--foreground)) !important;
                    }
                `}</style>
                <div
                    ref={holderRef}
                    className="min-h-75 sm:min-h-100 md:min-h-125 text-sm sm:text-base leading-relaxed focus:outline-none prose prose-sm max-w-none [&_.ce-block]:py-0.5 [&_.ce-toolbar__content]:max-w-none [&_.ce-block__content]:max-w-none [&_.codex-editor]:w-full dark:prose-invert"
                />
            </>
        );
    }
);

EditorJSComponent.displayName = "EditorJSComponent";

export default EditorJSComponent;