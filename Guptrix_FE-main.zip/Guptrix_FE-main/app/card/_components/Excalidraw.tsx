"use client";

import { useEffect, useRef, forwardRef, useImperativeHandle, useState } from "react";
import { Loader2 } from "lucide-react";
import "@excalidraw/excalidraw/index.css"; // <--- Add this line


export interface ExcalidrawHandle {
    getCanvasData: () => Promise<string>;
    setCanvasData: (data: string) => void;
}

interface ExcalidrawComponentProps {
    onChange?: () => void;
    onReady?: () => void;
}

const getExcalidrawTheme = (): "light" | "dark" => {
    if (typeof window === "undefined") return "dark";

    const uiTheme = localStorage.getItem("notes-ui-theme");
    return uiTheme === "light" ? "light" : "dark";
};
const ExcalidrawComponent = forwardRef<ExcalidrawHandle, ExcalidrawComponentProps>(
    ({ onChange, onReady }, ref) => {
        const [ExcalidrawLib, setExcalidrawLib] = useState<any>(null);
        const [excalidrawTheme, setExcalidrawTheme] = useState<"light" | "dark">("dark");
        const [isLoading, setIsLoading] = useState(true);
        const apiRef = useRef<any>(null);
        const pendingData = useRef<string | null>(null);

        useImperativeHandle(ref, () => ({
            getCanvasData: async () => {
                if (!apiRef.current) return "";
                try {
                    const elements = apiRef.current.getSceneElements();
                    const appState = apiRef.current.getAppState();
                    return JSON.stringify({
                        elements,
                        appState: {
                            viewBackgroundColor: appState.viewBackgroundColor,
                            currentItemFontFamily: appState.currentItemFontFamily,
                        },
                    });
                } catch {
                    return "";
                }
            },
            setCanvasData: (data: string) => {
                if (!data) return;
                if (!apiRef.current) {
                    pendingData.current = data;
                    return;
                }
                try {
                    const parsed = JSON.parse(data);
                    apiRef.current.updateScene({
                        elements: parsed.elements ?? [],
                        appState: parsed.appState ?? {},
                    });
                } catch (err) {
                    console.error("setCanvasData error:", err);
                }
            },
        }));

        useEffect(() => {
            import("@excalidraw/excalidraw")
                .then((mod) => {
                    setExcalidrawLib(() => mod.Excalidraw);
                    setIsLoading(false);
                })
                .catch(console.error);
        }, []);

        useEffect(() => {
            const handler = () => {
                const theme = getExcalidrawTheme();
                setExcalidrawTheme(theme);

                apiRef.current?.updateScene({
                    appState: { theme },
                });
            };

            window.addEventListener("theme-change", handler);
            return () => window.removeEventListener("theme-change", handler);
        }, []);

        // Excalidraw.tsx — in handleMount
        const handleMount = (api: any) => {
            apiRef.current = api;
            const theme = getExcalidrawTheme();
            setExcalidrawTheme(theme);

            // Use requestAnimationFrame instead of setTimeout(0)
            // to ensure the scene is fully initialized before updating
            requestAnimationFrame(() => {
                api.updateScene({ appState: { theme } });

                if (pendingData.current) {
                    try {
                        const parsed = JSON.parse(pendingData.current);
                        api.updateScene({
                            elements: parsed.elements ?? [],
                            appState: { ...parsed.appState, theme },
                        });
                    } catch (err) {
                        console.error("Failed to load pending canvas data:", err);
                    }
                    pendingData.current = null;
                }

                onReady?.(); // ✅ Move onReady AFTER scene is initialized
            });
        };

        if (isLoading || !ExcalidrawLib) {
            return (
                <div className="w-full h-full flex items-center justify-center">
                    <div className="flex flex-col items-center gap-3 text-[hsl(var(--muted-foreground))]">
                        <Loader2 className="h-6 w-6 animate-spin" />
                        <span className="text-sm">Loading canvas...</span>
                    </div>
                </div>
            );
        }

        return (
            <div className="w-full h-full">
                <ExcalidrawLib
                    theme={excalidrawTheme}
                    excalidrawAPI={(api: any) => handleMount(api)}
                    onChange={() => onChange?.()}
                    UIOptions={{
                        canvasActions: {
                            export: false,
                            loadScene: false,
                            saveToActiveFile: false,
                            saveAsImage: false,
                            toggleTheme: false,
                        },
                    }}
                    initialData={{
                        elements: [],
                        appState: {
                            viewBackgroundColor: "transparent",
                            theme: excalidrawTheme,
                        },
                    }}
                />
            </div>
        );
    }
);

ExcalidrawComponent.displayName = "ExcalidrawComponent";

export default ExcalidrawComponent;