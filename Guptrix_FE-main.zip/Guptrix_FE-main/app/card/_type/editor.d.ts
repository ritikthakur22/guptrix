declare module '@editorjs/checklist' {
  import { BlockTool, BlockToolConstructorOptions } from '@editorjs/editorjs';
  export default class Checklist implements BlockTool {
    constructor(options: BlockToolConstructorOptions);
    render(): HTMLElement;
    save(block: HTMLElement): object;
    static get toolbox(): { title: string; icon: string };
  }
}

declare module '@editorjs/marker' {
  import { InlineTool } from '@editorjs/editorjs';
  export default class Marker implements InlineTool {
    render(): HTMLElement;
    surround(range: Range): void;
    checkState(selection: Selection): boolean;
    static get shortcut(): string;
    static get isInline(): boolean;
    static get sanitize(): object;
    static get title(): string;
  }
}

declare module '@editorjs/delimiter' {
  import { BlockTool, BlockToolConstructorOptions } from '@editorjs/editorjs';
  export default class Delimiter implements BlockTool {
    constructor(options: BlockToolConstructorOptions);
    render(): HTMLElement;
    save(): object;
    static get toolbox(): { title: string; icon: string };
  }
}

declare module '@editorjs/inline-code' {
  import { InlineTool } from '@editorjs/editorjs';
  export default class InlineCode implements InlineTool {
    render(): HTMLElement;
    surround(range: Range): void;
    checkState(selection: Selection): boolean;
    static get shortcut(): string;
    static get isInline(): boolean;
    static get sanitize(): object;
    static get title(): string;
  }
}