interface NoteColor {
    name: string;
    value: string;
    class: string;
}

export const noteColors: NoteColor[] = [
    { name: "Default", value: "default", class: "bg-card" },
    { name: "Yellow", value: "yellow", class: "bg-[hsl(var(--note-yellow))]" },
    { name: "Green", value: "green", class: "bg-[hsl(var(--note-green))]" },
    { name: "Blue", value: "blue", class: "bg-[hsl(var(--note-blue))]" },
    { name: "Pink", value: "pink", class: "bg-[hsl(var(--note-pink))]" },
    { name: "Purple", value: "purple", class: "bg-[hsl(var(--note-purple))]" },
    { name: "Orange", value: "orange", class: "bg-[hsl(var(--note-orange))]" },
];
