'use client'

import { motion } from "framer-motion";
import { Github, Twitter, Mail, Lock, Instagram } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

export function Footer() {
  return (
    <footer className="relative py-14 px-4 bg-[hsl(var(--card))]/60 border-t border-[hsl(var(--border))]/50">

      {/* Gradient divider */}
      <div className="absolute top-0 left-0 right-0 h-px gradient-primary opacity-40" />

      <div className="max-w-6xl mx-auto">

        {/* Top Section */}
        {/* <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-10"> */}
        <div className="flex flex-col md:flex-row md:justify-between gap-10 mb-10">

          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Link href="/" className="flex items-center gap-3 mb-4">
              <Image src="/guptrix.png" alt="Guptrix" width={48} height={48} />
              <span className="text-xl font-bold gradient-text tracking-wide">
                Guptrix
              </span>
            </Link>

            <p className="text-sm text-[hsl(var(--muted-foreground))] leading-relaxed">
              Zero-knowledge encrypted notes built for people who value privacy.
            </p>

            <div className="inline-flex items-center gap-2 mt-4 px-3 py-1 rounded-full badge-bg badge-border border text-xs text-[hsl(var(--foreground))]">
              <Lock className="w-3.5 h-3.5 text-[hsl(var(--primary))]" />
              Client-side encryption enabled
            </div>
          </motion.div>

          {/* Quick Links (optional future use) */}
          {/* <div>
            <h4 className="font-semibold mb-4">Product</h4>
            <ul className="space-y-2 text-sm text-[hsl(var(--muted-foreground))]">
              <li>
                <a href="#features" className="hover:text-[hsl(var(--primary))] transition-colors">
                  Features
                </a>
              </li>
              <li>
                <a href="#security" className="hover:text-[hsl(var(--primary))] transition-colors">
                  Security
                </a>
              </li>
              <li>
                <a href="#roadmap" className="hover:text-[hsl(var(--primary))] transition-colors">
                  Roadmap
                </a>
              </li>
            </ul>
          </div> */}

          {/* Social */}
          <div>
            <h4 className="font-semibold mb-4">Connect</h4>
            <div className="flex gap-4">
              {[{ icon: Instagram, path: 'https://www.instagram.com/aadarshchaudhary04/' }, { icon: Github, path: 'https://github.com/A-adarsh1' }, { icon: Mail, path: 'mailto:guptrix@gmail.com' }].map((item, i) => (
                <motion.a
                  key={i}
                  href={item.path}
                  whileHover={{ scale: 1.15 }}
                  whileTap={{ scale: 0.95 }}
                  target="_blank"
                  className="p-3 rounded-xl bg-[hsl(var(--secondary))] hover:bg-[hsl(var(--primary))]/15 transition-all shadow-sm"
                >
                  <item.icon className="h-5 w-5 text-[hsl(var(--muted-foreground))]" />
                </motion.a>
              ))}
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between pt-6 border-t border-[hsl(var(--border))]/40">

          <p className="text-sm text-[hsl(var(--muted-foreground))]">
            © {new Date().getFullYear()} Guptrix. All rights reserved.
          </p>

          <p className="text-xs mt-2 md:mt-0 text-[hsl(var(--muted-foreground))]">
            Your notes. Your keys. Your privacy.
          </p>

        </div>
      </div>
    </footer>
  );
}
