'use client';

import { createContext, useContext, useEffect, useState } from "react";

// type Theme = "dark" | "light" | "system";
type Theme = "dark" | "light";

type ThemeProviderProps = {
  children: React.ReactNode;
  defaultTheme?: Theme;
  storageKey?: string;
};

type ThemeProviderState = {
  theme: Theme;
  setTheme: (theme: Theme) => void;
};

const ThemeProviderContext = createContext<ThemeProviderState | undefined>(
  undefined
);

export function ThemeProvider({
  children,
  // defaultTheme = "system",
  defaultTheme = "dark",
  storageKey = "notes-ui-theme",
}: ThemeProviderProps) {
  // ✅ Safe initial value (no browser APIs)
  const [theme, setTheme] = useState<Theme>(defaultTheme);

  // ✅ Read localStorage AFTER mount
  useEffect(() => {
    const storedTheme = localStorage.getItem(storageKey) as Theme | null;
    if (storedTheme) {
      setTheme(storedTheme);
    }
  }, [storageKey]);

  // ✅ Apply theme to <html>
  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("light", "dark");

    root.classList.add(theme);

  }, [theme]);

  const value: ThemeProviderState = {
    theme,
    setTheme: (theme: Theme) => {
      localStorage.setItem(storageKey, theme);
      // 🔔 notify Excalidraw (and anything else listening)
      window.dispatchEvent(new Event("theme-change"));
      setTheme(theme);
    },
  };

  return (
    <ThemeProviderContext.Provider value={value}>
      {children}
    </ThemeProviderContext.Provider>
  );
}

export const useTheme = () => {
  const context = useContext(ThemeProviderContext);
  if (!context) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
};
