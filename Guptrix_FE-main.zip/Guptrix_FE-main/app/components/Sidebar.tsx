"use client";

import { motion, AnimatePresence } from "framer-motion";
import { NotebookPen, Trash2, Settings, LogOut, PanelLeftClose } from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "./ThemeToggle";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import Image from "next/image";
import { logout } from "../lib/api/auth";
import { toast } from 'sonner';

export function Sidebar() {
    const [collapsed, setCollapsed] = useState(false);
    const [isMobile, setIsMobile] = useState(false);
    const pathname = usePathname();
    const router = useRouter();

    // Detect mobile and set collapsed state
    useEffect(() => {
        const checkMobile = () => {
            const mobile = window.innerWidth < 768;
            setIsMobile(mobile);
            if (mobile) {
                setCollapsed(true);
            }
        };

        checkMobile();
        window.addEventListener('resize', checkMobile);
        return () => window.removeEventListener('resize', checkMobile);
    }, []);

    const menuItems = [
        { id: "notes", url: "/dashboard", icon: NotebookPen, label: "Notes" },
        { id: "trash", url: "/trash", icon: Trash2, label: "Trash" },
    ];

    const isActive = (url: string) => pathname === url;

    const handleLogout = async () => {
        const response = await logout();
        toast.success(response?.message || "Logout successful")
        router.refresh();
        router.push('/auth/login')
    }

    return (
        <motion.aside
            initial={{ x: -100, opacity: 0 }}
            animate={{
                x: 0,
                opacity: 1,
                width: collapsed ? "4rem" : "16rem"
            }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="fixed left-0 top-0 h-full bg-[hsl(var(--sidebar-background))] border-r border-[hsl(var(--sidebar-border))] flex flex-col z-40"
        >
            {/* Logo */}
            <div className="p-3 border-b border-[hsl(var(--sidebar-border))] overflow-hidden">
                <Link href="/" className="flex items-center gap-2">
                    <motion.div
                        whileHover={{ rotate: 10 }}
                        transition={{ type: "spring", stiffness: 300 }}
                    >
                        <Image src="/guptrix.png" alt="syncgaurd" width={60} height={60} />
                    </motion.div>
                    <AnimatePresence>
                        {!collapsed && (
                            <motion.span
                                initial={{ opacity: 0, width: 0 }}
                                animate={{ opacity: 1, width: "auto" }}
                                exit={{ opacity: 0, width: 0 }}
                                transition={{ duration: 0.2 }}
                                className="text-xl font-bold gradient-text whitespace-nowrap"
                            >
                                Guptrix
                            </motion.span>
                        )}
                    </AnimatePresence>
                </Link>
            </div>

            {/* Navigation */}
            <nav className="flex-1 p-2 space-y-1">
                {menuItems.map((item) => (
                    <motion.button
                        key={item.id}
                        whileHover={{ x: collapsed ? 0 : 4 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => router.push(item.url)}
                        className={cn(
                            "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors overflow-hidden",
                            isActive(item.url)
                                ? "bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar-primary-foreground))]"
                                : "text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))]"
                        )}
                    >
                        <item.icon className="h-5 w-5 shrink-0" />
                        <AnimatePresence>
                            {!collapsed && (
                                <motion.span
                                    initial={{ opacity: 0, width: 0 }}
                                    animate={{ opacity: 1, width: "auto" }}
                                    exit={{ opacity: 0, width: 0 }}
                                    transition={{ duration: 0.2 }}
                                    className="font-medium whitespace-nowrap"
                                >
                                    {item.label}
                                </motion.span>
                            )}
                        </AnimatePresence>
                    </motion.button>
                ))}
            </nav>

            {/* Bottom Section */}
            <div className="p-2 border-t border-[hsl(var(--sidebar-border))] space-y-1">
                <div className={cn("flex items-center", collapsed ? "justify-center" : "justify-between px-2")}>
                    <AnimatePresence>
                        {!collapsed && (
                            <motion.span
                                initial={{ opacity: 0, width: 0 }}
                                animate={{ opacity: 1, width: "auto" }}
                                exit={{ opacity: 0, width: 0 }}
                                transition={{ duration: 0.2 }}
                                className="text-sm text-[hsl(var(--sidebar-foreground))] whitespace-nowrap"
                            >
                                Theme
                            </motion.span>
                        )}
                    </AnimatePresence>
                    <ThemeToggle />
                </div>

                <motion.button
                    whileHover={{ x: collapsed ? 0 : 4 }}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] transition-colors overflow-hidden"
                >
                    <Settings className="h-5 w-5 shrink-0" />
                    <AnimatePresence>
                        {!collapsed && (
                            <motion.span
                                initial={{ opacity: 0, width: 0 }}
                                animate={{ opacity: 1, width: "auto" }}
                                exit={{ opacity: 0, width: 0 }}
                                transition={{ duration: 0.2 }}
                                className="font-medium whitespace-nowrap"
                            >
                                Settings
                            </motion.span>
                        )}
                    </AnimatePresence>
                </motion.button>

                <motion.button
                    whileHover={{ x: collapsed ? 0 : 4 }}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-[hsl(var(--destructive))] hover:bg-[hsl(var(--destructive))]/10 transition-colors overflow-hidden"
                    onClick={handleLogout}
                >
                    <LogOut className="h-5 w-5 shrink-0" />
                    <AnimatePresence>
                        {!collapsed && (
                            <motion.span
                                initial={{ opacity: 0, width: 0 }}
                                animate={{ opacity: 1, width: "auto" }}
                                exit={{ opacity: 0, width: 0 }}
                                transition={{ duration: 0.2 }}
                                className="font-medium whitespace-nowrap"
                            >
                                Logout
                            </motion.span>
                        )}
                    </AnimatePresence>
                </motion.button>
            </div>

            {/* Collapse Toggle */}
            <Button
                variant="ghost"
                size="icon"
                onClick={() => setCollapsed(!collapsed)}
                className="absolute -right-5 top-4 z-40 h-8 w-8 rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--background))] shadow-md transition-all hover:bg-[hsl(var(--accent))]"
            >
                <PanelLeftClose
                    className={`h-4 w-4 transition-transform duration-300 ${collapsed ? "rotate-180" : ""}`}
                />
            </Button>
        </motion.aside>
    );
}