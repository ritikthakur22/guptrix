'use client'
import { motion } from "framer-motion";
import {
  Shield,
  Key,
  Fingerprint,
  Cpu,
  Cloud,
  Lock,
  Zap
} from "lucide-react";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const features = [
  {
    icon: Shield,
    title: "End-to-End Encryption",
    description: "Your notes are encrypted before leaving your device. Even we can't read them.",
    color: "text-green-500",
  },
  {
    icon: Key,
    title: "Zero-Knowledge Storage",
    description: "We store only encrypted data. Your secrets stay yours — not even our servers can unlock them.",
    color: "text-purple-500",
  },
  {
    icon: Cpu,
    title: "Client-Side Encryption Engine",
    description: "All encryption happens in your browser — your data never travels in plain text.",
    color: "text-blue-500",
  },
  {
    icon: Fingerprint,
    title: "Private by Design",
    description: "No trackers. No ads. No data mining. Built for privacy from the first line of code.",
    color: "text-rose-500",
  },
  {
    icon: Cloud,
    title: "Secure Sync",
    description: "Access your encrypted notes from any device, anywhere.",
    color: "text-cyan-500",
  },
  {
    icon: Zap,
    title: "Instant Lock Mode",
    description: "Lock and hide sensitive notes in one tap with blazing-fast encryption.",
    color: "text-yellow-500",
  },

];

export function Features() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (sectionRef.current) {
      const cards = sectionRef.current.querySelectorAll('.feature-card');

      gsap.fromTo(
        cards,
        { opacity: 0, y: 60, scale: 0.9 },
        {
          opacity: 1,
          y: 0,
          scale: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            end: "bottom 20%",
          },
        }
      );
    }
  }, []);

  return (
    <section ref={sectionRef} id="features" className="py-24 px-4 bg-[hsl(var(--secondary))]/30">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[hsl(var(--primary))]/10 border border-[hsl(var(--primary))]/20 mb-4">
            <Zap className="h-4 w-4 text-[hsl(var(--primary))]" />
            <span className="text-sm font-medium text-[hsl(var(--primary))]">Powerful Features</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Everything you need,{" "}
            <span className="gradient-text">nothing you don't</span>
          </h2>
          <p className="text-[hsl(var(--muted-foreground))] text-lg max-w-2xl mx-auto">
            Simple, powerful, and secure. The perfect note-taking experience.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              className="feature-card group"
              whileHover={{ y: -5 }}
              transition={{ duration: 0.2 }}
            >
              <div className="relative p-6 rounded-2xl bg-[hsl(var(--card))] border border-[hsl(var(--border))]/50 h-full overflow-hidden transition-all duration-300 hover:border-[hsl(var(--primary))]/30 hover:shadow-lg">
                {/* Gradient Overlay on Hover */}
                <div className="absolute inset-0 bg-linear-to-br from-[hsl(var(--primary))]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                <div className="relative z-10">
                  <div className={`inline-flex p-3 rounded-xl bg-[hsl(var(--secondary))] mb-4 ${feature.color}`}>
                    <feature.icon className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Security Highlight */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
          className="mt-16 p-8 rounded-3xl bg-linear-to-r from-[hsl(var(--primary))]/10 via-[hsl(var(--primary))]/5 to-[hsl(var(--accent))]/10 border border-[hsl(var(--primary))]/20"
        >
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="shrink-0">
              <div className="p-4 rounded-2xl bg-[hsl(var(--primary))]/20">
                <Lock className="h-12 w-12 text-[hsl(var(--primary))]" />
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-2">Your Privacy is Our Priority</h3>
              <p className="text-[hsl(var(--muted-foreground))]">
                We use the same encryption standards as banks and governments. Your notes are encrypted
                on your device before they ever reach our servers. Without your password, your data is
                completely unreadable—even to us.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
