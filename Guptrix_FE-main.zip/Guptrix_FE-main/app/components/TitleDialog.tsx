"use client";

import { Dispatch, SetStateAction, useState } from "react";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Type, Loader2, Save } from "lucide-react"; // Changed icon to 'Type' for title context
import { toast } from "sonner";

interface TitleDialogProps {
    open: boolean;
    setOpen: (open: boolean) => void; // Added to handle closing the dialog
    setTitle: (title: string) => void;
}

const TitleDialog = ({ open, setOpen, setTitle }: TitleDialogProps) => {
    // Local state to hold the text while typing
    const [inputValue, setInputValue] = useState("");
    const [loading, setLoading] = useState(false);

    const handleConfirm = () => {
        if (!inputValue.trim()) {
            toast.error("Title cannot be empty");
            return;
        }

        setLoading(true);

        // This now works perfectly with handleDialogConfirm
        setTitle(inputValue.trim());


        // Simulate a small delay for UX before closing
        setTimeout(() => {
            setLoading(false);
            setOpen(false);
            // toast.success("Title updated successfully");
            setInputValue(""); // Clear input for next time
        }, 500);
    };

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogContent className="sm:max-w-md glass-card">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Type className="h-5 w-5 text-primary" />
                        Rename Note
                    </DialogTitle>
                    <DialogDescription>
                        Enter a new title for your document.
                    </DialogDescription>
                </DialogHeader>

                <div className="space-y-4 pt-2">
                    <div className="relative">
                        <Input
                            type="text"
                            placeholder="e.g., My Private Journal"
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            className="pr-10"
                            autoFocus
                            onKeyDown={(e) => {
                                if (e.key === "Enter") handleConfirm();
                            }}
                        />
                    </div>

                    <Button
                        className="w-full gradient-primary text-primary-foreground"
                        disabled={!inputValue.trim() || loading}
                        onClick={handleConfirm}
                    >
                        {loading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                            </>
                        ) : (
                            "Save Title"
                        )}
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default TitleDialog;