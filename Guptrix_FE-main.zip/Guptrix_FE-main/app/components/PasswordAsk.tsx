"use client";

import { useState } from "react";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Lock, Eye, EyeOff, Loader2 } from "lucide-react";
import { useUser } from "../store/auth/auth.store";
import { unlockUserAESKey } from "../lib/crypto.service";
import { storeAESKey } from "../lib/crypto-key-manager";
import { toast } from "sonner";

interface PasswordAskProps {
    open: boolean;
    onClose: () => void; // Add this
    onUnlock: (key: CryptoKey) => void; // add this
}

const PasswordAsk = ({ open, onClose, onUnlock }: PasswordAskProps) => {
    const [password, setPassword] = useState<string>("");
    const [loading, setLoading] = useState<boolean>(false);
    const [showPassword, setShowPassword] = useState(false);
    const user = useUser((state) => state.user);

    const handlesubmit = async (password: string) => {
        setLoading(true);
        try {
            if (!user) throw new Error('User data not found');
            const userAESKey = await unlockUserAESKey(
                password,
                user.salt!,
                user.keyIV!,
                user.encryptedAESKey!
            );
            await storeAESKey(userAESKey);
            // Clear password field
            setPassword("");

            // Close the dialog
            // onClose();
            onUnlock(userAESKey); // ← pass key back instead of just closing

        } catch (err) {
            console.error("Failed to unlock AES key:", err);
            toast.warning("Invalid password", {
                description: "Please Enter corrent password to unlock the data",
            });
            // You can also show a toast here
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onClose}> {/* Pass onClose here */}
            <DialogContent className="sm:max-w-md glass-card">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Lock className="h-5 w-5 text-primary" />
                        Unlock Note
                    </DialogTitle>
                    <DialogDescription>
                        Enter your password to decrypt and access this note.
                    </DialogDescription>
                </DialogHeader>

                <div className="space-y-4 pt-2">
                    <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                            type={showPassword ? "text" : "password"}
                            placeholder="••••••••"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="pl-10 pr-10"
                            disabled={loading}
                            autoFocus
                            onKeyDown={(e) => {
                                if (e.key === "Enter" && password && !loading) {
                                    handlesubmit(password);
                                }
                            }}
                        />
                        <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute cursor-pointer right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                            disabled={loading}
                        >
                            {showPassword ? (
                                <Eye className="h-4 w-4" />
                            ) : (
                                <EyeOff className="h-4 w-4" />
                            )}
                        </button>
                    </div>

                    <Button
                        className="w-full gradient-primary text-primary-foreground"
                        disabled={!password || loading}
                        onClick={() => handlesubmit(password)}
                    >
                        {loading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Unlocking...
                            </>
                        ) : (
                            "Unlock"
                        )}
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default PasswordAsk;
