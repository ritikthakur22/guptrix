"use client"

import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { AppSidebar } from "@/components/app-sidebar"
import {
    SidebarInset,
    SidebarProvider,
} from "@/components/ui/sidebar"
import { AuthNavbar } from './AuthNavbar';
import DashboardSkeleton from './DashboardSkeleton';


export default function LayoutContent({ children }: { children: React.ReactNode }) {
    const pathname = usePathname();
    const router = useRouter();
    const [isAuth, setIsAuth] = useState<boolean | null>(null);

    // Check auth status by calling an API endpoint
    useEffect(() => {
        const checkAuth = async () => {
            try {
                const response = await fetch('/api/auth/check', {
                    method: 'GET',
                    credentials: 'include', // Important: includes cookies
                });
                if (!response.ok) {
                    setIsAuth(false);
                    return;
                }

                const data = await response.json();
                setIsAuth(data.authenticated);
            } catch (error) {
                console.error('Auth check failed:', error);
                setIsAuth(false);
            }
        };

        checkAuth();

        // Also check on focus (when user returns to tab)
        window.addEventListener('focus', checkAuth);

        return () => {
            window.removeEventListener('focus', checkAuth);
        };
    }, [pathname]);

    // Show loading spinner while checking auth
    if (isAuth === null) {
        return <DashboardSkeleton />;
    }

    // Authenticated layout
    if (isAuth) {
        return (
            <SidebarProvider>
                <AppSidebar />
                <SidebarInset className="flex flex-col">
                    <AuthNavbar />
                    <main className="flex-1 overflow-auto p-4">
                        {children}
                    </main>
                </SidebarInset>
            </SidebarProvider>
        );
    }

    // Unauthenticated - render children directly (login/signup pages)
    return <>{children}</>;
}