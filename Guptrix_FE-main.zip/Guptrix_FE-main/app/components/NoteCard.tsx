"use client";

import { motion } from "framer-motion";
import { Trash2, Pin, Palette, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { Note } from "../store/note/note.types";
import { noteColors } from "../constants/noteColors";
import { useRouter } from "next/navigation";
import { HiOutlineExternalLink } from "react-icons/hi";

interface NoteCardProps {
    note: Note;
    isTrash?: boolean;
    onDelete: (id: string) => void;
    onPin?: (id: string) => void;
    onColorChange?: (id: string, color: string) => void;
    onDownload: (id: string) => void;
}

/** Converts EditorJS JSON to a readable plain-text preview string */
export function editorJsToPlainText(content: string): string {
    if (!content) return "";

    try {
        const parsed = JSON.parse(content);
        if (!parsed?.blocks || !Array.isArray(parsed.blocks)) {
            // Not EditorJS JSON — return as-is (legacy plain text)
            return content;
        }

        return parsed.blocks
            .map((block: any) => {
                switch (block.type) {
                    case "paragraph":
                        return block.data?.text?.replace(/<[^>]*>/g, "") ?? "";
                    case "header":
                        return block.data?.text?.replace(/<[^>]*>/g, "") ?? "";
                    case "quote":
                        return block.data?.text?.replace(/<[^>]*>/g, "") ?? "";
                    case "list":
                        return (block.data?.items ?? [])
                            .map((item: any) => {
                                const text = typeof item === "string"
                                    ? item
                                    : item?.content ?? "";
                                return "• " + text.replace(/<[^>]*>/g, "");
                            })
                            .join("\n");
                    case "checklist":
                        return (block.data?.items ?? [])
                            .map((item: any) => {
                                const checked = item?.checked ? "☑" : "☐";
                                const text = (item?.text ?? "").replace(/<[^>]*>/g, "");
                                return `${checked} ${text}`;
                            })
                            .join("\n");
                    case "delimiter":
                        return "───";
                    case "code":
                        return block.data?.code ?? "";
                    default:
                        return block.data?.text?.replace(/<[^>]*>/g, "") ?? "";
                }
            })
            .filter(Boolean)
            .join("\n");
    } catch {
        // Not JSON at all — return raw string
        return content;
    }
}

export function NoteCard({
    note,
    isTrash = false,
    onDelete,
    onPin,
    onColorChange,
    onDownload
}: NoteCardProps) {
    const router = useRouter();
    const colorClass = noteColors.find((c) => c.value === note.color.toLowerCase())?.class || "bg-[hsl(var(--card))]";
    const plainTextContent = editorJsToPlainText(note.content!);

    const handleCardClick = () => {
        if (!isTrash) {
            router.push(`/card/${note.noteId}`);
        }
    };

    return (
        <motion.div
            layout
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            whileHover={{ y: -4 }}
            transition={{ duration: 0.2 }}
            className={cn(
                "group relative rounded-xl border border-[hsl(var(--border))]/50 overflow-hidden cursor-pointer transition-all duration-200",
                colorClass,
                "hover:border-[hsl(var(--primary))]/30 note-shadow hover:note-shadow-hover",
                isTrash && "cursor-default"
            )}
            onClick={handleCardClick}
        >
            {/* Pin Indicator */}
            {note.pinned && !isTrash && (
                <div className="absolute top-2 right-2 z-10">
                    <Pin className="h-4 w-4 text-[hsl(var(--primary))] fill-[hsl(var(--primary))]" />
                </div>
            )}

            {/* Content */}
            <div className="p-4 py-10 min-h-37.5">
                {note.title && (
                    <h3 className="font-semibold text-[hsl(var(--foreground))] mb-2 line-clamp-2">
                        {note.title}
                    </h3>
                )}
                <div>
                    <p className="text-sm text-[hsl(var(--muted-foreground))] line-clamp-4 whitespace-pre-wrap blur-xs select-none">
                        {plainTextContent}
                    </p>

                    {/* Blur overlay */}
                    <div className="absolute bottom-0 left-0 h-12 bg-linear-to-t from-background to-transparent backdrop-blur-sm" />
                </div>
            </div>

            {/* Actions */}
            <div
                className="absolute bottom-0 left-0 right-0 p-2 cursor-default flex items-center gap-1 transition-opacity bg-linear-to-t from-background/95 via-background/80 to-transparent pt-8"
                onClick={(e) => e.stopPropagation()}
            >
                {!isTrash && (
                    <>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={(e) => {
                                e.stopPropagation();
                                onPin?.(note.noteId);
                            }}
                        >
                            <Pin className={cn("h-4 w-4", note.pinned && "fill-[hsl(var(--primary))] text-[hsl(var(--primary))]")} />
                        </Button>
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <Palette className="h-4 w-4" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="start">
                                {noteColors.map((color) => (
                                    <DropdownMenuItem
                                        key={color.value}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            onColorChange?.(note.noteId, color.value);
                                        }}
                                        className="flex items-center gap-2"
                                    >
                                        <div className={cn("h-4 w-4 rounded-full border", color.class)} />
                                        {color.name}
                                    </DropdownMenuItem>
                                ))}
                            </DropdownMenuContent>
                        </DropdownMenu>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--destructive))]"
                            onClick={(e) => {
                                e.stopPropagation();
                                onDelete(note.noteId);
                            }}
                        >
                            <Trash2 className="h-4 w-4" />
                        </Button>
                    </>
                )}
            </div>

            {/* Arrow icon */}
            <div className="absolute -bottom-2 right-2 -translate-y-1/2" onClick={(e) => e.stopPropagation()}>
                <Button variant='ghost' size="icon" className="h-8 w-8 text-[hsl(var(--muted-foreground))]" onClick={(e) => {
                    e.stopPropagation();
                    onDownload(note.noteId)
                }}>
                    <Download className="h-5 w-5" />
                </Button>
                <Button variant='ghost' size="icon" className="h-8 w-8 text-[hsl(var(--muted-foreground))]" onClick={handleCardClick}>
                    <HiOutlineExternalLink className="h-5 w-5" />
                </Button>
            </div>

            {/* E2E Encryption Badge */}
            <div className="absolute top-2 left-2 transition-opacity">
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[hsl(var(--success))]/20 text-[hsl(var(--success))] font-medium">
                    🔒 Encrypted
                </span>
            </div>
        </motion.div>
    );
}