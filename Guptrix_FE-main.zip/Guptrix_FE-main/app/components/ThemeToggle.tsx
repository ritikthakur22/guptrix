'use client';
import { Moon, Sun } from "lucide-react";
import { useTheme } from "./ThemeProvider";
import { motion } from "framer-motion";

export function ThemeToggle() {
    const { setTheme, theme } = useTheme();
    const isDark = theme === "dark";

    const toggleTheme = () => {
        setTheme(isDark ? "light" : "dark");
    };

    return (
        <button
            onClick={toggleTheme}
            // Removed 'flex' from the main button to prevent layout shifting
            // Added 'shrink-0' to ensure the button never squishes
            className="relative h-8 w-14 shrink-0 cursor-pointer rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--muted))] p-1 transition-colors hover:border-[hsl(var(--primary)/0.5)] focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[hsl(var(--ring))]"
            aria-label="Toggle theme"
        >
            {/* Background Track Icons */}
            <div className="flex h-full w-full items-center justify-between px-1 opacity-20">
                <Sun className="h-3 w-3 text-[hsl(var(--foreground))]" />
                <Moon className="h-3 w-3 text-[hsl(var(--foreground))]" />
            </div>

            {/* The Animated Thumb */}
            <motion.div
                className="absolute top-1 left-1 flex h-6 w-6 items-center justify-center rounded-full bg-[hsl(var(--background))] shadow-md"
                initial={false}
                animate={{
                    // Use a percentage or a smaller, calculated X value
                    // 1.5rem (24px) is exactly the remaining space in a 56px (w-14) wide button with 4px (p-1) padding
                    x: isDark ? 24 : 0,
                }}
                transition={{
                    type: "spring",
                    stiffness: 500,
                    damping: 30,
                }}
            >
                {isDark ? (
                    <Moon className="h-3.5 w-3.5 text-[hsl(var(--foreground))]" />
                ) : (
                    <Sun className="h-3.5 w-3.5 text-[hsl(var(--foreground))]" />
                )}
            </motion.div>

            <span className="sr-only">Toggle theme</span>
        </button>
    );
}