"use client";

import { motion, AnimatePresence } from "framer-motion";
import { Plus, NotebookPen, RotateCcw, Trash2, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { editorJsToPlainText, NoteCard } from "./NoteCard";
import { Note } from "../store/note/note.types";
import { noteColors } from "../constants/noteColors";
import { cn } from "@/lib/utils";
import { useState } from "react";
import TitleDialog from "./TitleDialog";
import ImportNote from "./ImportNote";

interface NotesGridProps {
    notes: Note[];
    isTrash?: boolean;
    onAddNote?: (title: string) => void;
    onDeleteNote: (id: string) => void;
    onDownloadNote?: (id: string) => void;
    onUploadNote?: (file: File) => Promise<void> | void;
    // onUploadNote: (id: string, encryptedTitle: string, encryptedContent: string, encryptedcanvasData: string, color: string, pinned: string,) => void;
    onRestoreNote?: (id: string) => void;
    onPinNote?: (id: string) => void;
    onColorChange?: (id: string, color: string) => void;
}

export function NotesGrid({
    notes,
    isTrash = false,
    onAddNote,
    onDeleteNote,
    onDownloadNote,
    onUploadNote,
    onRestoreNote,
    onPinNote,
    onColorChange,
}: NotesGridProps) {
    const pinnedNotes = notes.filter((note) => note.pinned);
    const unpinnedNotes = notes.filter((note) => !note.pinned);

    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [isImportNoteDialogOpen, setIsImportNoteDialogOpen] = useState(false);

    const handleAddNewNoteClick = () => {
        setIsDialogOpen(true);
    };

    const handleImportNoteClick = () => {
        setIsImportNoteDialogOpen(true);
    }

    const handleDialogConfirm = (newTitle: string) => {
        if (onAddNote) {
            onAddNote(newTitle);
        }
    };

    const handleImportConfirm = async (file: File) => {
        if (onUploadNote) {
            await onUploadNote(file);
        }
    };

    return (
        <div className="p-6">
            {/* Header */}
            {/* <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6"> */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
                <motion.h1
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="text-2xl font-bold"
                >
                    {isTrash ? "Trash" : "My Notes"}
                </motion.h1>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
                    {!isTrash && onAddNote && (
                        <>
                            <Button
                                onClick={handleAddNewNoteClick}
                                className="gradient-primary text-[hsl(var(--primary-foreground))] w-full sm:w-auto"
                            >
                                <Plus className="h-4 w-4 mr-2" />
                                New Note
                            </Button>

                            <Button
                                onClick={handleImportNoteClick}
                                className="gradient-primary text-[hsl(var(--primary-foreground))] w-full sm:w-auto"
                            >
                                <Upload className="h-4 w-4 mr-2" />
                                Upload Note
                            </Button>
                        </>
                    )}
                </div>
            </div>

            {/* Empty State */}
            {notes.length === 0 && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex flex-col items-center justify-center py-20 text-center"
                >
                    <div className="p-4 rounded-full bg-muted mb-4">
                        <NotebookPen className="h-16 w-16 text-[hsl(var(--muted-foreground))]" />
                    </div>
                    <h3 className="text-lg font-medium mb-2">
                        {isTrash ? "Trash is empty" : "No notes yet"}
                    </h3>
                    <p className="text-[hsl(var(--muted-foreground))] mb-4">
                        {isTrash ? "Deleted notes will appear here" : "Create your first encrypted note"}
                    </p>
                    {!isTrash && onAddNote && (
                        <Button
                            // onClick={onAddNote}
                            onClick={handleAddNewNoteClick}
                            className="gradient-primary text-[hsl(var(--primary-foreground))]"
                        >
                            <Plus className="h-4 w-4 mr-2" />
                            Create Note
                        </Button>
                    )}
                </motion.div>
            )}

            <TitleDialog
                open={isDialogOpen}
                setOpen={setIsDialogOpen}
                setTitle={handleDialogConfirm}
            />

            <ImportNote
                open={isImportNoteDialogOpen}
                setOpen={setIsImportNoteDialogOpen}
                onImport={handleImportConfirm}
            />

            {/* Trash Notes - Different Layout */}
            {isTrash && notes.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    <AnimatePresence mode="popLayout">
                        {notes.map((note) => (
                            <motion.div
                                key={note.noteId}
                                layout
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, scale: 0.95 }}
                                transition={{ duration: 0.2 }}
                                className={cn(
                                    "group relative flex flex-col rounded-xl border border-[hsl(var(--border))]/60 bg-card p-5 shadow-sm hover:shadow-md hover:border-[hsl(var(--border))] transition-all",
                                    noteColors.find((c) => c.value === note.color.toLowerCase())?.class || "bg-[hsl(var(--card))]"
                                )}
                            >
                                {/* E2E Encryption Badge */}
                                <div className="absolute top-2 right-2 transition-opacity">
                                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[hsl(var(--success))]/20 text-[hsl(var(--success))] font-medium">
                                        🔒 Encrypted
                                    </span>
                                </div>

                                {/* Note Content - Shows DECRYPTED data */}
                                <div className="flex-1 pt-5">
                                    {note.title && (
                                        <h3 className="font-bold text-[hsl(var(--foreground))] leading-tight mb-2 line-clamp-2">
                                            {note.title}
                                        </h3>
                                    )}
                                    <div>
                                        <p className="text-sm text-[hsl(var(--muted-foreground))] line-clamp-4 whitespace-pre-wrap blur-xs select-none">
                                            {/* {note.content} */}
                                            {editorJsToPlainText(note.content!)}
                                        </p>

                                        {/* Blur overlay */}
                                        <div className="absolute bottom-0 left-0 h-12 bg-linear-to-t from-background to-transparent backdrop-blur-sm" />
                                    </div>
                                </div>

                                {/* Action Buttons */}
                                <div className="flex items-center gap-2 mt-6">
                                    <Button
                                        variant="secondary"
                                        size="sm"
                                        className="flex-1 h-9 rounded-lg font-medium bg-[#F39D25] text-white hover:bg-[#F39D25]/80"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            onRestoreNote?.(note.noteId);
                                        }}
                                    >
                                        <RotateCcw className="h-3.5 w-3.5 mr-2 stroke-[2.5px]" />
                                        Restore
                                    </Button>

                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        className="flex-1 h-9 rounded-lg text-[hsl(var(--destructive))] hover:bg-[hsl(var(--destructive))]/10 hover:text-[hsl(var(--destructive))] font-medium"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            onDeleteNote(note.noteId);
                                        }}
                                    >
                                        <Trash2 className="h-3.5 w-3.5 mr-2 stroke-[2.5px]" />
                                        Delete
                                    </Button>
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                </div>
            )
            }

            {/* Pinned Notes */}
            {
                !isTrash && pinnedNotes.length > 0 && (
                    <div className="mb-8">
                        <h2 className="text-sm font-medium text-[hsl(var(--muted-foreground))] mb-3 uppercase tracking-wide">
                            Pinned
                        </h2>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                            <AnimatePresence mode="popLayout">
                                {pinnedNotes.map((note) => (
                                    onDownloadNote && (
                                        <NoteCard
                                            key={note.noteId}
                                            note={note}
                                            onDelete={onDeleteNote}
                                            onDownload={onDownloadNote}
                                            onPin={onPinNote}
                                            onColorChange={onColorChange}
                                        />
                                    )
                                ))}
                            </AnimatePresence>
                        </div>
                    </div>
                )
            }

            {/* Other Notes */}
            {
                !isTrash && unpinnedNotes.length > 0 && (
                    <div>
                        {pinnedNotes.length > 0 && (
                            <h2 className="text-sm font-medium text-[hsl(var(--muted-foreground))] mb-3 uppercase tracking-wide">
                                Others
                            </h2>
                        )}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                            <AnimatePresence mode="popLayout">
                                {unpinnedNotes.map((note) => (
                                    onDownloadNote && (
                                        <NoteCard
                                            key={note.noteId}
                                            note={note}
                                            onDelete={onDeleteNote}
                                            onDownload={onDownloadNote}
                                            onPin={onPinNote}
                                            onColorChange={onColorChange}
                                        />
                                    )
                                ))}
                            </AnimatePresence>
                        </div>
                    </div>
                )
            }
        </div >
    );
}