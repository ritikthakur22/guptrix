"use client"

import { useEffect, useState } from 'react'
import { Toaster } from 'sonner'

type ToasterTheme = "light" | "dark";

export function ToastProvider() {
    const [savedTheme, setSavedTheme] = useState<ToasterTheme>("dark")

    useEffect(() => {
        const syncTheme = () => {
            const theme = localStorage.getItem('notes-ui-theme') as ToasterTheme | null
            if (theme) setSavedTheme(theme);
        }

        // Initial sync
        syncTheme();

        // Listen for storage changes (other tabs)
        window.addEventListener('storage', syncTheme);

        // Listen for class changes on <html> (local toggle)
        const observer = new MutationObserver(syncTheme);
        observer.observe(document.documentElement, {
            attributes: true,
            attributeFilter: ['class', 'data-theme']
        });

        return () => {
            window.removeEventListener('storage', syncTheme);
            observer.disconnect();
        };
    }, []);

    return (
        <Toaster
            position="bottom-right"
            richColors
            closeButton
            expand={true}
            duration={2500}
            theme={savedTheme}
            swipeDirections={['right', 'bottom']}
            toastOptions={{
                // glass-card for the blur, note-shadow for the 'sticky note' depth
                className: "note-shadow glass-card !border-border !text-foreground",
                classNames: {
                    closeButton: "!left-auto !right-[-14px] !top-[-4px] !bg-background !border-border",
                },
                style: {
                    padding: '16px',
                    borderRadius: 'var(--radius)',
                    // Explicitly passing the duration to the CSS variable
                    "--duration": "3000ms",
                } as React.CSSProperties,
            }}
        />
    )
}