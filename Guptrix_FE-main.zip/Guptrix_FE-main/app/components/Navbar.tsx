'use client'

import { motion } from "framer-motion";
import { Lock, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "./ThemeToggle";
import Link from "next/link";
import { useState } from "react";
import Image from "next/image";

export function Navbar() {
    const [isOpen, setIsOpen] = useState(false);

    const scrollToSection = (id: string) => {
        // Close mobile menu if open
        setIsOpen(false);

        // Handle home/top scroll
        if (id === "home" || id === "/") {
            window.scrollTo({
                top: 0,
                behavior: "smooth",
            });
            return;
        }

        // Remove # if present
        const sectionId = id.replace('#', '');
        const element = document.getElementById(sectionId);

        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    };

    return (
        <motion.nav
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="fixed top-0 left-0 right-0 z-50 glass border-b border-[hsl(var(--border))]/50"
        >
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    {/* Logo */}
                    <button
                        onClick={() => scrollToSection("home")}
                        className="flex items-center gap-2 cursor-pointer"
                    >
                        <motion.div
                            whileHover={{ rotate: 10, scale: 1.1 }}
                            transition={{ type: "spring", stiffness: 300 }}
                        >
                            <Image src='/guptrix.png' alt="syncgaurd" loading="eager" width={45} height={45} />
                        </motion.div>
                        <span className="text-xl font-bold gradient-text">Guptrix</span>
                    </button>

                    {/* Desktop Nav */}
                    <div className="hidden md:flex items-center gap-6">
                        <button
                            onClick={() => scrollToSection('home')}
                            className="text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] transition-colors cursor-pointer"
                        >
                            Home
                        </button>
                        <button
                            onClick={() => scrollToSection('features')}
                            className="text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] transition-colors cursor-pointer"
                        >
                            Features
                        </button>
                        <ThemeToggle />
                        <Link href="/auth/login">
                            <Button variant="ghost">Sign In</Button>
                        </Link>
                        <Link href="/auth/signup">
                            <Button className="gradient-primary text-[hsl(var(--primary-foreground))]">
                                <Lock className="mr-2 h-4 w-4" />
                                Sign Up
                            </Button>
                        </Link>
                    </div>

                    {/* Mobile Menu Button */}
                    <div className="md:hidden flex items-center gap-2">
                        <ThemeToggle />
                        <Button variant="ghost" size="icon" onClick={() => setIsOpen(!isOpen)}>
                            {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                        </Button>
                    </div>
                </div>

                {/* Mobile Nav */}
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="md:hidden py-4 space-y-3"
                    >
                        <button
                            onClick={() => scrollToSection('home')}
                            className="block w-full text-left text-muted-foreground hover:text-foreground transition-colors"
                        >
                            Home
                        </button>
                        <button
                            onClick={() => scrollToSection('features')}
                            className="block w-full text-left text-muted-foreground hover:text-foreground transition-colors"
                        >
                            Features
                        </button>
                        <div className="flex flex-col gap-2 pt-2">
                            <Link href="/auth/login">
                                <Button variant="ghost" className="w-full">Sign In</Button>
                            </Link>
                            <Link href="/auth/signup">
                                <Button className="w-full gradient-primary text-primary-foreground">
                                    <Lock className="mr-2 h-4 w-4" />
                                    Get Started
                                </Button>
                            </Link>
                        </div>
                    </motion.div>
                )}
            </div>
        </motion.nav>
    );
}