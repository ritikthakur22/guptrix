"use client";

import { motion } from "framer-motion";
import { ThemeToggle } from "./ThemeToggle";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { Separator } from "@/components/ui/separator";
import { useQuery } from "@tanstack/react-query";
import { getCurrentUserProfile } from "../lib/api/user";
import UserHydrator from "./provider/UserHydrator";
import { useUser } from "../store/auth/auth.store";

export function AuthNavbar() {

    const user = useUser((state) => state.user);

    const { data, error } = useQuery({
        queryKey: ["user-data"],
        queryFn: () => getCurrentUserProfile(),
        enabled: !user,
    });

    const transformedUserStats = data?.data
        ? (Array.isArray(data.data) ? data.data[0] : data.data)
        : null;

    const finalUser = transformedUserStats && {
        _id: transformedUserStats._id,
        username: transformedUserStats.username,
        email: transformedUserStats.email,
        salt: transformedUserStats.salt,
        encryptedAESKey: transformedUserStats.encryptedAESKey,
        keyIV: transformedUserStats.keyIV,
        userId: transformedUserStats.userId,
    };


    return (
        <motion.header
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="sticky top-0 z-30 bg-[hsl(var(--sidebar-background))] backdrop-blur-md border-b border-[hsl(var(--border))] px-2 lg:px-3 py-3"
        >
            {!user && finalUser && <UserHydrator user={finalUser} />}
            <div className="flex items-center justify-between gap-4">
                <div className="flex flex-1 gap-3 lg:gap-15">
                    <div className="flex gap-2 lg:gap-3 items-center">
                        <SidebarTrigger />
                        <Separator orientation="vertical" className="mt-0.5 data-[orientation=vertical]:h-8" />
                    </div>
                </div>

                {/* Right Section */}
                <div className="flex items-center gap-2">
                    <ThemeToggle />
                </div>
            </div>
        </motion.header>
    );
}
