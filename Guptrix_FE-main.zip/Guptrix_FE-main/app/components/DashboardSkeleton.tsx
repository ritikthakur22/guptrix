import { Skeleton } from "@/components/ui/skeleton";

const DashboardSkeleton = () => {
    return (
        <div className='flex bg-[hsl(var(--background))] h-screen overflow-hidden'>
            {/* Sidebar - Hidden on mobile, shown from 'lg' screens up */}
            <aside className='hidden lg:flex h-full pt-2 w-64 flex-col px-5 border-r border-white/5 shrink-0'>
                <div className='flex-1'>
                    <div className='flex gap-5'>
                        <Skeleton className="size-10 rounded-full shrink-0" />
                        <Skeleton className="mt-1.5 h-8 w-full" />
                    </div>
                    <div className='mt-10 flex flex-col gap-3'>
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-full" />
                    </div>
                </div>
                <div className='pb-5'>
                    <Skeleton className="h-4 w-full" />
                </div>
            </aside>

            {/* Main Content Area */}
            <main className='flex-1 flex flex-col h-full overflow-hidden'>
                {/* Navbar */}
                <nav className='h-16 flex items-center justify-between px-4 md:px-6 border-b shrink-0'>
                    <div className='flex items-center gap-4 md:gap-10 flex-1'>
                        {/* Mobile Menu Icon Placeholder */}
                        <div className='flex items-center gap-3'>
                            <Skeleton className="h-6 w-6 shrink-0" />
                            <div className='hidden md:block h-8 w-px bg-white/10' />
                        </div>
                        {/* Search Bar - Hidden on extra small mobile */}
                        <div className='hidden sm:block w-full max-w-xl'>
                            <Skeleton className="h-8 w-full" />
                        </div>
                    </div>
                    <Skeleton className="h-6 w-10 shrink-0" />
                </nav>

                {/* Page Content */}
                <div className='p-4 md:p-6 overflow-y-auto flex-1 space-y-8 md:space-y-10'>
                    {/* Page Header */}
                    <div className='flex flex-row justify-between items-center gap-4'>
                        <Skeleton className="h-8 md:h-10 w-32 md:w-48" />
                        <Skeleton className="h-8 md:h-10 w-24 md:w-32 rounded-lg" />
                    </div>

                    {/* PINNED SECTION */}
                    <div>
                        <Skeleton className="h-4 w-16 mb-4 md:mb-6" />
                        {/* Grid: 1 col on mobile, 2 on tablet, 3 on desktop */}
                        <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4'>
                            {[1, 2, 3].map((i) => (
                                <CardSkeleton key={i} hasPin />
                            ))}
                        </div>
                    </div>

                    {/* OTHERS SECTION */}
                    <div>
                        <Skeleton className="h-4 w-16 mb-4 md:mb-6" />
                        <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4'>
                            {[1, 2, 3].map((i) => (
                                <CardSkeleton key={i} />
                            ))}
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

// Extracted Card component to keep the code DRY
const CardSkeleton = ({ hasPin = false }: { hasPin?: boolean }) => (
    <div className='p-4 rounded-xl border border-white/5 bg-white/5 h-48 md:h-52 relative flex flex-col justify-between'>
        {hasPin && <Skeleton className="size-5 absolute top-4 right-4 rounded-sm" />}
        <div className='space-y-3'>
            <Skeleton className="h-6 w-3/4" />
            <Skeleton className="h-3 w-full" />
            <Skeleton className="h-3 w-full" />
            <Skeleton className="h-3 w-2/3" />
        </div>
        <div className="flex gap-3">
            <Skeleton className="size-4 rounded-sm" />
            <Skeleton className="size-4 rounded-sm" />
            <Skeleton className="size-4 rounded-sm" />
        </div>
    </div>
);

export default DashboardSkeleton;