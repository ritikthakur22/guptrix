'use client'
import { motion } from "framer-motion";
import { Shield, Lock, Zap, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useEffect, useRef } from "react";
import gsap from "gsap";

export function Hero() {
  const floatingNotesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (floatingNotesRef.current) {
      const notes = floatingNotesRef.current.querySelectorAll('.floating-note');
      
      notes.forEach((note, index) => {
        gsap.to(note, {
          y: "random(-20, 20)",
          x: "random(-10, 10)",
          rotation: "random(-5, 5)",
          duration: 3 + index * 0.5,
          repeat: -1,
          yoyo: true,
          ease: "sine.inOut",
        });
      });
    }
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] as const },
    },
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16" id="home">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-linear-to-br from-[hsl(var(--primary))]/5 via-[hsl(var(--background))] to-[hsl(var(--accent))]/5" />
      
      {/* Floating Notes Background */}
      <div ref={floatingNotesRef} className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="floating-note absolute top-20 left-[10%] w-32 h-24 rounded-lg bg-[hsl(var(--note-yellow))] note-shadow opacity-60 rotate-6" />
        <div className="floating-note absolute top-40 right-[15%] w-28 h-20 rounded-lg bg-[hsl(var(--note-green))] note-shadow opacity-60 -rotate-3" />
        <div className="floating-note absolute bottom-32 left-[20%] w-36 h-28 rounded-lg bg-[hsl(var(--note-blue))] note-shadow opacity-60 rotate-12" />
        <div className="floating-note absolute bottom-48 right-[25%] w-24 h-18 rounded-lg bg-[hsl(var(--note-pink))] note-shadow opacity-60 -rotate-6" />
        <div className="floating-note absolute top-60 left-[40%] w-20 h-16 rounded-lg bg-[hsl(var(--note-purple))] note-shadow opacity-40 rotate-3" />
      </div>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="relative z-10 max-w-5xl mx-auto px-4 text-center"
      >
        {/* Badge */}
        <motion.div
          variants={itemVariants}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-bg border badge-border mb-8"
        >
          <Shield className="h-4 w-4 text-[hsl(var(--primary))]" />
          <span className="text-sm font-medium text-[hsl(var(--primary))]">End-to-End Encrypted</span>
        </motion.div>

        {/* Headline */}
        <motion.h1
          variants={itemVariants}
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6"
        >
          Your thoughts,{" "}
          <span className="gradient-text">completely private</span>
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          variants={itemVariants}
          className="text-lg sm:text-xl text-[hsl(var(--muted-foreground))] max-w-2xl mx-auto mb-10"
        >
          Capture your ideas with military-grade encryption. Only you can read your notes.
          No one else—not even us.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          variants={itemVariants}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Link href="/auth/signup">
            <Button size="lg" className="gradient-primary text-[hsl(var(--primary-foreground))] group px-8">
              Start for Free
              <motion.span
                className="ml-2"
                animate={{ x: [0, 4, 0] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
              >
                <ArrowRight className="h-5 w-5" />
              </motion.span>
            </Button>
          </Link>
          {/* needs to improve here */}
          <Link href="/auth/login">
            <Button size="lg" variant="outline" className="group px-8">
              Sign In
              <Lock className="ml-2 h-4 w-4 group-hover:scale-110 transition-transform" />
            </Button>
          </Link>
        </motion.div>

        {/* Trust Badges */}
        <motion.div
          variants={itemVariants}
          className="flex flex-wrap items-center justify-center gap-6 mt-12 text-[hsl(var(--muted-foreground))]"
        >
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-[hsl(var(--success))]" />
            <span className="text-sm">256-bit AES Encryption</span>
          </div>
          <div className="flex items-center gap-2">
            <Lock className="h-5 w-5 text-[hsl(var(--success))]" />
            <span className="text-sm">Zero-Knowledge Architecture</span>
          </div>
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-[hsl(var(--success))]" />
            <span className="text-sm">Instant Sync</span>
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}
