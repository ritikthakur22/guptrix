'use client'

import { retrieveAESKey } from "@/app/lib/crypto-key-manager";
import { decryptNote } from "@/app/lib/crypto.service";
import { useNoteStore } from "@/app/store/note/note.store";
import { EncryptedNote, Note } from "@/app/store/note/note.types";
import { useEffect } from "react";

interface NoteHydratorProps {
  notes?: EncryptedNote[] | null;
  trashNotes?: EncryptedNote[] | null;
}

const NoteHydrator = ({ notes, trashNotes }: NoteHydratorProps) => {
  const setNote = useNoteStore((state) => state.setNotes);
  const clearNote = useNoteStore((state) => state.clearNotes);
  const setTrashNote = useNoteStore((state) => state.setTrashNotes);
  const clearTrashNote = useNoteStore((state) => state.clearTrashNotes);

  useEffect(() => {
    const decryptAndSetNotes = async (
      notesList?: EncryptedNote[],
      trashList?: EncryptedNote[]
    ) => {
      try {
        const aesKey = await retrieveAESKey();

        if (!aesKey) {
          console.warn("AES key not available yet");
          return;
        }

        const decryptList = async (list: EncryptedNote[]): Promise<Note[]> => {
          return Promise.all(
            list.map(async (note) => {
              try {
                let content;
                const title = await decryptNote(note.title, note.titleIV, aesKey);
                if (note.content && note.contentIV) {
                  content = await decryptNote(note.content, note.contentIV, aesKey);
                }

                // ✅ Decrypt canvasData
                let canvasData;
                if (note.canvasData && note.canvasIV) {
                  canvasData = await decryptNote(note.canvasData, note.canvasIV, aesKey);
                }

                return { ...note, title, content, canvasData };
              } catch (e) {
                console.error("Decrypt failed for note:", note.noteId, e);
                return {
                  ...note,
                  title: "[Decryption Failed]",
                  content: "[Unable to decrypt content]",
                };
              }
            })
          );
        };

        if (notesList) {
          const decryptedNotes = await decryptList(notesList);
          setNote(decryptedNotes);
        }
        if (trashList) {
          const decryptedTrashNotes = await decryptList(trashList);
          setTrashNote(decryptedTrashNotes);
        }

      } catch (error) {
        console.error("Error during decryption:", error);
        clearNote();
        clearTrashNote();
      }
    };

    if (!notes && !trashNotes) {
      clearNote();
      clearTrashNote();
      return;
    }

    decryptAndSetNotes(notes ?? [], trashNotes ?? []);
  }, [notes, trashNotes, setNote, setTrashNote, clearNote, clearTrashNote]);

  return null;
};

export default NoteHydrator;
