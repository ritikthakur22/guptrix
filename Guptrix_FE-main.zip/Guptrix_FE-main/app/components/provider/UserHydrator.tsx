'use client'
import { useUser } from "@/app/store/auth/auth.store";
import { IUser } from "@/app/store/auth/auth.type"
import { useEffect } from "react"


interface UserHydratorProps {
    user: IUser | null;
}

const UserHydrator = ({ user }: UserHydratorProps) => {
    const setUser = useUser((state) => state.setUser);
    const clearUser = useUser((state) => state.clearUser);

    useEffect(() => {
        if (user) {
            setUser(user);
        } else {
            clearUser();
        }
    }, [user, setUser, clearUser])

    return null;
}

export default UserHydrator;