"use client";

import { useState, DragEvent, useRef } from "react";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { UploadCloud, Loader2, FileText } from "lucide-react";
import { toast } from "sonner";

interface ImportNoteProps {
    open: boolean;
    setOpen: (open: boolean) => void;
    onImport: (file: File) => Promise<void> | void;
}

const ImportNote = ({ open, setOpen, onImport }: ImportNoteProps) => {
    const [loading, setLoading] = useState(false);
    const [dragActive, setDragActive] = useState(false);
    const [fileName, setFileName] = useState<string | null>(null);
    const [selectedFile, setSelectedFile] = useState<File | null>(null);

    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFile = (file: File) => {
        if (!file.name.endsWith(".gnote") && !file.name.endsWith(".json")) {
            toast.error("Invalid file type");
            return;
        }

        setSelectedFile(file);
        setFileName(file.name);
    };

    const handleDrop = (e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        setDragActive(false);

        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            handleFile(e.dataTransfer.files[0]);
        }
    };

    const handleDrag = (e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();

        if (e.type === "dragenter" || e.type === "dragover") {
            setDragActive(true);
        } else if (e.type === "dragleave") {
            setDragActive(false);
        }
    };

    const handleBrowse = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) handleFile(file);
    };

    const handleImport = async () => {
        if (!selectedFile) {
            toast.error("Please select a file first");
            return;
        }

        try {
            setLoading(true);

            await onImport(selectedFile);

            setSelectedFile(null);
            setFileName(null);
            setOpen(false);
        } catch (err) {
            console.error(err);
            toast.error("Failed to import note");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogContent className="glass-card">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <UploadCloud className="h-5 w-5 text-primary" />
                        Import Encrypted Note
                    </DialogTitle>

                    <DialogDescription>
                        Drag & drop your exported <b>.gnote</b> file or browse your device.
                    </DialogDescription>
                </DialogHeader>

                <div className="space-y-4 pt-4">

                    <div
                        onDrop={handleDrop}
                        onDragEnter={handleDrag}
                        onDragOver={handleDrag}
                        onDragLeave={handleDrag}
                        className={`border-2 border-dashed rounded-xl p-8 text-center transition cursor-pointer
                        ${dragActive
                                ? "border-primary bg-primary/10"
                                : "border-muted-foreground/30 hover:border-primary/60"
                            }`}
                    >
                        <UploadCloud className="mx-auto h-10 w-10 text-muted-foreground mb-3" />

                        <p className="text-sm text-muted-foreground">
                            Drag & drop your note file here
                        </p>

                        <p className="text-xs text-muted-foreground mt-1">
                            Supported format: .gnote
                        </p>

                        <div className="mt-4">
                            <Button
                                variant="secondary"
                                onClick={handleBrowse}
                            >
                                Browse File
                            </Button>

                            <input
                                ref={fileInputRef}
                                type="file"
                                accept=".gnote,.json"
                                onChange={handleFileChange}
                                className="hidden"
                            />
                        </div>
                    </div>

                    {fileName && (
                        <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                            <FileText className="h-5 w-5 text-primary" />
                            <p className="text-sm truncate">{fileName}</p>
                        </div>
                    )}

                    <Button
                        className="w-full gradient-primary"
                        disabled={!selectedFile || loading}
                        onClick={handleImport}
                    >
                        {loading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Importing...
                            </>
                        ) : (
                            "Import Note"
                        )}
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default ImportNote;