import axios from "axios";
import { useUser } from "../store/auth/auth.store";
import { getToken } from "../components/Token";

const api = axios.create({
    baseURL: process.env.NEXT_PUBLIC_API_URL,
    headers: { 'Content-Type': 'application/json' },
    withCredentials: true,
});

// REQUEST: Get the token from our bridge route if we don't have it
api.interceptors.request.use(async (config) => {
    // get the token from store
    const token = await getToken();

    // Only try to fetch the token if it's not already on the header
    if (!config.headers['Authorization']) {
        try {
            if (token) {
                config.headers['Authorization'] = `Bearer ${token}`;

            } else {
                // Internal bridge call to get token from secure cookies
                const res = await axios.get('/api/auth/token');
                if (res.data.token) {
                    config.headers['Authorization'] = `Bearer ${res.data.token}`;
                }
            }
        } catch (e) {
            // No token found, proceed (backend will 401)
        }
    }
    return config;
});

// RESPONSE: Handle 401s and Refresh
api.interceptors.response.use(
    (response) => response,
    async (error) => {
        const originalRequest = error.config;

        if (error.response?.status === 401 && !originalRequest._retry) {
            originalRequest._retry = true;

            try {
                // Call internal refresh route
                const refreshRes = await axios.get('/api/auth/refresh');
                const newToken = refreshRes.data.accessToken;
                if (newToken) {
                    // Retry with the NEW token
                    originalRequest.headers['Authorization'] = `Bearer ${newToken}`;
                    return api(originalRequest);
                }
            } catch (refreshError) {
                if (typeof window !== "undefined") {
                    const currentPath = window.location.pathname;

                    const authPages = [
                        "/auth/login",
                        "/auth/signup",
                        "/auth/forgot-password",
                        "/auth/reset-password",
                        "/auth/verify-otp",
                    ];

                    if (!authPages.includes(currentPath)) {
                        window.location.href = "/auth/login?expired=true";
                    }
                }

                return Promise.reject(refreshError);
            }
        }
        return Promise.reject(error);
    }
);

export default api;