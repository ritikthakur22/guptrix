// import axios from "axios";
import api from "../axios";
import * as url from "./url-helpers";

export const getCurrentUserProfile = async (token?: string) => {
    try {
        const response = await api.get(url.GET_CURRENT_USER)
        return {
            status: response.status,
            success: true,
            data: response.data.user
        };
    } catch (error: any) {
        console.error(error, "during calling current user profile");
        return {
            status: error.response?.status || 500,
            success: false,
            data: error.response?.data || { error: 'Network error' }
        };
    }
}