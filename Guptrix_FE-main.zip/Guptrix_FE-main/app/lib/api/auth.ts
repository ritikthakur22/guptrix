import * as url from './url-helpers';
import axios from 'axios';

export const register = async (data: any) => {
    try {
        const response = await axios.post(url.SIGN_UP, data);
        return {
            status: response.status,
            data: response.data,
            success: true
        };
    } catch (error: any) {
        // Handle error gracefully without throwing
        return {
            status: error.response?.status || 500,
            data: error.response?.data || { message: 'Network error' },
            success: false
        };
    }
};

export const verify_otp = async (data: any) => {
    try {
        const response = await axios.post(url.VERIFY_OTP, data);
        return {
            status: response.status,
            data: response.data,
            success: true
        };
    } catch (error: any) {
        // Handle error gracefully without throwing
        return {
            status: error.response?.status || 500,
            data: error.response?.data || { message: 'Network error' },
            success: false
        };
    }
};

export const resend_otp = async (data: any) => {
    try {
        const response = await axios.post(url.RESEND_OTP, data);
        return {
            status: response.status,
            data: response.data,
            success: true
        };
    } catch (error: any) {
        // Handle error gracefully without throwing
        return {
            status: error.response?.status || 500,
            data: error.response?.data || { message: 'Network error' },
            success: false
        };
    }
};

export const forgot_password = async (data: any) => {
    try {
        const response = await axios.post(url.FORGOT_PASSWORD, data);
        return {
            status: response.status,
            data: response.data,
            success: true
        }
    } catch (error: any) {
        return {
            status: error.response?.status || 500,
            data: error.response?.data || { message: 'Network error' },
            success: false
        }
    }
}

export const reset_forgot_password = async (data: any) => {
    try {
        const response = await axios.post(url.RESET_FORGOT_PASSWORD, data);
        return {
            status: response.status,
            data: response.data,
            success: true
        }
    } catch (error: any) {
        return {
            status: error.response?.status || 500,
            data: error.response?.data || { message: 'Network error' },
            success: false
        }
    }
}

export const recoverLogin = async (email: string) => {
    try {
        const response = await axios.get(`${url.GET_RECOVERY_CREDS}/${email}`);
        return {
            status: response.status,
            data: response.data,
            success: true
        }
    } catch (error: any) {
        return {
            status: error.response?.status || 500,
            data: error.response?.data || { message: 'Network error' },
            success: false
        }
    }
}

export const logout = async () => {
    const response = await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include',
    });
    return response.json();
};
