import * as url from './url-helpers'
import api from "../axios";
import axios from 'axios';
import { encryptNote, decryptNote } from '@/app/lib/crypto.service';

interface CreateNoteParams {
    userAESKey: CryptoKey;
    title?: string;
    content?: string;
    color?: string;
    pinned?: boolean;
}

interface UpdateNoteParams {
    noteId: string;
    userAESKey: CryptoKey;
    title?: string;
    content?: string;
    canvasData?: string;
    color?: string;
    pinned?: boolean;
}

// Helper function to decrypt a single note
const decryptNoteData = async (note: any, userAESKey: CryptoKey) => {
    try {
        const decryptedTitle = await decryptNote(note.title, note.titleIV, userAESKey);
        let decryptedContent;
        if (note.content && note.contentIV) {
            decryptedContent = await decryptNote(note.content, note.contentIV, userAESKey);
        }

        return {
            ...note,
            title: decryptedTitle,
            content: decryptedContent,
        };
    } catch (error) {
        console.error('Failed to decrypt note:', note.noteId, error);
        return {
            ...note,
            title: '[Decryption Failed]',
            content: '[Unable to decrypt content]',
        };
    }
};

// Helper function to decrypt multiple notes
const decryptNotes = async (notes: any[], userAESKey: CryptoKey) => {
    return Promise.all(notes.map(note => decryptNoteData(note, userAESKey)));
};

/**
 * Create a new note with encryption
 */
export const createNote = async ({
    userAESKey,
    title = "Untitled Note",
    // content = "Notes...",
    color = "default",
    pinned = false,
}: CreateNoteParams) => {
    try {
        // Encrypt title
        const encryptedTitleObj = await encryptNote(title, userAESKey);
        // Encrypt content
        // const encryptedContentObj = await encryptNote(content, userAESKey);

        const response = await api.post(url.CREATE_NOTE, {
            title: encryptedTitleObj.ciphertext,
            titleIV: encryptedTitleObj.iv,
            // content: encryptedContentObj.ciphertext,
            // contentIV: encryptedContentObj.iv,
            color,
            pinned,
        });

        // Decrypt the returned note before sending it back
        if (response.data.note) {
            const decryptedNote = await decryptNoteData(response.data.note, userAESKey);
            return {
                status: response.status,
                data: {
                    ...response.data,
                    note: decryptedNote
                },
                success: true,
            };
        }

        return {
            status: response.status,
            data: response.data,
            success: true,
        };
    } catch (error: any) {
        return {
            status: error.response?.status || 500,
            data: error.response?.data || { error: 'Network error' },
            success: false,
        };
    }
};

/**
 * Update an existing note with encryption
 */
export const updateNote = async ({
    noteId,
    userAESKey,
    title,
    content,
    canvasData,
    color,
    pinned,
}: UpdateNoteParams) => {
    try {
        const payload: any = {};

        // Only encrypt and include fields that are provided
        if (title !== undefined) {
            const encryptedTitle = await encryptNote(title, userAESKey);
            payload.title = encryptedTitle.ciphertext;
            payload.titleIV = encryptedTitle.iv;
        }

        if (content !== undefined) {
            const encryptedContent = await encryptNote(content, userAESKey);
            payload.content = encryptedContent.ciphertext;
            payload.contentIV = encryptedContent.iv;
        }

        if (canvasData !== undefined) {
            const encryptedContent = await encryptNote(canvasData, userAESKey);
            payload.canvasData = encryptedContent.ciphertext;
            payload.canvasIV = encryptedContent.iv;
        }

        if (color !== undefined) payload.color = color;
        if (pinned !== undefined) payload.pinned = pinned;

        const response = await api.patch(`${url.UPDATE_NOTE}/${noteId}`, payload);

        // Decrypt the returned note
        if (response.data.updatedNote) {
            const decryptedNote = await decryptNoteData(response.data.updatedNote, userAESKey);
            return {
                status: response.status,
                data: {
                    ...response.data,
                    updatedNote: decryptedNote
                },
                success: true,
            };
        }

        return {
            status: response.status,
            data: response.data,
            success: true,
        };
    } catch (error: any) {
        return {
            status: error.response?.status || 500,
            data: error.response?.data || { error: "Network error" },
            success: false,
        };
    }
};

/**
 * Fetch notes WITHOUT decryption - for server-side use
 * Returns encrypted data that will be decrypted client-side
 */
export const getNotes = async (
    token: string,
    page?: number | string,
    limit?: number | string,
) => {
    try {
        const response = await axios.get(url.GET_NOTE, {
            params: {
                page: page || 1,
                limit: limit || 10,
            },
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            withCredentials: true,
        });

        // Return encrypted data as-is (no decryption)
        return {
            status: response.status,
            success: true,
            data: {
                currentPage: response.data?.currentPage,
                totalPages: response.data?.totalPages,
                totalItems: response.data?.totalItems,
                userNotes: response.data?.userNotes || []
            }
        };
    } catch (error: any) {
        console.error(error, "notes api helper")
        return {
            status: error.response?.status || 500,
            success: false,
            data: error.response?.data || { error: 'Network error' }
        };
    }
};

/**
 * Fetch notes with pagination, search, and automatic decryption
 * Client-side version (uses API instance with interceptors)
 */
export const getNotesClientSide = async (
    userAESKey: CryptoKey,
    page?: number | string,
    limit?: number | string,
    search?: string
) => {
    try {
        const response = await api.get(url.GET_NOTE, {
            params: {
                page: page || 1,
                limit: limit || 10,
                search: search || ''
            },
        });

        // Decrypt all notes
        const decryptedNotes = response.data?.userNotes
            ? await decryptNotes(response.data.userNotes, userAESKey)
            : [];

        return {
            status: response.status,
            success: true,
            data: {
                currentPage: response.data?.currentPage,
                totalPages: response.data?.totalPages,
                totalItems: response.data?.totalItems,
                userNotes: decryptedNotes
            }
        };
    } catch (error: any) {
        console.error(error, "notes api helper")
        return {
            status: error.response?.status || 500,
            success: false,
            data: error.response?.data || { error: 'Network error' }
        };
    }
};

/**
 * Fetch trash notes WITHOUT decryption - for server-side use
 * Returns encrypted data that will be decrypted client-side
 */
export const getTrashNotes = async (
    token: string,
    page?: number | string,
    limit?: number | string,
    search?: string
) => {
    try {
        const response = await axios.get(url.GET_TRASH_NOTE, {
            params: {
                page: page || 1,
                limit: limit || 10,
                search: search || ''
            },
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            withCredentials: true,
        });

        // Return encrypted data as-is (no decryption)
        return {
            success: true,
            data: {
                currentPage: response.data?.currentPage,
                totalPages: response.data?.totalPages,
                totalItems: response.data?.totalItems,
                trashedNotes: response.data?.trashedNotes || []
            }
        };
    } catch (error: any) {
        return {
            success: false,
            status: error.response?.status || 500,
            error: error.response?.data?.error || "Failed to fetch trash"
        };
    }
};

/**
 * Fetch trash notes with automatic decryption
 * Client-side version
 */
export const getTrashNotesClientSide = async (
    userAESKey: CryptoKey,
    page?: number | string,
    limit?: number | string,
    search?: string
) => {
    try {
        const response = await api.get(url.GET_TRASH_NOTE, {
            params: {
                page: page || 1,
                limit: limit || 10,
                search: search || ''
            }
        });

        // Decrypt all trash notes
        const decryptedNotes = response.data?.trashedNotes
            ? await decryptNotes(response.data.trashedNotes, userAESKey)
            : [];

        return {
            success: true,
            data: {
                currentPage: response.data?.currentPage,
                totalPages: response.data?.totalPages,
                totalItems: response.data?.totalItems,
                trashedNotes: decryptedNotes
            }
        };
    } catch (error: any) {
        return {
            success: false,
            status: error.response?.status || 500,
            error: error.response?.data?.error || "Failed to fetch trash"
        };
    }
};

/**
 * Move a note to trash (Soft Delete)
 * No encryption needed - just metadata update
 */
export const deleteNote = async (noteId: string) => {
    try {
        const response = await api.delete(`${url.DELETE_NOTE}/${noteId}`);
        return { success: true, message: response.data.message };
    } catch (error: any) {
        return {
            success: false,
            status: error.response?.status || 500,
            error: error.response?.data?.error || "Failed to move note to trash"
        };
    }
};

/**
 * Restore a note from trash
 * No encryption needed - just metadata update
 */
export const restoreNote = async (noteId: string) => {
    try {
        const response = await api.patch(`${url.RESTORE_NOTE}/${noteId}`);
        return { success: true, message: response.data.message };
    } catch (error: any) {
        return {
            success: false,
            status: error.response?.status || 500,
            error: error.response?.data?.error || "Failed to restore note"
        };
    }
};

/**
 * Permanently delete a note from the database
 * No encryption needed - complete deletion
 */
export const hardDeleteNote = async (noteId: string) => {
    try {
        const response = await api.delete(`${url.PERMANENT_DELETE_NOTE}/${noteId}`);
        return { success: true, message: response.data.message };
    } catch (error: any) {
        return {
            success: false,
            status: error.response?.status || 500,
            error: error.response?.data?.error || "Failed to permanently delete note"
        };
    }
};

interface ImportNoteParams {
    file: File;
    userAESKey: CryptoKey;
}

export const importNote = async ({ file, userAESKey }: ImportNoteParams) => {
    try {
        const fileText = await file.text();

        let parsed;

        try {
            parsed = JSON.parse(fileText);
        } catch {
            return {
                success: false,
                status: 400,
                data: { error: "Invalid note file format" }
            };
        }

        // 🔐 Decrypt export payload
        if (parsed.encrypted && parsed.data && parsed.iv) {
            const decrypted = await decryptNote(
                parsed.data,
                parsed.iv,
                userAESKey
            );

            parsed = JSON.parse(decrypted);
        }

        // Now note exists
        const notePayload = parsed?.note;

        if (!notePayload) {
            return {
                success: false,
                status: 400,
                data: { error: "Invalid export structure" }
            };
        }

        const response = await api.post(url.IMPORT_NOTE, {
            noteId: notePayload.noteId,
            title: notePayload.title,
            titleIV: notePayload.titleIV,
            content: notePayload.content,
            contentIV: notePayload.contentIV,
            canvasData: notePayload.canvasData,
            canvasIV: notePayload.canvasIV,
            color: notePayload.color,
            pinned: notePayload.pinned,
        });

        if (response.data.note) {
            const decryptedNote = await decryptNoteData(
                response.data.note,
                userAESKey
            );

            return {
                status: response.status,
                success: true,
                data: {
                    ...response.data,
                    note: decryptedNote
                }
            };
        }

        return {
            status: response.status,
            success: true,
            data: response.data
        };

    } catch (error: any) {
        console.error("Import note helper error:", error);

        return {
            status: error.response?.status || 500,
            success: false,
            data: error.response?.data || { error: "Failed to import note" }
        };
    }
};