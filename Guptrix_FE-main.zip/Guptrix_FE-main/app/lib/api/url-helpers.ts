export const baseURL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

export const SIGN_UP = `${baseURL}/api/register`;
export const VERIFY_OTP = `${baseURL}/api/verify`;
export const RESEND_OTP = `${baseURL}/api/resend-otp`;
export const LOGIN = `${baseURL}/api/login`;
export const FORGOT_PASSWORD = `${baseURL}/api/request-password-reset`;
export const RESET_FORGOT_PASSWORD = `${baseURL}/api/verify-otp-reset-password`;
export const LOGOUT_USER = `${baseURL}/api/logout`;
export const CREATE_NOTE = `${baseURL}/note/create`;
export const GET_NOTE = `${baseURL}/note/get-notes`;
export const UPDATE_NOTE = `${baseURL}/note/update`;
export const GET_TRASH_NOTE = `${baseURL}/note/trash`;
export const DELETE_NOTE = `${baseURL}/note/delete`;
export const RESTORE_NOTE = `${baseURL}/note/restore`;
export const PERMANENT_DELETE_NOTE = `${baseURL}/note/permanent-delete`;
export const REFRESH_TOKEN = `${baseURL}/refresh/access-token`;

// current user profile
export const GET_CURRENT_USER = `${baseURL}/api/user/current`;

// get recovery creds
export const GET_RECOVERY_CREDS = `${baseURL}/api/recovery-login`;

// import note
export const IMPORT_NOTE = `${baseURL}/note/import-note`