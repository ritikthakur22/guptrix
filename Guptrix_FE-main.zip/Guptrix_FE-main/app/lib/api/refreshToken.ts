import axios from "axios";

export const refreshToken = async () => {
    try {
        // Call the Route Handler we just created above
        const response = await axios.get('/api/auth/refresh');
        
        return { 
            success: response.data.success 
        };
    } catch (error: any) {
        return {
            success: false,
            status: error.response?.status || 500
        };
    }
}