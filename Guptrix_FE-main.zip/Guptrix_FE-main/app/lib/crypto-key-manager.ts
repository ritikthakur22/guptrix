// app/lib/crypto-key-manager.ts
// Centralized key management to avoid duplication and race conditions

/**
 * Store the user's AES key in sessionStorage
 */
export async function storeAESKey(key: CryptoKey): Promise<void> {
    try {
        const exportedKey = await window.crypto.subtle.exportKey("jwk", key);
        sessionStorage.setItem('userAESKey', JSON.stringify(exportedKey));
    } catch (error) {
        console.error("Failed to store AES key:", error);
        throw new Error("Failed to store encryption key");
    }
}

/**
 * Retrieve the user's AES key from sessionStorage
 * Returns null if not found or if import fails
 */
export async function retrieveAESKey(): Promise<CryptoKey | null> {
    try {
        const jwkString = sessionStorage.getItem('userAESKey');
        if (!jwkString) {
            return null;
        }

        const jwk = JSON.parse(jwkString);
        const key = await window.crypto.subtle.importKey(
            "jwk",
            jwk,
            { name: "AES-GCM" },
            true,
            ["encrypt", "decrypt"]
        );

        return key;
    } catch (error) {
        console.error("Failed to retrieve AES key:", error);
        return null;
    }
}

/**
 * Clear the stored AES key (on logout)
 */
export function clearAESKey(): void {
    sessionStorage.removeItem('userAESKey');
}

/**
 * Check if an AES key exists in storage
 */
export function hasStoredAESKey(): boolean {
    return sessionStorage.getItem('userAESKey') !== null;
}