// crypto.service.ts
const encoder = new TextEncoder();
const decoder = new TextDecoder();

// Browser-friendly crypto - LAZY EVALUATION
// Don't access crypto until actually needed
const getCrypto = (): Crypto => {
    if (typeof window !== "undefined" && window.crypto) {
        return window.crypto;
    }
    throw new Error("Crypto API not available - must be used in browser context");
};

// --------------------- Base64 Helpers ---------------------
export function bufferToBase64(buffer: ArrayBuffer): string {
    return btoa(String.fromCharCode(...new Uint8Array(buffer)));
}

export function base64ToBuffer(base64: string): ArrayBuffer {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes.buffer;
}

// ---------------------Generate a Recovery Key ------------------------------------------------
export function generateRecoveryKey(): string {
    const crypto = getCrypto();
    const bytes = crypto.getRandomValues(new Uint8Array(32));
    return bufferToBase64(bytes.buffer); // user must save this
}


// --------------------- KEK Derivation ---------------------
export async function deriveKEK(password: string, salt: Uint8Array): Promise<CryptoKey> {
    const crypto = getCrypto(); // Get crypto when actually used

    const baseKey = await crypto.subtle.importKey(
        "raw",
        encoder.encode(password),
        "PBKDF2",
        false,
        ["deriveKey"]
    );

    return crypto.subtle.deriveKey(
        {
            name: "PBKDF2",
            salt: salt as any,
            iterations: 150_000,
            hash: "SHA-256",
        },
        baseKey,
        { name: "AES-GCM", length: 256 },
        true,
        ["encrypt", "decrypt"]
    );
}

// ----------------------Derive KEK from Recovery Key --------------------------------
export async function deriveRecoveryKEK(recoveryKey: string, salt: Uint8Array): Promise<CryptoKey> {
    const crypto = getCrypto();

    const baseKey = await crypto.subtle.importKey(
        "raw",
        encoder.encode(recoveryKey),
        "PBKDF2",
        false,
        ["deriveKey"]
    );

    return crypto.subtle.deriveKey(
        {
            name: "PBKDF2",
            salt: salt as any,
            iterations: 150_000,
            hash: "SHA-256",
        },
        baseKey,
        { name: "AES-GCM", length: 256 },
        true,
        ["encrypt", "decrypt"]
    );
}


// --------------------- Registration ---------------------
// export async function registerUser(password: string) {
//     const crypto = getCrypto(); // Get crypto when actually used

//     const userAESKeyRaw = crypto.getRandomValues(new Uint8Array(32));
//     const salt = crypto.getRandomValues(new Uint8Array(16));
//     const keyIv = crypto.getRandomValues(new Uint8Array(12));

//     const kek = await deriveKEK(password, salt);

//     const encryptedAESKey = await crypto.subtle.encrypt(
//         { name: "AES-GCM", iv: keyIv.buffer },
//         kek,
//         userAESKeyRaw.buffer
//     );

//     return {
//         salt: bufferToBase64(salt.buffer),
//         keyIv: bufferToBase64(keyIv.buffer),
//         encryptedAESKey: bufferToBase64(encryptedAESKey),
//     };
// }

export async function registerUser(password: string) {
    const crypto = getCrypto();

    const userAESKeyRaw = crypto.getRandomValues(new Uint8Array(32));

    const salt = crypto.getRandomValues(new Uint8Array(16));
    const recoverySalt = crypto.getRandomValues(new Uint8Array(16));

    const keyIv = crypto.getRandomValues(new Uint8Array(12));
    const recoveryIv = crypto.getRandomValues(new Uint8Array(12));

    const recoveryKey = generateRecoveryKey();

    const passwordKEK = await deriveKEK(password, salt);
    const recoveryKEK = await deriveRecoveryKEK(recoveryKey, recoverySalt);

    const encryptedAESKey = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: keyIv },
        passwordKEK,
        userAESKeyRaw
    );

    const encryptedAESKeyWithRecovery = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: recoveryIv },
        recoveryKEK,
        userAESKeyRaw
    );

    return {
        // store in DB
        salt: bufferToBase64(salt.buffer),
        keyIv: bufferToBase64(keyIv.buffer),
        encryptedAESKey: bufferToBase64(encryptedAESKey),

        recoverySalt: bufferToBase64(recoverySalt.buffer),
        recoveryIv: bufferToBase64(recoveryIv.buffer),
        encryptedAESKeyWithRecovery: bufferToBase64(encryptedAESKeyWithRecovery),

        // show ONCE to user
        recoveryKey,
    };
}

// ------------------Unlock AES Key (using Recovery Key) --------------------
export async function unlockAESKeyWithRecoveryKey(
    recoveryKey: string,
    recoverySaltFromDB: string,
    recoveryIvFromDB: string,
    encryptedAESKeyWithRecoveryFromDB: string
): Promise<CryptoKey> {

    const crypto = getCrypto();

    const salt = new Uint8Array(base64ToBuffer(recoverySaltFromDB));
    const iv = new Uint8Array(base64ToBuffer(recoveryIvFromDB));
    const encryptedAESKey = base64ToBuffer(encryptedAESKeyWithRecoveryFromDB);

    const recoveryKEK = await deriveRecoveryKEK(recoveryKey, salt);

    const userAESKeyRaw = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv },
        recoveryKEK,
        encryptedAESKey
    );

    return crypto.subtle.importKey(
        "raw",
        userAESKeyRaw,
        "AES-GCM",
        true,
        ["encrypt", "decrypt"]
    );
}

// --------------------- Re-Encrypt AES key with new password --------------------
export async function reEncryptAESKeyWithNewPassword(
    userAESKey: CryptoKey,
    newPassword: string
) {
    const crypto = getCrypto();

    const rawKey = await crypto.subtle.exportKey("raw", userAESKey);

    const newSalt = crypto.getRandomValues(new Uint8Array(16));
    const newIv = crypto.getRandomValues(new Uint8Array(12));

    const newKEK = await deriveKEK(newPassword, newSalt);

    const newEncryptedAESKey = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: newIv },
        newKEK,
        rawKey
    );

    return {
        salt: bufferToBase64(newSalt.buffer),
        keyIv: bufferToBase64(newIv.buffer),
        encryptedAESKey: bufferToBase64(newEncryptedAESKey),
    };
}


// --------------------- Unlock AES Key (after login) ---------------------
export async function unlockUserAESKey(
    password: string,
    saltFromDB: string,
    keyIvFromDB: string,
    encryptedAESKeyFromDB: string
): Promise<CryptoKey> {
    const crypto = getCrypto(); // Get crypto when actually used

    const salt = new Uint8Array(base64ToBuffer(saltFromDB));
    const keyIv = new Uint8Array(base64ToBuffer(keyIvFromDB));
    const encryptedAESKey = base64ToBuffer(encryptedAESKeyFromDB);

    const kek = await deriveKEK(password, salt);

    const userAESKeyRaw = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: keyIv.buffer },
        kek,
        encryptedAESKey
    );

    return crypto.subtle.importKey(
        "raw",
        userAESKeyRaw,
        "AES-GCM",
        true,
        ["encrypt", "decrypt"]
    );
}

// --------------------- Encrypt Note ---------------------
export async function encryptNote(noteText: string, userAESKey: CryptoKey) {
    const crypto = getCrypto(); // Get crypto when actually used

    const iv = crypto.getRandomValues(new Uint8Array(12));

    const ciphertext = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: iv.buffer },
        userAESKey,
        encoder.encode(noteText)
    );

    return {
        iv: bufferToBase64(iv.buffer),
        ciphertext: bufferToBase64(ciphertext),
    };
}

// --------------------- Decrypt Note ---------------------
export async function decryptNote(
    ciphertextFromDB: string,
    ivFromDB: string,
    userAESKey: CryptoKey
) {
    const crypto = getCrypto(); // Get crypto when actually used

    const iv = new Uint8Array(base64ToBuffer(ivFromDB));
    const ciphertext = base64ToBuffer(ciphertextFromDB);

    const plaintext = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: iv.buffer },
        userAESKey,
        ciphertext
    );

    return decoder.decode(plaintext);
}