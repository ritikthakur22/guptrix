// lib/serverCache.ts
import { getNotes, getTrashNotes } from "./api/note";

// ----------------------
// Simple in-memory caches
// ----------------------
let notesCache: { data: any[]; version: string } | null = null;
let trashCache: { data: any[]; version: string } | null = null;

// Transform notes for frontend
const transformNotes = (notes: any[]) =>
    notes.map(note => ({
        noteId: note.noteId,
        title: note.title,
        content: note.content,
        canvasData: note.canvasData,
        canvasIV: note.canvasIV,
        color: note.color,
        pinned: note.pinned,
        trash: {
            isDeleted: note.trash.isDeleted,
            deletedAt: note.trash.deletedAt,
        },
        createdAt: note.createdAt,
        updatedAt: note.updatedAt,
        contentIV: note.contentIV,
        titleIV: note.titleIV,
    }));

// Compute version based on updatedAt timestamps
const computeVersion = (notes: any[]) => notes.map(n => n.updatedAt).join(",");

/**
 * Fetch and cache notes (for Dashboard)
 */
export const fetchCachedNotes = async (token: string): Promise<any[]> => {
    const noteStates = await getNotes(token);
    const transformedNotes = noteStates.success ? transformNotes(noteStates.data.userNotes) : [];

    const newVersion = computeVersion(transformedNotes);

    if (notesCache && notesCache.version === newVersion) {
        return notesCache.data;
    }

    // Update cache
    notesCache = {
        data: transformedNotes,
        version: newVersion,
    };
    
    return transformedNotes;
};

/**
 * Fetch and cache trash notes (for Trash page)
 */
export const fetchCachedTrashNotes = async (token: string): Promise<any[]> => {
    const trashStates = await getTrashNotes(token);
    const transformedTrashNotes =
        trashStates.success && trashStates.data?.trashedNotes
            ? transformNotes(trashStates.data.trashedNotes)
            : [];

    const newVersion = computeVersion(transformedTrashNotes);

    if (trashCache && trashCache.version === newVersion) {
        return trashCache.data;
    }

    trashCache = {
        data: transformedTrashNotes,
        version: newVersion,
    };

    return transformedTrashNotes;
};