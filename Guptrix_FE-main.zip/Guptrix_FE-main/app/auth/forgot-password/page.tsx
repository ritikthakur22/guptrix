'use client'
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Mail, ArrowLeft, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ThemeToggle } from "../../components/ThemeToggle";
import Link from "next/link";
import { toast } from 'sonner';
import Image from "next/image";
import { useMutation } from "@tanstack/react-query";
import { forgot_password } from "@/app/lib/api/auth";

const page = () => {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    toast.warning("Encryption Warning", {
      description: "Resetting your password will result in the permanent loss of all previously encrypted data. This action cannot be undone.",
    });
  }, [])

  const forgotPasswordMutation = useMutation({
    mutationFn: async (credential: { email: string }) => {
      const response = await forgot_password(credential);

      // Throw error if the request was not successful
      if (!response.success) {
        throw new Error(response.data?.error || response.data?.message || "Failed to send OTP");
      }

      return response;
    },
    onSuccess: (response) => {
      setIsSubmitted(true);
      toast.success("OTP Sent", {
        description: response.data?.message || "Check your email for the password reset code"
      });
    },
    onError: (err: Error) => {
      toast.error(err.message || "Network Error");
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email) {
      toast.error("Email required", {
        description: "Please enter your email address"
      });
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast.error("Invalid email", {
        description: "Please enter a valid email address"
      });
      return;
    }

    forgotPasswordMutation.mutate({ email });
  };

  const handleResend = () => {
    if (email) {
      setIsSubmitted(false);
      forgotPasswordMutation.mutate({ email });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-linear-to-br from-[hsl(var(--primary))]/5 via-[hsl(var(--background))] to-[hsl(var(--accent))]/5 p-4">
      {/* Theme Toggle */}
      <div className="fixed top-4 right-4">
        <ThemeToggle />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex items-center justify-center gap-2 mb-8"
        >
          <Link href="/" className="flex items-center gap-2">
            <motion.div
              whileHover={{ rotate: 10 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Image src='/guptrix.png' alt="syncgaurd" width={60} height={60} />
            </motion.div>
            <span className="text-2xl font-bold gradient-text">Guptrix</span>
          </Link>
        </motion.div>

        <Card className="border-[hsl(var(--border))]/50 shadow-xl">
          <CardHeader className="text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="w-16 h-16 bg-[hsl(var(--primary))]/10 rounded-full flex items-center justify-center mx-auto mb-4"
            >
              <Mail className="w-8 h-8 text-[hsl(var(--primary))]" />
            </motion.div>
            <CardTitle className="text-2xl font-bold">Forgot Password?</CardTitle>
            <CardDescription>
              {isSubmitted
                ? "We've sent a verification code to your email"
                : "Enter your email and we'll send you a reset code"
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!isSubmitted ? (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--muted-foreground))]" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      disabled={forgotPasswordMutation.isPending}
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full gradient-primary text-[hsl(var(--primary-foreground))]"
                  disabled={forgotPasswordMutation.isPending}
                >
                  {forgotPasswordMutation.isPending ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                    >
                      <RefreshCw className="h-4 w-4" />
                    </motion.div>
                  ) : (
                    "Send Reset Code"
                  )}
                </Button>
              </form>
            ) : (
              <div className="space-y-4">
                <div className="p-4 bg-[hsl(var(--primary))]/10 rounded-lg text-center">
                  <p className="text-sm text-[hsl(var(--muted-foreground))]">
                    A 6-digit code has been sent to
                  </p>
                  <p className="font-medium mt-1">{email}</p>
                </div>

                <Button asChild className="w-full gradient-primary text-[hsl(var(--primary-foreground))]">
                  <Link href={`/auth/reset-password?email=${encodeURIComponent(email)}`}>
                    Enter Verification Code
                  </Link>
                </Button>

                <Button
                  variant="ghost"
                  className="w-full"
                  onClick={handleResend}
                  disabled={forgotPasswordMutation.isPending}
                >
                  {forgotPasswordMutation.isPending ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    "Didn't receive code? Resend"
                  )}
                </Button>
              </div>
            )}

            {/* Back Link */}
            <Link href="/auth/login">
              <Button variant="ghost" className="w-full mt-4">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Login
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Security Note */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-sm text-[hsl(var(--muted-foreground))] mt-6"
        >
          🔒 Your notes are end-to-end encrypted
        </motion.p>
      </motion.div>
    </div>
  );
};

export default page;