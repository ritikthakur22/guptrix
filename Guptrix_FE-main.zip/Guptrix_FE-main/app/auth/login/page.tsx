'use client'
import { motion } from "framer-motion"
import { useState, useTransition } from "react"
import Link from "next/link"
import { Mail, Lock, Eye, EyeOff, ArrowRight, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ThemeToggle } from "../../components/ThemeToggle"
import Image from "next/image"
import { useMutation } from "@tanstack/react-query"
import { useRouter } from "next/navigation"
import { toast } from 'sonner'
import { unlockUserAESKey } from "@/app/lib/crypto.service"
import { storeAESKey } from "@/app/lib/crypto-key-manager"

const LoginPage = () => {
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [rememberMe, setRememberMe] = useState(false)
  const [isPendingTransition, startTransition] = useTransition();


  const router = useRouter();

  const loginMutation = useMutation({
    mutationFn: async (credentials: { email: string; password: string; rememberMe: boolean }) => {
      // Call Next.js API route
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: credentials.email,
          password: credentials.password,
          rememberMe: credentials.rememberMe,
        }),
        credentials: 'include', // Important for cookies
      });

      const data = await response.json();

      if (!response.ok) {
        // throw new Error(data.error || 'Login failed');
        throw {
          message: data.error?.error || data.error || 'Login failed',
          status: response.status,
          email: data.email || data.error?.email,
          userId: data.userId || data.error?.userId,
        };
      }

      // Unlock the user's AES key using their password
      const unlockedUserAESKey = await unlockUserAESKey(
        credentials.password,
        data.salt,
        data.keyIV,
        data.encryptedAESKey
      );

      await storeAESKey(unlockedUserAESKey);

      return data;
    },
    onSuccess: (response) => {
      toast.success(response.data.message || 'Login successful!', {
        description: "Redirecting to dashboard ..."
      });

      // ✅ Force router refresh and redirect
      // setTimeout(() => {
      // router.refresh(); // 👈 This forces layout to re-check cookies
      // router.push('/dashboard');
      // }, 1000);
      startTransition(() => {
        router.refresh();
        router.push("/dashboard");
      });
    },
    onError: (error: any) => {

      // toast.error(error?.message || 'An error occurred.', {
      //   description: " Please try again."
      // });
      // Check if the error is specifically the "Unverified" status (403)
      if (error.status === 403 && error.email && error.userId) {
        toast.error("Account not verified", {
          description: "Redirecting to verification page...",
        });
        localStorage.setItem('userId', error.userId);

        // Redirect the user to your verification screen
        startTransition(() => {
          router.push(`/auth/verify-otp?email=${encodeURIComponent(email)}`);
        });

        return; // Exit early so the default error toast doesn't fire
      }

      // Default error handling for 401, 500, etc.
      toast.error(error?.message || 'An error occurred.', {
        description: "Please try again."
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    loginMutation.mutate({ email, password, rememberMe })
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-linear-to-br from-[hsl(var(--primary))]/5 via-[hsl(var(--background))] to-[hsl(var(--accent))]/5 p-4">
      {/* Theme Toggle */}
      <div className="fixed top-4 right-4">
        <ThemeToggle />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex items-center justify-center gap-2 mb-8"
        >
          <Link href="/" className="flex items-center gap-2">
            <motion.div
              whileHover={{ rotate: 10 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Image src='/guptrix.png' alt="syncgaurd" width={60} height={60} />
            </motion.div>
            <span className="text-2xl font-bold gradient-text">Guptrix</span>
          </Link>
        </motion.div>

        <Card className="border-[hsl(var(--border))]/50 shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold">Welcome back</CardTitle>
            <CardDescription>
              Sign in to access your encrypted notes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[hsl(var(--muted-foreground))]" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    required
                    disabled={loginMutation.isPending}
                    autoComplete="email"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <Link
                    href="/auth/forgot-password"
                    className="text-sm text-[hsl(var(--primary))] hover:underline"
                  >
                    Forgot password?
                  </Link>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[hsl(var(--muted-foreground))]" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10"
                    required
                    disabled={loginMutation.isPending}
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute cursor-pointer right-3 top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]"
                    disabled={loginMutation.isPending}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {/* Remember Me */}
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="rememberMe"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                  disabled={loginMutation.isPending}
                />
                <Label
                  htmlFor="rememberMe"
                  className="text-sm font-normal cursor-pointer"
                >
                  Remember me
                </Label>
              </div>

              {/* Submit */}
              <Button
                type="submit"
                className="w-full gradient-primary text-primary-foreground group"
                disabled={loginMutation.isPending || isPendingTransition}
              >
                {loginMutation.isPending || isPendingTransition ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {/* Signing in... */}
                    Redirecting...
                  </>
                ) : (
                  <>
                    Sign In
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </Button>
            </form>

            {/* Divider */}
            <div className="flex items-center my-8 text-sm text-[hsl(var(--muted-foreground))]">
              <div className="grow border-t border-[hsl(var(--border))]/30 shadow-[0_1px_0_0_rgba(255,255,255,0.05)]"></div>
              <span className="mx-4 shrink-0">New to Guptrix?</span>
              <div className="grow border-t border-[hsl(var(--border))]/30 shadow-[0_1px_0_0_rgba(255,255,255,0.05)]"></div>
            </div>

            {/* Sign Up Link */}
            <Link href="/auth/signup">
              <Button variant="outline" className="w-full" disabled={loginMutation.isPending}>
                Create an account
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Security Note */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-sm text-muted-foreground mt-6"
        >
          🔒 Your notes are end-to-end encrypted
        </motion.p>
      </motion.div>
    </div>
  )
}

export default LoginPage