"use client";

import { useState, useRef, useEffect, Suspense, useTransition } from "react";
import { motion } from "framer-motion";
import { KeyRound, ArrowLeft, RefreshCw, Eye, EyeOff, Check, X, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ThemeToggle } from "../../components/ThemeToggle";
import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { toast } from 'sonner';
import Image from "next/image";
import { useMutation } from "@tanstack/react-query";
import { recoverLogin, reset_forgot_password } from "@/app/lib/api/auth";
import { reEncryptAESKeyWithNewPassword, registerUser, unlockAESKeyWithRecoveryKey } from "@/app/lib/crypto.service";

// Sub-component to handle logic using SearchParams
const ResetPasswordContent = () => {
    const searchParams = useSearchParams();
    const router = useRouter();
    const email = searchParams.get("email") || "";
    const [isPendingTransition, startTransition] = useTransition();

    const [otp, setOtp] = useState(["", "", "", "", "", ""]);
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [recoveryKey, setRecoveryKey] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [step, setStep] = useState<"otp" | "password" | "success">("otp");
    const [resendTimer, setResendTimer] = useState(300);
    const [isTimerLoaded, setIsTimerLoaded] = useState(false);
    const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
    const isProcessing = useRef(false); // 1. Create the lock

    const passwordRequirements = [
        { label: "At least 8 characters", met: newPassword.length >= 8 },
        { label: "Contains uppercase letter", met: /[A-Z]/.test(newPassword) },
        { label: "Contains lowercase letter", met: /[a-z]/.test(newPassword) },
        { label: "Contains a number", met: /\d/.test(newPassword) },
        { label: "Contains special character", met: /[!@#$%^&*(),.?":{}|<>]/.test(newPassword) },
    ];

    const allRequirementsMet = passwordRequirements.every(req => req.met);
    const passwordsMatch = newPassword === confirmPassword && confirmPassword.length > 0;

    // Load timer from localStorage on mount (client-side only)
    useEffect(() => {
        const saved = localStorage.getItem('resetPasswordTimer');
        if (saved) {
            const savedTime = parseInt(saved);
            setResendTimer(savedTime > 0 ? savedTime : 0);
        }
        setIsTimerLoaded(true);
    }, []);

    // Countdown timer
    useEffect(() => {
        if (!isTimerLoaded) return;

        if (resendTimer > 0) {
            const timer = setTimeout(() => {
                const newTime = resendTimer - 1;
                setResendTimer(newTime);
                localStorage.setItem('resetPasswordTimer', newTime.toString());
            }, 1000);
            return () => clearTimeout(timer);
        } else {
            localStorage.removeItem('resetPasswordTimer');
        }
    }, [resendTimer, isTimerLoaded]);

    const resetPasswordMutation = useMutation({
        mutationFn: async (data: { email: string; otp: string; newPassword: string; salt: string; encryptedAESKey: string; keyIV: string, encryptedAESKeyWithRecovery?: string, recoverySalt?: string; recoveryIv?: string }) => {
            const response = await reset_forgot_password(data);

            if (!response.success) {
                throw new Error(response.data?.error || response.data?.message || "Failed to reset password");
            }

            return response;
        },
        onSuccess: (response) => {
            setStep("success");
            toast.success("Password Reset Successful", {
                description: response.data?.message || "Your password has been reset successfully"
            });

            // setTimeout(() => {
            //     localStorage.removeItem('resetPasswordTimer');
            //     router.push("/auth/login");
            // }, 2000);
            startTransition(() => {
                localStorage.removeItem('resetPasswordTimer');
                if (recoveryKey) {
                    router.replace('/auth/login')
                } else {
                    router.replace(`/auth/recovery-key?email=${encodeURIComponent(email)}`);
                }
            })
        },
        onError: (err: Error) => {
            toast.error(err.message || "Failed to reset password");
        }
    });

    useEffect(() => {
        if (!email && !isProcessing.current) {
            isProcessing.current = true; // 3. Set the lock immediately

            toast.error("Email not found", {
                description: "Please start from the forgot password page"
            });
            router.push("/auth/forgot-password");
        }
    }, [email, router]);

    useEffect(() => {
        if (resendTimer > 0) {
            const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
            return () => clearTimeout(timer);
        }
    }, [resendTimer]);

    const handleChange = (index: number, value: string) => {
        if (!/^\d*$/.test(value)) return;
        const newOtp = [...otp];
        newOtp[index] = value.slice(-1);
        setOtp(newOtp);
        if (value && index < 5) {
            inputRefs.current[index + 1]?.focus();
        }
    };

    const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
        if (e.key === "Backspace" && !otp[index] && index > 0) {
            inputRefs.current[index - 1]?.focus();
        }
    };

    const handlePaste = (e: React.ClipboardEvent) => {
        e.preventDefault();
        const pasted = e.clipboardData.getData("text").slice(0, 6);
        if (!/^\d+$/.test(pasted)) return;

        const newOtp = [...otp];
        pasted.split("").forEach((char, i) => {
            if (i < 6) newOtp[i] = char;
        });
        setOtp(newOtp);
        inputRefs.current[Math.min(pasted.length, 5)]?.focus();
    };

    const handleVerifyOtp = () => {
        const otpString = otp.join("");

        if (otpString.length !== 6) {
            toast.error("Invalid OTP", {
                description: "Please enter the complete 6-digit code"
            });
            return;
        }

        setStep("password");
        toast.success("Code Verified", {
            description: "Now set your new password"
        });
    };

    const handleResetPassword = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!allRequirementsMet) {
            toast.error("Password Requirements Not Met", {
                description: "Please ensure all password requirements are satisfied"
            });
            return;
        }

        if (!passwordsMatch) {
            toast.error("Passwords Don't Match", {
                description: "Please make sure both passwords are identical"
            });
            return;
        }

        const otpString = otp.join("");

        // resetPasswordMutation.mutate({
        //     email,
        //     otp: otpString,
        //     newPassword
        // });
        try {
            if (recoveryKey) {
                // 1️⃣ Fetch recovery credentials from backend
                const recoveryResponse = await recoverLogin(email);
                if (!recoveryResponse.success || !recoveryResponse.data.user) {
                    throw new Error("Failed to fetch recovery credentials");
                }

                const { encryptedAESKeyWithRecovery, recoverySalt, recoveryIv } = recoveryResponse.data.user[0];

                // 2️⃣ Decrypt AES key using recovery key
                const userAESKey = await unlockAESKeyWithRecoveryKey(
                    recoveryKey,
                    recoverySalt,
                    recoveryIv,
                    encryptedAESKeyWithRecovery
                );

                // 3️⃣ Re-encrypt AES key using new password KEK
                const { encryptedAESKey, salt, keyIv } = await reEncryptAESKeyWithNewPassword(userAESKey, newPassword);

                // 4️⃣ Send all info to backend
                resetPasswordMutation.mutate({
                    email,
                    otp: otpString,
                    newPassword,
                    encryptedAESKey,
                    salt,
                    keyIV: keyIv
                });
            } else {
                const cryptoData = await registerUser(newPassword);
                sessionStorage.setItem('recoveryKey', cryptoData.recoveryKey);

                // 4️⃣ Send all info to backend
                resetPasswordMutation.mutate({
                    email,
                    otp: otpString,
                    newPassword,
                    encryptedAESKey: cryptoData.encryptedAESKey,
                    salt: cryptoData.salt,
                    keyIV: cryptoData.keyIv,
                    encryptedAESKeyWithRecovery: cryptoData.encryptedAESKeyWithRecovery,
                    recoverySalt: cryptoData.recoverySalt,
                    recoveryIv: cryptoData.recoveryIv,
                });
            }

        } catch (error: any) {
            toast.error(error.message || "Fail to reset password");
        }
    };

    const handleResend = () => {
        // Prevent multiple clicks
        if (resendTimer > 0) return;

        // Reset timer to 5 minutes and save to localStorage
        setResendTimer(300);
        localStorage.setItem('resetPasswordTimer', '300');

        toast.info("Resend OTP", {
            description: "A new code will be sent to your email"
        });
        // You can call the forgot_password API again here if needed
    };

    return (
        <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="w-full max-w-md"
        >
            {/* Logo */}
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="flex items-center justify-center gap-2 mb-8"
            >
                <Link href="/" className="flex items-center gap-2">
                    <motion.div
                        whileHover={{ rotate: 10 }}
                        transition={{ type: "spring", stiffness: 300 }}
                    >
                        <Image src='/guptrix.png' alt="syncgaurd" width={60} height={60} />
                    </motion.div>
                    <span className="text-2xl font-bold gradient-text">Guptrix</span>
                </Link>
            </motion.div>

            <Card className="border-[hsl(var(--border))]/50 shadow-xl">
                <CardHeader className="text-center">
                    {step === "success" ? (
                        <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ type: "spring", stiffness: 200 }}
                            className="mx-auto mb-4"
                        >
                            <CheckCircle className="h-16 w-16 text-green-500" />
                        </motion.div>
                    ) : (
                        <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                            className="w-16 h-16 bg-[hsl(var(--primary))]/10 rounded-full flex items-center justify-center mx-auto mb-4"
                        >
                            <KeyRound className="w-8 h-8 text-[hsl(var(--primary))]" />
                        </motion.div>
                    )}
                    <CardTitle className="text-2xl font-bold">
                        {step === "otp" && "Verify Your Email"}
                        {step === "password" && "Set New Password"}
                        {step === "success" && "Password Reset!"}
                    </CardTitle>
                    <CardDescription>
                        {step === "otp" && `We've sent a 6-digit code to ${email}`}
                        {step === "password" && "Create a strong password for your account"}
                        {step === "success" && "Redirecting you to login..."}
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    {step === "otp" && (
                        <>
                            <div className="flex justify-center gap-2 mb-6" onPaste={handlePaste}>
                                {otp.map((digit, index) => (
                                    <motion.input
                                        key={index}
                                        ref={(el) => { inputRefs.current[index] = el; }}
                                        type="text"
                                        inputMode="numeric"
                                        maxLength={1}
                                        value={digit}
                                        onChange={(e) => handleChange(index, e.target.value)}
                                        onKeyDown={(e) => handleKeyDown(index, e)}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: index * 0.1 }}
                                        className="w-12 h-14 text-center text-2xl font-bold rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary))]/20 outline-none transition-all"
                                    />
                                ))}
                            </div>

                            <Button
                                onClick={handleVerifyOtp}
                                disabled={otp.some((d) => !d)}
                                className="w-full gradient-primary text-[hsl(var(--primary-foreground))]"
                            >
                                Verify Code
                            </Button>

                            <div className="text-center mt-6">
                                <p className="text-sm text-[hsl(var(--muted-foreground))]">
                                    Didn't receive the code?{" "}
                                    {resendTimer > 0 ? (
                                        <span className="text-[hsl(var(--primary))]">
                                            Resend in {Math.floor(resendTimer / 60) !== 0 && `${Math.floor(resendTimer / 60)}m`} {resendTimer % 60}s
                                        </span>
                                    ) : (
                                        <button onClick={handleResend} className="text-[hsl(var(--primary))] hover:underline font-medium">
                                            Resend code
                                        </button>
                                    )}
                                </p>
                            </div>

                            <Link href="/auth/forgot-password">
                                <Button
                                    variant="ghost"
                                    className="w-full mt-4"
                                    onClick={() => {
                                        localStorage.removeItem('resetPasswordTimer');
                                    }}
                                >
                                    <ArrowLeft className="mr-2 h-4 w-4" />
                                    Back
                                </Button>
                            </Link>
                        </>
                    )}

                    {step === "password" && (
                        <form onSubmit={handleResetPassword} className="space-y-4">
                            <div className="space-y-2">
                                <label htmlFor="recoveryKey" className="text-sm font-medium">Recovery Key</label>
                                <Input
                                    id="recoveryKey"
                                    type="text"
                                    placeholder="Enter your recovery key"
                                    value={recoveryKey}
                                    onChange={(e) => setRecoveryKey(e.target.value)}
                                    disabled={resetPasswordMutation.isPending || isPendingTransition}
                                />
                            </div>
                            {!recoveryKey && (
                                <p className="text-red-500 text-xs mt-1">
                                    ⚠️ Without your recovery key, all previous notes will be lost.
                                </p>
                            )}
                            <div className="space-y-2 flex gap-2">
                                <Input
                                    id="forgotRecoveryKey"
                                    type="checkbox"
                                    checked={!recoveryKey}
                                    className="h-5 w-5"
                                    onChange={() => setRecoveryKey("")} // user acknowledges loss
                                    disabled={resetPasswordMutation.isPending || isPendingTransition}
                                />
                                <label htmlFor="forgotRecoveryKey" className="text-xs text-[hsl(var(--destructive))]">I forgot my recovery key. All previous notes will be lost.</label>
                            </div>

                            <div className="space-y-2">
                                <label htmlFor="newPassword" className="text-sm font-medium">New Password</label>
                                <div className="relative">
                                    <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--muted-foreground))]" />
                                    <Input
                                        id="newPassword"
                                        type={showPassword ? "text" : "password"}
                                        placeholder="Enter new password"
                                        value={newPassword}
                                        onChange={(e) => setNewPassword(e.target.value)}
                                        className="pl-10 pr-10"
                                        disabled={resetPasswordMutation.isPending || isPendingTransition}
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute right-3 cursor-pointer top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))]"
                                    >
                                        {showPassword ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                                    </button>
                                </div>
                            </div>

                            <div className="space-y-2">
                                {passwordRequirements.map((req, index) => (
                                    <motion.div
                                        key={index}
                                        className={`flex items-center gap-2 text-xs ${req.met ? "text-green-500" : "text-[hsl(var(--muted-foreground))]"}`}
                                    >
                                        {req.met ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                                        {req.label}
                                    </motion.div>
                                ))}
                            </div>

                            <div className="space-y-2">
                                <label htmlFor="confirmPassword" className="text-sm font-medium">Confirm Password</label>
                                <div className="relative">
                                    <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--muted-foreground))]" />
                                    <Input
                                        id="confirmPassword"
                                        type={showConfirmPassword ? "text" : "password"}
                                        placeholder="Confirm new password"
                                        value={confirmPassword}
                                        onChange={(e) => setConfirmPassword(e.target.value)}
                                        className="pl-10 pr-10"
                                        disabled={resetPasswordMutation.isPending || isPendingTransition}
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                        className="absolute right-3 top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))] cursor-pointer"
                                    >
                                        {showConfirmPassword ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                                    </button>
                                </div>
                                {confirmPassword && (
                                    <motion.div
                                        initial={{ opacity: 0 }}
                                        animate={{ opacity: 1 }}
                                        className={`flex items-center gap-2 text-xs ${passwordsMatch ? "text-green-500" : "text-red-500"}`}
                                    >
                                        {passwordsMatch ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                                        {passwordsMatch ? "Passwords match" : "Passwords don't match"}
                                    </motion.div>
                                )}
                            </div>

                            <Button
                                type="submit"
                                className="w-full gradient-primary text-[hsl(var(--primary-foreground))]"
                                disabled={resetPasswordMutation.isPending || !allRequirementsMet || !passwordsMatch || isPendingTransition}
                            >
                                {resetPasswordMutation.isPending || isPendingTransition ? (
                                    <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                                        <RefreshCw className="h-4 w-4" />
                                    </motion.div>
                                ) : "Reset Password"}
                            </Button>
                        </form>
                    )}
                </CardContent>
            </Card>

            {/* Security Note */}
            <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="text-center text-sm text-[hsl(var(--muted-foreground))] mt-6"
            >
                🔒 Your notes are end-to-end encrypted
            </motion.p>
        </motion.div>
    );
};

// Main Page Component
export default function ResetPasswordPage() {
    return (
        <div className="min-h-screen flex items-center justify-center bg-linear-to-br from-[hsl(var(--primary))]/5 via-[hsl(var(--background))] to-[hsl(var(--accent))]/5 p-4">
            <div className="fixed top-4 right-4">
                <ThemeToggle />
            </div>
            <Suspense fallback={<div>Loading...</div>}>
                <ResetPasswordContent />
            </Suspense>
        </div>
    );
}