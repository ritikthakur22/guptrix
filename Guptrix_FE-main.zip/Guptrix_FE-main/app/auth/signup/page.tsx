'use client'

import { motion } from "framer-motion";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { Mail, Lock, Eye, EyeOff, User, ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ThemeToggle } from "../../components/ThemeToggle";
import { useMutation } from '@tanstack/react-query';
import { register } from "../../lib/api/auth";
import { toast } from 'sonner'
import { registerUser } from "@/app/lib/crypto.service";

const page = () => {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(true);
  const [isPendingTransition, startTransition] = useTransition();
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const passwordRequirements = [
    { label: "At least 8 characters", met: formData.password.length >= 8 },
    { label: "One uppercase letter", met: /[A-Z]/.test(formData.password) },
    { label: "One lowercase letter", met: /[a-z]/.test(formData.password) },
    { label: "One number", met: /\d/.test(formData.password) },
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  //   const signUpMutation = useMutation({
  //   mutationFn: (formData: {
  //     username: string;
  //     email: string;
  //     password: string;
  //     salt: string;
  //     encryptedAESKey: string;
  //     keyIV: string;
  //   }) => register(formData),

  //   onSuccess: (response) => {
  //     toast.success(response.message || "Account created successfully!");

  //     const email = formData.email;
  //     setFormData({ username: "", email: "", password: "", confirmPassword: "" });

  //     setTimeout(() => {
  //       router.push(`/auth/verify-otp?email=${encodeURIComponent(email)}`);
  //     }, 1500);
  //   },

  //   onError: (error: any) => {
  //     const msg =
  //       error.response?.data?.message ||
  //       error.response?.data?.error ||
  //       "Failed to create account";

  //     toast.error(msg);
  //   },
  // });


  // React Query mutation
  const signUpMutation = useMutation({
    mutationFn: async (data: any) => {
      const cryptoData = await registerUser(data.password);

      sessionStorage.setItem('recoveryKey', cryptoData.recoveryKey);

      return register({
        ...data,
        encryptedAESKey: cryptoData.encryptedAESKey,
        salt: cryptoData.salt,
        keyIV: cryptoData.keyIv,
        encryptedAESKeyWithRecovery: cryptoData.encryptedAESKeyWithRecovery,
        recoverySalt: cryptoData.recoverySalt,
        recoveryIv: cryptoData.recoveryIv,
      })
      // register(data)
    },
    onSuccess: (response) => {
      if (response.success) {
        toast.success(response.data.message || 'Account created successfully!');
        const email = formData.email;
        setFormData({ username: "", email: "", password: "", confirmPassword: "" });
        localStorage.setItem('userId', response.data?.userId);
        // setTimeout(() => {
        //   router.push(`/auth/verify-otp?email=${encodeURIComponent(email)}`);
        // }, 1500);
        startTransition(() => {
          router.push(`/auth/verify-otp?email=${encodeURIComponent(email)}`);
        })
      } else {
        toast.error(response.data?.message || response.data?.error || 'Failed to create account');
      }
    },
    onError: (error: Error) => {
      if (error.message) {
        toast.error(error.message);
      } else {
        toast.error("Something went wrong", { description: "Please try again." });
      };
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const { username, email, password } = formData;
    signUpMutation.mutate({ username, email, password });

  };


  return (
    <div className="min-h-screen flex items-center justify-center bg-linear-to-br from-[hsl(var(--primary))]/5 via-[hsl(var(--background))] to-[hsl(var(--accent))]/5 p-4 py-12">
      {/* Theme Toggle */}
      <div className="fixed top-4 right-4">
        <ThemeToggle />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex items-center justify-center gap-2 mb-8"
        >
          <Link href="/" className="flex items-center gap-2">
            <motion.div
              whileHover={{ rotate: 10 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Image src='/guptrix.png' alt="syncgaurd" width={60} height={60} />
              {/* <StickyNote className="h-10 w-10 text-primary" /> */}
            </motion.div>
            <span className="text-2xl font-bold gradient-text">Guptrix</span>
          </Link>
        </motion.div>

        <Card className="border-[hsl(var(--border))]/50 shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold">Create your account</CardTitle>
            <CardDescription>
              Start securing your notes with end-to-end encryption
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Username */}
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[hsl(var(--muted-foreground))]" />
                  <Input
                    id="username"
                    name="username"
                    type="text"
                    placeholder="johndoe"
                    value={formData.username}
                    onChange={handleChange}
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[hsl(var(--muted-foreground))]" />
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="you@example.com"
                    value={formData.email}
                    onChange={handleChange}
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[hsl(var(--muted-foreground))]" />
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "password" : "text"}
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={handleChange}
                    className="pl-10 pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute cursor-pointer right-3 top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>

                {/* Password Requirements */}
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {passwordRequirements.map((req, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={`flex items-center gap-1 text-xs ${req.met ? "text-[hsl(var(--success))]" : "text-[hsl(var(--muted-foreground))]"
                        }`}
                    >
                      <Check className={`h-3 w-3 ${req.met ? "opacity-100" : "opacity-30"}`} />
                      {req.label}
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Confirm Password */}
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[hsl(var(--muted-foreground))]" />
                  <Input
                    id="confirmPassword"
                    name="confirmPassword"
                    type={showPassword ? "password" : "text"}
                    placeholder="••••••••"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    className="pl-10"
                    required
                  />
                </div>
                {formData.confirmPassword && formData.password !== formData.confirmPassword && (
                  <p className="text-xs text-[hsl(var(--destructive))]">Passwords do not match</p>
                )}
              </div>

              {/* Submit */}
              <Button
                type="submit"
                className="w-full gradient-primary text-[hsl(var(--primary-foreground))] group"
                disabled={
                  !passwordRequirements.every((r) => r.met) ||
                  formData.password !== formData.confirmPassword || isPendingTransition
                }
              >
                Continue
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </form>

            {/* Divider */}
            <div className="flex items-center my-8 text-sm text-[hsl(var(--muted-foreground))]">
              <div className="grow border-t border-[hsl(var(--border))]/30 shadow-[0_1px_0_0_rgba(255,255,255,0.05)]"></div>
              <span className="mx-4 shrink-0">Already have an account?</span>
              <div className="grow border-t border-[hsl(var(--border))]/30 shadow-[0_1px_0_0_rgba(255,255,255,0.05)]"></div>
            </div>

            {/* Sign In Link */}
            <Link href="/auth/login">
              <Button variant="outline" className="w-full">
                Sign in instead
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Terms */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-xs text-[hsl(var(--muted-foreground))] mt-6"
        >
          By signing up, you agree to our{" "}
          <a href="#" className="text-[hsl(var(--primary))] hover:underline">Terms of Service</a>
          {" "}and{" "}
          <a href="#" className="text-[hsl(var(--primary))] hover:underline">Privacy Policy</a>
        </motion.p>
      </motion.div>
    </div>
  )
}

export default page
