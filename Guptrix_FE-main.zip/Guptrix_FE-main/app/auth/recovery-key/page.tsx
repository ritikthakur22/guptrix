'use client'
import { Button } from '@/components/ui/button';
import { useRouter, useSearchParams } from 'next/navigation';
import Cookies from 'js-cookie';
import { ShieldAlert, KeyRound, Copy, CheckCheck } from 'lucide-react';
import { useEffect, useState } from 'react';
import { ThemeToggle } from '@/app/components/ThemeToggle';

const Page = () => {
    const router = useRouter();
    const searchParams = useSearchParams();
    const email = searchParams.get('email') || "your@email.com";
    const recoveryKey = sessionStorage.getItem('recoveryKey');
    const [copied, setCopied] = useState(false);

    useEffect(() => {
        if (!recoveryKey) {
            // user tried to open page directly
            router.push("/auth/login");
        }
    }, []);

    const handleCopy = () => {
        if (recoveryKey) {
            navigator.clipboard.writeText(recoveryKey);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    };

    const handleDownload = () => {
        if (!recoveryKey) return;
        sessionStorage.removeItem('recoveryKey');
        router.replace(`/auth/login`);

        const content = `Recovery Key for ${email}

${recoveryKey}

Keep this key safe. You will need it if you forget your password.
`;

        const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
        const url = URL.createObjectURL(blob);

        const link = document.createElement("a");
        link.href = url;
        link.download = "recovery-key.txt";
        link.style.display = "none";

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        URL.revokeObjectURL(url);
    };

    return (
        <div className="min-h-screen bg-[hsl(var(--background))] flex items-center justify-center p-4">
            <div className="fixed top-4 right-4">
                <ThemeToggle />
            </div>

            <div className="w-full max-w-md">

                {/* Card */}
                <div className="glass-card rounded-2xl p-8 shadow-lg">

                    {/* Icon Header */}
                    <div className="flex flex-col items-center text-center mb-8">
                        <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center mb-4 shadow-md">
                            <KeyRound className="w-8 h-8 text-white" />
                        </div>
                        <h1 className="text-2xl font-bold text-[hsl(var(--foreground))] tracking-tight">
                            Save Your Recovery Key
                        </h1>
                        <p className="text-sm text-[hsl(var(--muted-foreground))] mt-1">
                            For account: <span className="font-medium text-[hsl(var(--foreground))]">{email}</span>
                        </p>
                    </div>

                    {/* Recovery Key Box */}
                    <div className="relative mb-4">
                        <div className="bg-[hsl(var(--muted))] border border-[hsl(var(--border))] rounded-xl p-4 pr-12 font-mono text-sm text-[hsl(var(--foreground))] break-all leading-relaxed tracking-wide">
                            {recoveryKey || 'XXXX-XXXX-XXXX-XXXX'}
                        </div>
                        <button
                            onClick={handleCopy}
                            className="cursor-pointer absolute top-3 right-3 w-8 h-8 rounded-lg bg-[hsl(var(--background))] border border-[hsl(var(--border))] flex items-center justify-center hover:bg-[hsl(var(--primary))] hover:border-[hsl(var(--primary))] hover:text-white transition-all duration-200 text-[hsl(var(--muted-foreground))]"
                            title="Copy to clipboard"
                        >
                            {copied
                                ? <CheckCheck className="w-4 h-4 text-[hsl(var(--success))]" />
                                : <Copy className="w-4 h-4" />
                            }
                        </button>
                    </div>

                    {/* Warning Banner */}
                    <div className="flex items-start gap-3 bg-[hsl(var(--destructive)/0.08)] border border-[hsl(var(--destructive)/0.2)] rounded-xl p-3 mb-8">
                        <ShieldAlert className="w-4 h-4 text-[hsl(var(--destructive))] mt-0.5 shrink-0" />
                        <p className="text-xs text-[hsl(var(--destructive))] leading-relaxed">
                            This key <strong>cannot be recovered</strong> if lost. Store it in a safe place before continuing.<br /> Use this when you forgot the password.
                        </p>
                    </div>

                    {/* CTA Button */}
                    <Button
                        className="w-full gradient-primary text-white font-semibold py-5 rounded-xl hover:opacity-90 transition-opacity shadow-md"
                        // onClick={() => {
                        //     sessionStorage.removeItem('recoveryKey');
                        //     router.replace(`/auth/login`);
                        // }}
                        onClick={handleDownload}
                    >
                        {/* I've Saved My Recovery Key */}
                        Save My Recovery Key
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default Page;