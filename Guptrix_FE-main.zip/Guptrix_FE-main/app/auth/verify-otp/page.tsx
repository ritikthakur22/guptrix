'use client'
import { motion } from "framer-motion";
import { useState, useRef, useEffect, useTransition } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from 'next/navigation';
import { ArrowLeft, RefreshCw, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ThemeToggle } from "../../components/ThemeToggle";
import Image from "next/image";
import { useMutation } from "@tanstack/react-query";
import { resend_otp, verify_otp } from "@/app/lib/api/auth";
import { toast } from 'sonner'

const Page = () => {
    const router = useRouter();
    const searchParams = useSearchParams();
    const email = searchParams.get('email') || "your@email.com";
    const [isPendingTransition, startTransition] = useTransition();

    const [otp, setOtp] = useState(["", "", "", "", "", ""]);
    const [isVerified, setIsVerified] = useState(false);
    const [resendTimer, setResendTimer] = useState(300);
    const [isTimerLoaded, setIsTimerLoaded] = useState(false);
    const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

    // Load timer from localStorage on mount (client-side only)
    useEffect(() => {
        const saved = localStorage.getItem('resendTimer');
        if (saved) {
            const savedTime = parseInt(saved);
            setResendTimer(savedTime > 0 ? savedTime : 0);
        }
        setIsTimerLoaded(true);
    }, []);

    // Countdown timer
    useEffect(() => {
        if (!isTimerLoaded) return;

        if (resendTimer > 0) {
            const timer = setTimeout(() => {
                const newTime = resendTimer - 1;
                setResendTimer(newTime);
                localStorage.setItem('resendTimer', newTime.toString());
            }, 1000);
            return () => clearTimeout(timer);
        } else {
            // Timer reached 0, remove from localStorage
            localStorage.removeItem('resendTimer');
        }
    }, [resendTimer, isTimerLoaded]);

    const handleChange = (index: number, value: string) => {
        if (!/^\d*$/.test(value)) return;

        const newOtp = [...otp];
        newOtp[index] = value.slice(-1);
        setOtp(newOtp);

        if (value && index < 5) {
            inputRefs.current[index + 1]?.focus();
        }
    };

    const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
        if (e.key === "Backspace" && !otp[index] && index > 0) {
            inputRefs.current[index - 1]?.focus();
        }
    };

    const handlePaste = (e: React.ClipboardEvent) => {
        e.preventDefault();
        const pasted = e.clipboardData.getData("text").slice(0, 6);
        if (!/^\d+$/.test(pasted)) return;

        const newOtp = [...otp];
        pasted.split("").forEach((char, i) => {
            if (i < 6) newOtp[i] = char;
        });
        setOtp(newOtp);
        inputRefs.current[Math.min(pasted.length, 5)]?.focus();
    };

    const mutationOtp = useMutation({
        mutationFn: async (credential: { userId: string, otp: string }) => {
            const response = await verify_otp(credential);

            if (!response.success) {
                throw new Error(response.data?.error || response.data?.message || "Failed to verify OTP");
            }

            return response;
        },
        onSuccess: (response) => {
            toast.success(response.data.message || 'Account verified successfully!');

            if (response.data.isVerified) {
                setIsVerified(true);
            }

            // Clean up localStorage
            localStorage.removeItem('userId');
            localStorage.removeItem('resendTimer');

            // setTimeout(() => {
            //     router.replace(`/auth/login`);
            // }, 1500);
            startTransition(() => {
                router.replace(`/auth/recovery-key?email=${encodeURIComponent(email)}`)
            })
        },
        onError: (error: Error) => {
            toast.error(error.message || "Something went wrong. Please try again.");
        }
    });

    const handleVerify = async () => {
        const userId = localStorage.getItem('userId');

        if (!userId) {
            toast.error('User ID not found', {
                description: 'Please sign up again.'
            });
            router.replace('/auth/signup');
            return;
        }

        const otpCode = otp.join('');
        if (otpCode.length !== 6) {
            toast.error('Invalid OTP', {
                description: 'Please enter a valid 6-digit OTP.'
            });
            return;
        }

        mutationOtp.mutate({ userId, otp: otpCode });
    };

    const mutationResend = useMutation({
        mutationFn: async (credential: { userId: string }) => {
            const response = await resend_otp(credential);

            if (!response.success) {
                throw new Error(response.data?.error || response.data?.message || "Failed to resend OTP");
            }

            return response;
        },
        onSuccess: (response) => {
            toast.success(response.data.message || "OTP resent successfully.");
            // Reset timer to 5 minutes and save to localStorage
            setResendTimer(300);
            localStorage.setItem('resendTimer', '300');
        },
        onError: (error: Error) => {
            toast.error(error.message || "Network Error");
        }
    });

    const handleResend = () => {
        // Prevent multiple clicks
        if (resendTimer > 0 || mutationResend.isPending) return;

        const userId = localStorage.getItem('userId');
        if (!userId) {
            toast.error('User ID not found', {
                description: "Please sign up again."
            });
            router.replace('/auth/signup');
            return;
        }

        mutationResend.mutate({ userId });
    };

    const handleBackToSignup = () => {
        // Clean up localStorage before navigating
        localStorage.removeItem('resendTimer');
        localStorage.removeItem('userId');
        router.replace('/auth/signup');
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-linear-to-br from-[hsl(var(--primary))]/5 via-[hsl(var(--background))] to-[hsl(var(--accent))]/5 p-4">
            <div className="fixed top-4 right-4">
                <ThemeToggle />
            </div>

            <motion.div
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="w-full max-w-md"
            >
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="flex items-center justify-center gap-2 mb-8"
                >
                    <Link href="/" className="flex items-center gap-2">
                        <motion.div
                            whileHover={{ rotate: 10 }}
                            transition={{ type: "spring", stiffness: 300 }}
                        >
                            <Image src='/guptrix.png' alt="syncgaurd" width={60} height={60} />
                        </motion.div>
                        <span className="text-2xl font-bold gradient-text">Guptrix</span>
                    </Link>
                </motion.div>

                <Card className="border-[hsl(var(--border))]/50 shadow-xl">
                    <CardHeader className="text-center">
                        {isVerified ? (
                            <motion.div
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                transition={{ type: "spring", stiffness: 200 }}
                                className="mx-auto mb-4"
                            >
                                <CheckCircle className="h-16 w-16 text-green-500" />
                            </motion.div>
                        ) : null}
                        <CardTitle className="text-2xl font-bold">
                            {isVerified ? "Email Verified!" : "Verify your email"}
                        </CardTitle>
                        <CardDescription>
                            {isVerified
                                ? "Redirecting you to login..."
                                : `We've sent a 6-digit code to ${email}`
                            }
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        {!isVerified && (
                            <>
                                <div className="flex justify-center gap-2 mb-6" onPaste={handlePaste}>
                                    {otp.map((digit, index) => (
                                        <motion.input
                                            key={index}
                                            ref={(el) => { inputRefs.current[index] = el; }}
                                            type="text"
                                            inputMode="numeric"
                                            maxLength={1}
                                            value={digit}
                                            onChange={(e) => handleChange(index, e.target.value)}
                                            onKeyDown={(e) => handleKeyDown(index, e)}
                                            initial={{ opacity: 0, y: 20 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            transition={{ delay: index * 0.1 }}
                                            className="w-12 h-14 text-center text-2xl font-bold rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary))]/20 outline-none transition-all"
                                            disabled={mutationOtp.isPending || isPendingTransition}
                                        />
                                    ))}
                                </div>

                                <Button
                                    onClick={handleVerify}
                                    disabled={otp.some((d) => !d) || mutationOtp.isPending || isPendingTransition}
                                    className="w-full gradient-primary text-[hsl(var(--primary-foreground))]"
                                >
                                    {mutationOtp.isPending || isPendingTransition ? (
                                        <motion.div
                                            animate={{ rotate: 360 }}
                                            transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                                        >
                                            <RefreshCw className="h-4 w-4" />
                                        </motion.div>
                                    ) : (
                                        "Verify Email"
                                    )}
                                </Button>

                                <div className="text-center mt-6">
                                    <p className="text-sm text-[hsl(var(--muted-foreground))]">
                                        Didn't receive the code?{" "}
                                        {resendTimer > 0 ? (
                                            <span className="text-[hsl(var(--primary))]">
                                                Resend in {Math.floor(resendTimer / 60) !== 0 && `${Math.floor(resendTimer / 60)}m`} {resendTimer % 60}s
                                            </span>
                                        ) : (
                                            <button
                                                onClick={handleResend}
                                                disabled={mutationResend.isPending}
                                                className="text-[hsl(var(--primary))] hover:underline font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                                            >
                                                {mutationResend.isPending ? "Sending..." : "Resend code"}
                                            </button>
                                        )}
                                    </p>
                                </div>

                                <Button
                                    variant="ghost"
                                    className="w-full mt-4"
                                    onClick={handleBackToSignup}
                                >
                                    <ArrowLeft className="mr-2 h-4 w-4" />
                                    Back to Sign Up
                                </Button>
                            </>
                        )}
                    </CardContent>
                </Card>

                {/* Security Note */}
                <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                    className="text-center text-sm text-[hsl(var(--muted-foreground))] mt-6"
                >
                    🔒 Your notes are end-to-end encrypted
                </motion.p>
            </motion.div>
        </div>
    );
}

export default Page;