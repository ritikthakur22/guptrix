"use client"

import * as React from "react"
import {
  LogOut,
  NotebookPen,
  // Settings,
  Trash2,
} from "lucide-react"
import { cn } from "@/lib/utils";

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  useSidebar,
} from "@/components/ui/sidebar"
import Link from "next/link"
import Image from "next/image"
import { logout } from "@/app/lib/api/auth"
import { toast } from "sonner"
import { usePathname, useRouter } from "next/navigation"
import { clearAESKey } from "@/app/lib/crypto-key-manager";

const data = {
  routes: [
    { name: "Notes", url: "/dashboard", icon: NotebookPen },
    { name: "Trash", url: "/trash", icon: Trash2 },
  ],
}



export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const { state, setOpenMobile } = useSidebar()
  const isCollapsed = state === "collapsed"
  const pathname = usePathname();
  const router = useRouter()

  const isActive = (url: string) => pathname === url;

  const handleLogout = async () => {
    try {
      const response = await logout()
      toast.success(response?.message || "Logout successful")
      router.refresh()
      router.push('/auth/login')
    } catch (error) {
      toast.error("Logout failed")
    } finally {
      clearAESKey()
    }
  }

  const handleClick = (url: string) => {
    router.push(url);
    setOpenMobile(false);
  }

  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarHeader className="pt-4">
        <SidebarMenu>
          <SidebarMenuItem>
            <Link href="/" className="flex items-center gap-3">
              {/* Logo Container */}
              <div
                className={`flex items-center justify-center transition-all duration-200 ease-in-out shrink-0 ${isCollapsed ? "w-10 h-10 -ml-1" : "w-14 h-14"
                  }`}
              >
                <Image
                  src="/guptrix.png"
                  alt="syncgaurd"
                  width={48}
                  height={48}
                  className="object-contain w-full h-full transition-all duration-200 ease-in-out"
                  priority
                />
              </div>
              {/* Brand Name - Smooth fade in/out */}
              <div
                className={`grid flex-1 text-left leading-tight overflow-hidden transition-all duration-200 ease-in-out ${isCollapsed ? "opacity-0 w-0" : "opacity-100 w-auto"
                  }`}
              >
                <span className="truncate font-bold text-2xl gradient-text">
                  Guptrix
                </span>
              </div>
            </Link>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>



      <SidebarContent>
        <SidebarMenu className={`gap-1 ${!isCollapsed ? "pr-2" : "px-2"}`}>
          {data.routes.map((item) => {
            const active = isActive(item.url)

            return (
              <SidebarMenuItem key={item.name}>
                <SidebarMenuButton
                  tooltip={item.name}
                  isActive={active}
                  onClick={() => handleClick(item.url)}
                  // onClick={() => router.push(item.url)}
                  className={cn(
                    "h-11 mb-2 flex items-center gap-3 transition-all",
                    !isCollapsed ? "pl-[25%] rounded-r-full" : "rounded-full",
                    "data-[active=true]:bg-[hsl(var(--sidebar-primary))]",
                    "data-[active=true]:text-[hsl(var(--sidebar-primary-foreground))]"
                  )}
                >
                  <item.icon className="size-5 shrink-0" />

                  <span
                    className={cn(
                      "font-medium transition-all duration-200",
                      isCollapsed ? "opacity-0 w-0" : "opacity-100 w-auto"
                    )}
                  >
                    {item.name}
                  </span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            )
          })}
        </SidebarMenu>

      </SidebarContent>

      <SidebarFooter className={`border-t border-[hsl(var(--sidebar-border))] ${isCollapsed ? "p-2" : "py-2 pr-2"}`}>
        <SidebarMenu className="gap-1">

          {/* Settings Button */}
          {/* <SidebarMenuItem>
            <SidebarMenuButton
              tooltip="Settings"
              className={`h-11 w-full mb-2 justify-start gap-3 transition-all duration-200 ease-in-out ${!isCollapsed ? "pl-[25%] rounded-r-full" : "rounded-full"}`}
            >
              <Settings className="size-5 shrink-0" />
              {!isCollapsed && <span className="font-medium transition-all duration-200 ease-in-out">Settings</span>}
            </SidebarMenuButton>
          </SidebarMenuItem> */}

          {/* Logout Button */}
          <SidebarMenuItem>
            <SidebarMenuButton
              tooltip="Logout"
              onClick={handleLogout}
              className={`h-11 w-full mb-2 justify-start gap-3 text-[hsl(var(--destructive))] hover:text-[hsl(var(--destructive))] hover:bg-[hsl(var(--destructive))]/10 transition-all duration-200 ease-in-out ${!isCollapsed ? "pl-[25%] rounded-r-full" : "rounded-full"}`}
            >
              <LogOut className="size-5 shrink-0" />
              <span className={`font-medium transition-all duration-200 ease-in-out ${isCollapsed ? "opacity-0 w-0" : "opacity-100 w-auto"
                }`}>Logout</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}