"use client"

import {
  CircleCheckIcon,
  InfoIcon,
  Loader2Icon,
  OctagonXIcon,
  TriangleAlertIcon,
} from "lucide-react"
import { useTheme } from "next-themes"
import { Toaster as Sonner, type ToasterProps } from "sonner"

const Toaster = ({ ...props }: ToasterProps) => {
  const { theme = "system" } = useTheme()

  return (
    <Sonner
      theme={theme as ToasterProps["theme"]}
      className="toaster group"
      // This enables the progress bar globally
      toastOptions={{
        unstyled: false,
        // className: "glass-card note-shadow group![.toaster]:border-border",
        classNames: {
          toast: "glass-card note-shadow !border-border",
          title: "text-foreground font-semibold", // Style for the title
          description: "text-muted-foreground text-sm", // Style for the description
        },
        style: {
          borderRadius: "var(--radius)",
        },
      }}
      icons={{
        success: <CircleCheckIcon className="size-4 text-[hsl(var(--success))]" />,
        info: <InfoIcon className="size-4 text-[hsl(var(--primary))]" />,
        warning: <TriangleAlertIcon className="size-4 text-[hsl(var(--warning))]" />,
        error: <OctagonXIcon className="size-4 text-[hsl(var(--destructive))]" />,
        loading: <Loader2Icon className="size-4 animate-spin text-[hsl(var(--muted-foreground))]" />,
      }}
      style={
        {
          "--normal-bg": "hsl(var(--popover))",
          "--normal-text": "hsl(var(--popover-foreground))",
          "--normal-border": "hsl(var(--border))",
          "--success-bg": "hsl(var(--success) / 0.1)",
          "--success-text": "hsl(var(--success))",
          "--error-bg": "hsl(var(--destructive) / 0.1)",
          "--error-text": "hsl(var(--destructive))",
          "--info-bg": "hsl(var(--primary) / 0.1)",
          "--info-text": "hsl(var(--primary))",
          "--warning-bg": "hsl(var(--warning) / 0.1)",
          "--warning-text": "hsl(var(--warning))",
        } as React.CSSProperties
      }
      {...props}
    />
  )
}

export { Toaster }