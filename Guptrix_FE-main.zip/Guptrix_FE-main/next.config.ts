import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: false,
  output: "standalone", // ensures all required files are included for Netlify
};

export default nextConfig;