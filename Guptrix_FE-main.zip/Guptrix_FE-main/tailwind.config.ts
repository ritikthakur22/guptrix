// tailwind.config.ts
import type { Config } from "tailwindcss";

export default {
    darkMode: "class", // Just "class", not an array in v4
    content: [
        "./app/**/*.{ts,tsx}",
        "./components/**/*.{ts,tsx}",
        "./src/**/*.{ts,tsx}",
    ],
    theme: {
        extend: {
            // Add custom note colors that aren't auto-generated
            colors: {
                "note-yellow": "hsl(var(--note-yellow))",
                "note-green": "hsl(var(--note-green))",
                "note-blue": "hsl(var(--note-blue))",
                "note-pink": "hsl(var(--note-pink))",
                "note-purple": "hsl(var(--note-purple))",
                "note-orange": "hsl(var(--note-orange))",
            },
            // Keep animations from v3
            keyframes: {
                "accordion-down": {
                    from: { height: "0" },
                    to: { height: "var(--radix-accordion-content-height)" },
                },
                "accordion-up": {
                    from: { height: "var(--radix-accordion-content-height)" },
                    to: { height: "0" },
                },
            },
            animation: {
                "accordion-down": "accordion-down 0.2s ease-out",
                "accordion-up": "accordion-up 0.2s ease-out",
            },
        },
    },
    // plugins: [require("tailwindcss-animate")],
} satisfies Config;